/*
* Writer.java        09/03/2022
*
* This is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation v3.
*
* @see <a href="http://www.gnu.org/licenses/gpl.html">GNU License</a> for more information.
*
* Copyright (c) Joan S�culi <a href="mailto:jseculi@escoladeltreball.org">Joan Seculi</a>
*/
package libraryStream;
/**
* Writer class.
*
* @author  <a href="mailto:jseculi@escoladeltreball.org">Joan Seculi</a>
* @version 1.0
* @since   09/03/2022  
* 
*
* This is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation v3.
*
* @see <a href="http://www.gnu.org/licenses/gpl.html">GNU License</a>
*
*
*/
public class Writer {
	private String name;
	private String dateBirth;
	private String countryOfBirth;
	/**
	 * Writer constructor using name, dateBirth and countryOfBirth
	 * 
	 * @param name
	 * @param dateBirth
	 * @param countryOfBirth
	 */
	public Writer(String name, String dateBirth, String countryOfBirth) {
		super();
		this.name = name;
		this.dateBirth = dateBirth;
		this.countryOfBirth = countryOfBirth;
	}
	/**
	 * Returns the writer name.
	 * 
	 * @return the writer name
	 */
	public String getName() {
		return name;
	}
	/**
	 * Sets the name writer with the given String.
	 * 
	 * @param name	the given name value
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * Returns the writer dateBirth.
	 * 
	 * @return the writer dateBirth
	 */
	public String getDateBirth() {
		return dateBirth;
	}
	/**
	 * Sets the dateBirth writer with the given String.
	 * 
	 * @param name	the given dateBirth value
	 */
	public void setDateBirth(String dateBirth) {
		this.dateBirth = dateBirth;
	}
	/**
	 * Returns the writer countryOfBirth.
	 * 
	 * @return the writer countryOfBirth
	 */
	public String getCountryOfBirth() {
		return countryOfBirth;
	}
	/**
	 * Sets the countryOfBirth writer with the given String.
	 * 
	 * @param name	the given countryOfBirth value
	 */
	public void setCountryOfBirth(String countryOfBirth) {
		this.countryOfBirth = countryOfBirth;
	}
	/**
	 * Returns a String representation of a Writer object. <br />
	 * 
	 * Exemple: <br />
	 * {@code 0015  978-84-8181-015-5   HARRY POTTER AND THE CURSED CHILD            J. THORNE, J.K. ROWLING, J. TIFFANY     2007 }
	 */
	@Override
	public String toString() {
		
		return String.format("%-20S%-15S%-15S", name, dateBirth, countryOfBirth);
	}
	/**
	 *@hidden
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((countryOfBirth == null) ? 0 : countryOfBirth.hashCode());
		result = prime * result + ((dateBirth == null) ? 0 : dateBirth.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}
	/**
	 *@hidden
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof Writer))
			return false;
		Writer other = (Writer) obj;
		if (countryOfBirth == null) {
			if (other.countryOfBirth != null)
				return false;
		} else if (!countryOfBirth.equals(other.countryOfBirth))
			return false;
		if (dateBirth == null) {
			if (other.dateBirth != null)
				return false;
		} else if (!dateBirth.equals(other.dateBirth))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equalsIgnoreCase(other.name))
			return false;
		return true;
	}
	
	
	
}
