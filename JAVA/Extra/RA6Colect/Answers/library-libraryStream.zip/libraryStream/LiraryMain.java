/*
 * LibraryMain.java       01.02.2021
 *
 *
 * Copyright 2020 Joan Seculi <jseculi@escoladeltreball.org>
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package libraryStream;

import java.util.HashSet;
import java.util.Locale;
import java.util.Scanner;
import java.util.Set;

public class LiraryMain {
	public static Scanner scanner = new Scanner(System.in).useLocale(Locale.UK);

	public static void main(String[] args) {
		Library library = new Library("Library");

		Writer tolkien = new Writer("J.R.R. Tolkien", "03/02/1892", "South-Africa");
		// System.out.println(writer1);
		Writer rowling = new Writer("J.K. Rowling", "31/07/1965", "UK");
		Writer thorne = new Writer("J. Thorne", "31/07/1965", "UK");
		Writer tiffany = new Writer("J. Tiffany", "31/07/1965", "UK");
		Writer king = new Writer("Stephen King", "21/09/1947", "US");
		Writer straub = new Writer("Peter Straub", "02/04/1947", "US");
		Writer straub2 = new Writer("Peter Straub", "02/04/1947", "US");
		


		Book book2 = new Book("978-84-8181-002-5", "The Hobbit", (short) 1934);
		book2.addWriter(tolkien);
		
		Book book3 = new Book("978-84-8181-003-5", "The Fellowship of the Ring", (short) 1954);
		book3.addWriter(tolkien);
			
		Book book4 = new Book("978-84-8181-004-5", "The Two Towers", (short) 1957);
		book4.addWriter(tolkien);
				
		Book book5 = new Book("978-84-8181-005-5", "The Return of the king", (short) 1959);
		book5.addWriter(tolkien);
		
		Book book6 = new Book("978-84-8181-006-5", "The Silmarillion", (short) 1960);
		book6.addWriter(tolkien);
		
		Book book7 = new Book("978-84-8181-007-5", "The Children of H�rin", (short) 1965);
		book7.addWriter(tolkien);	
		
		Book book8 = new Book("978-84-8181-008-5", "Harry Potter and the Sorcerer's Stone", (short) 1997);
		book8.addWriter(rowling);
		
		Book book9 = new Book("978-84-8181-009-5", "Harry Potter and the Chamber of Secrets",	(short) 1998);
		book9.addWriter(rowling);
			
		Book book10 = new Book("978-84-8181-010-5", "Harry Potter and the Prisoner of Azkaban",	(short) 1999);
		book10.addWriter(rowling);
		
		Book book11 = new Book("978-84-8181-011-5", "Harry Potter and the Goblet of Fire", (short) 2000);
		book11.addWriter(rowling);
			
		Book book12 = new Book("978-84-8181-012-5", "Harry Potter and the Order of the Phoenix",(short) 2003);
		book12.addWriter(rowling);
		
		Book book13 = new Book("978-84-8181-013-5", "Harry Potter and the Half-Blood Prince",(short) 2005);
		book13.addWriter(rowling);
		
		Book book14 = new Book("978-84-8181-014-5", "Harry Potter and the Deathly Hallows", (short) 2007);
		book14.addWriter(rowling);

		Book book15 = new Book("978-84-8181-015-5", "Harry Potter and the Cursed Child", (short) 2007);
		book15.addWriter(rowling);
		book15.addWriter(thorne);
		book15.addWriter(tiffany);
		
		Book book16 = new Book("978-034-544-488-2", "The Talisman", (short)1984);
		book16.addWriter(king);
		book16.addWriter(straub);
		
	
		//library.addBook(book1);
		library.addBook(book2);
		library.addBook(book3);
		library.addBook(book4);
		library.addBook(book5);
		library.addBook(book6);
		library.addBook(book7);
		library.addBook(book8);
		library.addBook(book9);
		library.addBook(book10);
		library.addBook(book11);
		library.addBook(book12);
		library.addBook(book13);
		library.addBook(book14);
		library.addBook(book15);
		library.addBook(book16);
		
	/*	System.out.println(book2);
		System.out.println(book3);
		System.out.println(book4);
		System.out.println(book5);
		System.out.println(book6);
		System.out.println(book7);
		System.out.println(book8);
		System.out.println(book9);
		System.out.println(book10);
		System.out.println(book11);
		System.out.println(book12);
		System.out.println(book13);
		System.out.println(book14);
		System.out.println(book15);
		System.out.println(book16);
*/

		// System.out.println(library.toString());

		byte option = menu();
		if (option == 0) {
			System.out.println("BYE!");
		}
		while (option != 0) {
			switch (option) {
			case 1:
				System.out.println("LIST ALL BOOKS");
				System.out.println(library.toString());
				
				
				break;
			case 2:
				System.out.println("ADD BOOK");
				scanner.nextLine();
				System.out.println("ENTER ISBN OF BOOK:");
				String isbn = scanner.nextLine();
				System.out.println("ENTER TITLE OF BOOK:");
				String title = scanner.nextLine();

				short year = dataEntryShort("ENTER YEAR OF BOOK: ");

				Book newBook = new Book(isbn, title, year);
				System.out.println("BOOK ADDED: " + library.addBook(newBook));
				
				int numWriters = dataEntryInt("ENTER NUMBER OF WRITERS: ");
				scanner.nextLine();
			
				for (int i = 0; i < numWriters; i++) {
					System.out.println("ENTER NAME OF WRITER:");

					String nameWriter = scanner.nextLine();
					System.out.println("ENTER BIRTH DATE OF WRITER:");
					String birthDate = scanner.nextLine();
					System.out.println("ENTER COUNTRY OF WRITER:");
					String countryOfBirth = scanner.nextLine();
					
					System.out.println("WRITER ADDED: " + newBook.addWriter(new Writer(nameWriter, birthDate, countryOfBirth)));
				}
				

				break;
			case 3:
				System.out.println("REMOVE BOOK");
				System.out.println("ENTER THE CODE OF THE BOOK: ");
				scanner.nextLine();
				String codeB = scanner.nextLine();
				
				if (library.removeBook(codeB)) {
					System.out.println("BOOK HAS BEEN REMOVED");
				} else {
					System.out.println("ERROR REMOVING BOOK FROM LIBRARY");
				}
				break;
			case 4:
				System.out.println("SEARCH BOOK");
				System.out.println("ENTER CODE BOOK: ");
				scanner.nextLine();
				String code1 = scanner.nextLine();
				
				if (library.isBookInLibrary(code1)) {
					System.out.println("BOOK IS THE LIBRARY");
				
				} else {
					System.out.println("BOOK IS NOT IN THE LIBRARY");
				}

				
				break;

			case 5:
				System.out.println("NUMBER OF BOOKS");
				// Test methods
				System.out.println("UMBER OF BOOKS IN LIBRARY: " + library.numberOfBooks());

				break;
			case 6:
				System.out.println("GET BOOKS FROM LIBRARY");
				byte selection = dataEntryByte("1: SEARCH BY CODE, 2: SEARCH BY ISBN ?");
				scanner.nextLine();
				boolean sel = false;
				String search = "";

				if (selection == 1) {
					sel = true;
					System.out.print("ENTER CODE: ");
					search = scanner.nextLine();
				} else {
					// sel = false;
					System.out.print("ENTER ISBN: ");
					search = scanner.nextLine();
				}

				Book newBook2 = library.getBookFromLibrary(search, sel);

				if (newBook2 != null)
					System.out.println("\n" + newBook2.toString());
				else
					System.out.println("getBookFromLibrary: NOT IN LIBRARY");

				break;
		
			case 7:
				System.out.println("GET BOOKS BY TITLE");
				scanner.nextLine();
				// Get books from writer

				Set<Book> booksTitle = new HashSet<Book>();
				System.out.println("ENTER TITLE: ");
				title = scanner.nextLine();
				booksTitle = library.getBooksByTitle(title);

				for (Book b : booksTitle) {
					System.out.println(b.toString());
				}

				break;
			case 8:
				System.out.println("GET BOOKS BY WRITER");
				scanner.nextLine();
				// Get books from writer

				Set<Book> booksWriter = new HashSet<Book>();
				System.out.println("ENTER NAME OF WRITER: ");
				String writerS = scanner.nextLine();
				booksWriter = library.getBooksByWriter(writerS);

				for (Book b : booksWriter) {
					System.out.println(b.toString());
				}

				break;
			default:
				System.out.println("WRONG ENTRY, PLEASE ENTER A NUMBER FROM 0 to 7: ");
				break;
			}
			option = menu();
			if (option == 0) {
				System.out.println("BYE!");
			}

		}
		scanner.close();

	

	}

	public static byte menu() {
		System.out.println("MENU");
		System.out.println("1. LIST ALL BOOKS");
		System.out.println("2. ADD BOOK");
		System.out.println("3. REMOVE BOOK");
		System.out.println("4. SEARCH BOOK");
		System.out.println("5. NUMBER OF BOOKS");
		System.out.println("6. GET BOOK FROM LIBRARY");
		System.out.println("7. GET BOOKS BY TITLE");
		System.out.println("8. GET BOOKS BY WRITER");

		System.out.println("0. Quit");
		byte option = dataEntryByte("CHOOSE MENU OPTION: ");
		return option;
	}

	public static byte dataEntryByte(String text) {
		byte number = 0;
		System.out.print(text);
		boolean isValid = false;
		while (!isValid) {
			if (scanner.hasNextByte()) {
				number = scanner.nextByte();
				isValid = true;
			} else {
				scanner.next(); // Consume next line
				System.out.println("Error! " + text);
			}
		}
		return number;
	}

	public static int dataEntryInt(String text) {
		int number = 0;
		System.out.print(text);
		boolean isValid = false;
		while (!isValid) {
			if (scanner.hasNextInt()) {
				number = scanner.nextInt();
				isValid = true;
			} else {
				scanner.next(); // Consume next line
				System.out.println("Error! " + text);
			}
		}
		return number;
	}

	public static short dataEntryShort(String text) {
		short number = 0;
		System.out.print(text);
		boolean isValid = false;
		while (!isValid) {
			if (scanner.hasNextShort()) {
				number = scanner.nextShort();
				isValid = true;
			} else {
				scanner.next(); // Consume next line
				System.out.println("Error! " + text);
			}
		}
		return number;
	}

}
