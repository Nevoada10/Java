/*
 * Book.java        20.10.2020
 *
 *
 * Copyright 2020 Joan Seculi <jseculi@escoladeltreball.org>
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package libraryStream;

import java.util.HashSet;
import java.util.Set;

/**
* Book class.
*
* @author  <a href="mailto:jseculi@escoladeltreball.org">Joan Seculi</a>
* @version 1.0
* @since   09/03/2022  
* 
*
* This is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation v3.
*
* @see <a href="http://www.gnu.org/licenses/gpl.html">GNU License</a>
*
*
*/
public class Book /*implements Comparable<Book>*/{
	
	private String code;
	private String isbn;
	private String title;
	private Set<Writer> writers;
	private short year;
	
	private static int idNext = 1;
	
	/**
	 * Book constructor with all attributes.
	 * <br />
	 * This constructor uses:<br />
	 * @see #generateCode()
	 * 
	 * @param isbn	book ISBN code. Example: "978-84-8181-002-5"
	 * @param title	book title
	 * @param writers 	book writers
	 * @param year		book year
	 */
	public Book(String isbn, String title, Set<Writer> writers, short year) {
		this.code = generateCode();
		this.isbn = isbn;
		this.title = title;
		this.writers = writers;
		this.year = year;
		idNext++;
	}


	/**
	 * Returns the generated code for next book.
	 * 
	 * @return the generated book code
	 */
	public String generateCode() {
		return String.format("%04d", idNext);
	}
	
	
	/**
	 * Book Constructor.
	 * <br />
	 * This constructor uses:<br />
	 * @see #generateCode()
	 * 
	 * @param isbn	book ISBN code. Example: "978-84-8181-002-5"
	 * @param title	book title
	 * @param year		book year
	 */
	public Book(String isbn, String title, short year) {
		this.code = generateCode();
		this.isbn = isbn;
		this.title = title;
		this.writers = new HashSet<>();
		this.year = year;
		idNext++;
	}

	
	/**
	 * Returns the book code.
	 * @return	the book code
	 */
	public String getCode() {
		return code;
	}
	/**
	 * Sets the code with the given String value.
	 * @param code the given code value
	 */
	public void setCode(String code) {
		this.code = code;
	}
	/**
	 * Returns the ISBN code.
	 * @return	the ISBN code
	 */
	public String getIsbn() {
		return isbn;
	}
	/**
	 * Sets the book ISBN with the given String value.
	 * @param isbn the given ISBN value
	 */
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	/**
	 * @return
	 */
	public String getTitle() {
		return title;
	}
	
	/**
	 * Sets the book title with the given String value.
	 * @param title	the given title value
	 */
	public void setTitle(String title) {
		this.title = title;
	}
	
	/**
	 * @return the book writers
	 */
	public Set<Writer> getWriters() {
		return writers;
	}
	
	/**
	 * Sets the book writers with the given collection Set.

	 * @param writers	the given collection Set
	 */
	public void setWriters(Set<Writer> writers) {
		this.writers = writers;
	}
	
	/**
	 * Returns the book year.
	 * 
	 * @return	the book year
	 */
	public short getYear() {
		return year;
	}
	
	/**
	 * Sets the year book with the given short value.
	 * 
	 * @param year the given year value
	 */
	public void setYear(short year) {
		this.year = year;
	}

	/**
	 *@hidden
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((code == null) ? 0 : code.hashCode());
		return result;
	}
	
	/**
	 *@hidden
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Book other = (Book) obj;
		if (code == null) {
			if (other.code != null)
				return false;
		} else if (!code.equalsIgnoreCase(other.code))
			return false;
		return true;
	}
	
	/**
	 * Returns a String representation of the book object. <br />
	 * 
	 * Exemple: <br />
	 * {@code 0015  978-84-8181-015-5   HARRY POTTER AND THE CURSED CHILD            J. THORNE, J.K. ROWLING, J. TIFFANY     2007 }
	 */
	@Override
	public String toString() {
		//return "Book [code=" + code + ", isbn=" + isbn + ", title=" + title + ", writer=" + writer + ", year=" + year
		//		+ "]\n";
		String text = "";
		String writerTextString = "";
		if (writers != null) {
			int count = 1;
			for (Writer w: writers) {
				if (count == writers.size()) {
					writerTextString += w.getName();
				} else  {
					writerTextString += w.getName() + ", ";
				}
				count++;
				
			}
		}
		
		text += String.format("%-6S%-20S%-45S%-40S%-5d", code, isbn, title, writerTextString, year);
		return text;
	}
	
	/**
	 * Add a writer to the book.
	 * @param writer	the writer to add
	 * @return			{@code true} if writer is added, {@code false} otherwise
	 */
	public boolean addWriter(Writer writer) {
		return writers.add(writer);
	}

	/*@Override
	public int compareTo(Book o) {
		if (this.title.compareTo(o.title) > 0) return 1;
		else if (this.title.compareTo(o.title) < 0) return -1;
		else if (this.year > o.year) return 1;
		else if (this.year < o.year) return -1;
		return 0;
	}
*/
}
