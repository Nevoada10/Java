/*
 * Library.java        20.10.2020
 *
 *
 * Copyright 2020 Joan Seculi <jseculi@escoladeltreball.org>
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package libraryStream;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;


/**
* Library class.
*
* @author  <a href="mailto:jseculi@escoladeltreball.org">Joan Seculi</a>
* @version 1.0
* @since   09/03/2022  
* 
*
* This is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation v3.
*
* @see <a href="http://www.gnu.org/licenses/gpl.html">GNU License</a>
*
*
*/
public class Library {
	private String name;
	private Set<Book> books;
	
	/**
	 * Library constructor.
	 * @param name the library name
	 */
	public Library(String name) {
		this.name = name;
		this.books = new HashSet<Book>();
	}
	
	
	/**
	 * Adds a book to the library
	 * @param book
	 * @return true if the book is added, otherwise false
	 */
	public boolean addBook(Book book) {
		return this.books.add(book);
	}

//	/**
//	 * Remove a book to the library
//	 * @param book
//	 * @return true if the book is removed, otherwise false
//	 */
//	public boolean removeBook(Book book) {
//		
//		return this.books.remove(book);
//	}
	
	/**
	 * Remove a book to the library
	 * @param book
	 * @return true if the book is removed, otherwise false
	 */
	public boolean removeBook(String code) {
		return books.removeIf(b -> b.getCode().equals(code));
	}
	
	
//	/**
//	 * Remove a book to the library
//	 * @param book
//	 * @return true if the book is removed, otherwise false
//	 */
//	public boolean removeBook2(String code) {
//		for (Book b : books) {
//			if (b.getCode().equals(code)) {	
//				return this.books.remove(b);
//			}
//		}
//		return false;
//	}
	
	
	/**
	 * Check if book is in the library
	 * @param book
	 * @return true if the book is found, otherwise false
	 */
	public boolean isBookInLibrary(Book book) {
		
		return this.books.contains(book);
	}
	

	/**
	 * Check if a book is in library.
	 * @param code	the book code
	 * @return	true if the book is in library, false otherwise
	 */
	public boolean isBookInLibrary(String code) {
		
		
		//Option anyMatch
		return books.stream().anyMatch(b -> b.getCode().equals(code));
	
		//Option findAny i isPresent
		
//		return books.stream()
//                .filter(b -> b.getCode().equals(code))
//                .findAny()
//                .isPresent();
        
	}
	
	/**
	 * Returns the number of books in library.
	 * 
	 * @return	the number of books
	 */
	public int numberOfBooks() {
		return this.books.size();
	}
	
	

	/**
	 * Retrieve the book knowing the code or ISBN.
	 * 
	 * @param param	the book or ISBN code
	 * @param isCode	if true, the method searches the code, otherwise it searches the ISBN
	 * @return
	 */
	public Book getBookFromLibrary(String param, boolean isCode) {
		return books.stream()
                .filter(b -> isCode ? b.getCode().equals(param) : b.getIsbn().equals(param))
                .findFirst()
                .orElse(null);
		
	}
	
	/**
	 * Retrieve the book knowing the code or ISBN.
	 * 
	 * @param param	the book or ISBN code
	 * @param isCode	if true, the method searches the code, otherwise it searches the ISBN
	 * @return
	 */
	public Book getBookFromLibrary2(String param, boolean isCode) {
		for (Book b : books) {
			if (isCode) {
				if (b.getCode().equals(param)) {
					return b;
				}
			}
			else {
				if (b.getIsbn().equals(param)) {
					return b;
				}
			}
		}
		return null;
		
	}
	
	/**
	 * Gets the books by writer.
	 *  
	 * @param writer the writer name
	 * @return the list of books written by a writer	
	 */
	public Set<Book> getBooksByWriter(String writer) {
		if (writer.isEmpty()) {  //or writer.equals("")
	        return null;
	    }
		
		//Option1
		/*
	    return books.stream()
                .filter(b -> b.getWriters().stream()
                              .map(r -> r.getName().toUpperCase())
                              .anyMatch(name -> name.contains(writer.toUpperCase())))
                .collect(Collectors.toSet());
	    */
	    //Option2
	   /* return books.stream()
                .filter(b -> b.getWriters().stream()
                              .flatMap(r -> Stream.of(r.getName().toUpperCase()))
                              .anyMatch(name -> name.contains(writer.toUpperCase())))
                .collect(Collectors.toSet());
		*/
	    
	    //Option3
	    
		return books.stream()
                .filter(b -> b.getWriters().stream()
                              .anyMatch(r -> r.getName().toUpperCase().contains(writer.toUpperCase())))
                .collect(Collectors.toSet());
	    
	    
	    
	    
	}
	
	/**
	 * Gets the books by writer.
	 *  
	 * @param writer the writer name
	 * @return the list of books written by a writer	
	 */
	public Set<Book> getBooksByWriter2(String writer) {
		HashSet<Book> bWriter = new HashSet<Book>();
		if (writer.equals("")) {
			return books;
		}
		for (Book b : books) {
			for (Writer r : b.getWriters()) {
				if (r.getName().toUpperCase().contains(writer.toUpperCase())) {
					bWriter.add(b);
				}
			}
			
		}
		//retornem null sin� s'ha trobat
		return bWriter;
	
	}

	/**
	 * Gets the books by title.
	 *  
	 * @param title the book title
	 * @return the list of books by title	
	 */
	public Set<Book> getBooksByTitle(String title) {
		
		return books.stream()
				.filter(b -> b.getTitle().toLowerCase().contains(title.toLowerCase()))
				.collect(Collectors.toSet());
	
	}
	
	/**
	 * Gets the books by title.
	 *  
	 * @param title the book title
	 * @return the list of books by title	
	 */
	public Set<Book> getBooksByTitle2(String title) {

		HashSet<Book> bWriter = new HashSet<Book>();
		if (title.equals("")) {
			return books;
		}
		for (Book b : books) {
			if (b.getTitle().toUpperCase().contains(title.toUpperCase())) {
				bWriter.add(b);
			}
		}
		// retornem null sin� s'ha trobat
		return bWriter;

	}



	/**
	 * Returns a String representation of a Library object. <br />
	 *
	 */
	@Override
	public String toString() {
		StringBuilder text = new StringBuilder(String.format("%S:%-10S%n", "NAME", name));
		text.append(String.format("%-6S%-20S%-45S%-40S%-5S\n", "CODE", "IBN", "TITLE", "WRITER", "YEAR"));
		text.append("--------------------------------------------------------------------------------------------------------------------\n");
		//TRANSFOEM LIST ORDER BY
		books.stream()
			.forEach(b -> text.append(b + "\n"));

		
		return text.toString();
	}
	


}
