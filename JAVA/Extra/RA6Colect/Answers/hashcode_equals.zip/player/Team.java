/*
* Team.java
*
* This is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation v3.
*
* @see <a href="http://www.gnu.org/licenses/gpl.html">GNU License</a> for more information.
*
* Copyright (c) Joan S�culi <a href="mailto:jseculi@escoladeltreball.org">Joan Seculi</a>
*/
package player;

public enum Team {
      FCB("Futbol Club Barcelona", "Spain"), 
      RM("Real Madrid", "Spain"), 
      SFC("Sevilla FC", "Spain"), 
     
      PSG("Paris Saint Germain", "France"), 
      BNF("Benfica", "Portugal"), 
      JUV("Juventus", "Italy");
	
	  private final String name;
	  private final String country;
	  
	  
	  private Team(String name, String country) {
		  this.name = name;
		  this.country = country;
	  }
      
      public String getName() {
    	  return name;
      }
      public String getCountry() {
    	  return country;
      }
      
}
