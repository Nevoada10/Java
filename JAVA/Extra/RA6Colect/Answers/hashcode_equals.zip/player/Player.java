/*
 * Player.java        01.02.2021
 *
 *
 * Copyright 2020 Joan Seculi <jseculi@escoladeltreball.org>
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package player;

public class Player {
	
	

	private String name;
	private String surname;
	private float height;
	private float weight;
	private byte age;
	private Sex sex;
	private int points;
	private Team team;
	private Position position;
	private boolean active;
	private byte cards;
	
	public static final int INITIAL_POINTS = 100;
	public static final byte INITIAL_AGE = 18;
	public static final byte MAX_CARDS = 2;
	
	
	public Player(String name, String surname, float height, float weight, byte age, Sex sex, int points, Team team,
			Position position, boolean active) {
		this.name = name;
		this.surname = surname;
		this.height = height;
		this.weight = weight;
		setAge(age);
		this.sex = sex;
		setPoints(points);
		this.team = team;
		this.position = position;
		this.active = active;
		//this.cards = 0; Not necessary

	}

	public Player(String name, String surname, float height, float weight, Team team, Position position) {
		this.name = name;
		this.surname = surname;
		this.height = height;
		this.weight = weight;
		setAge(age);
		this.sex = Sex.NOTDEFINED;
		this.points = INITIAL_POINTS;
		this.team = team;
		this.position = position;
		this.active = true;
	}

	public Player(String name, String surname, Sex sex, Team team, Position position) {
		this.name = name;
		this.surname = surname;
		this.sex = sex;
		this.age = INITIAL_AGE;
		this.sex = sex;
		this.points = INITIAL_POINTS;
		this.team = team;
		this.position = position;
		this.active = true;
	}

	public Player(String name, String surname, byte age, Sex sex, Team team, Position position) {
		this.name = name;
		this.surname = surname;
		this.age = age;
		this.sex = sex;
		this.points = INITIAL_POINTS;
		this.team = team;
		this.position = position;
		this.active = true;
	}

	@Override
	public String toString() {
		return "PLAYER: " + String.format("%-10S", name) + 
							String.format("%-10S", surname) + 
							String.format("%-10.2f", height) + 
							String.format("%-10.2f", weight) +
							String.format("%-10d", age) +    //NOT NECESSARY TO age.toString(), it is done by us 
							String.format("%-10S", sex) +    //NOT NECESSARY TO age.toString(), it is done by us 
							String.format("%-10d", points) + 
							String.format("%-10S", team) +   //NOT NECESSARY TO age.toString(), it is done by us 
							String.format("%-10S", position) +  //NOT NECESSARY TO age.toString(), it is done by us 
							String.format("%-10B", active) + 
							String.format("%-101d", cards); 
	}
	

	/**
	 * Increase points if player is active and cards < 2
	 * @param points	the number of points to increase
	 * @return			true if the points are increased
	 */
	public boolean increasePoints(int points) {
		if (points > 0 && this.active && this.cards < 2) {
			this.points += points;
			return true;
		} else return false;
	}
	
	/**
	 * Decrease points of player, only if the player is active, cards < 2 and points are bigger than 0
	 * @param points	the number of points to decrease
	 * @return			true if the points are decreased
	 */
	public boolean decreasePoints(int points) {
		if (points <= 0 || this.cards == 2 || !this.active)  return false;
		if (this.points - points < 0) {
			this.points = 0;
			this.active = false;
			return true;
		} else {
			this.points -= points;
			return true;
		}
	}
	
	
	
	/** Add 1 to number of cards if player is active and cards < 2
	 * @return 	true if player get a new card
	 */
	public boolean giveCard() {
		if (this.cards == 2 || !this.active) return false;
		else if (this.cards == 1) {
			this.cards++;
			this.active = false;
			return true;
		} else {
			this.cards++;
			return true;
		}
	}
	
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public float getHeight() {
		return height;
	}

	public void setHeight(float height) {
		this.height = height;
	}

	public float getWeight() {
		return weight;
	}

	public void setWeight(float weight) {
		this.weight = weight;
	}

	

	public byte getAge() {
		return age;
	}

	public void setAge(byte age) {
		if (age < INITIAL_AGE) this.age = 18;
		else  this.age = age;
	}

	public Sex getSex() {
		return sex;
	}

	public void setSex(Sex sex) {
		this.sex = sex;
	}

	public int getPoints() {
		return this.points;
	}

	public void setPoints(int points) {
		if (points < INITIAL_POINTS) this.points = INITIAL_POINTS;
		else  this.points = points;
	}

	public Team getTeam() {
		return team;
	}

	public void setTeam(Team team) {
		this.team = team;
	}
	
	public Position getPosition() {
		return this.position;
	}

	public void setPosition(Position position) {
		this.position = position;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public byte getCards() {
		return cards;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + age;
		result = prime * result + Float.floatToIntBits(height);
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((surname == null) ? 0 : surname.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof Player))
			return false;
		Player other = (Player) obj;
		if (age != other.age)
			return false;
		if (Float.floatToIntBits(height) != Float.floatToIntBits(other.height))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equalsIgnoreCase(other.name))
			return false;
		if (surname == null) {
			if (other.surname != null)
				return false;
		} else if (!surname.equalsIgnoreCase(other.surname))
			return false;
		return true;
	}
}
