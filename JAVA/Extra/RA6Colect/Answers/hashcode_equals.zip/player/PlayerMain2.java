/*
* PlayerTest2.java
*
* This is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation v3.
*
* @see <a href="http://www.gnu.org/licenses/gpl.html">GNU License</a> for more information.
*
* Copyright (c) Joan S�culi <a href="mailto:jseculi@escoladeltreball.org">Joan Seculi</a>
*/
package player;
/**
* Enter a description
*
* @author  <a href="mailto:jseculi@escoladeltreball.org">Joan Seculi</a>
* @version 1.0
* @since   20/02/2022  
* 
*
* This is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation v3.
*
* @see <a href="http://www.gnu.org/licenses/gpl.html">GNU License</a>
*
*
*/
public class PlayerMain2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//1. Constructor 1

		
		//2. Constructor 2
			
		//3. Constructor 3
			
		//4. Constructor 4
			
		//5. Test increasePoints with 100 for an active player, it should be TRUE
		//Check points after calling the method

		
		//6. Test increasePoints for an inactive player, it should be FALSE
		//Check points of player are the same before and after calling the method		

		
		//7. Test decreasePoints (5 points) for a player with enough points (100)
		//Check points of player are 95 after calling the method;

		
		//8. Test decreasePoints (150 points) for a player with (95 points), it should be TRUE
		//Check points of player are 0 after calling the method;

			
		//9. Test decreasePoints of a player with negative number (-15), it should be FALSE
		//Check points of player are the same before and after calling the method
			
		//10. Test decrease points of an inactive player, it should be FALSE
		//Check points of player has not changed after calling the method
			
		//11. Test giveCard() to an active player with 0 cards, it should be true
		//Check cards after calling method
			
		//12. Test giveCard() to an active player with 1 cards, it should be true
		//Check cards after calling method

		//13. Test giveCard() to an active player with 2 cards, it should be false
		//Check cards after calling method

		//Getters
		//14. getName

		//15. getSurname

		//16. getHeight

		//17. getWeight

		//18. getAge

		//19. getSex

		//20. getTeam

		//21. getTeam -> getName 

		//22. getTeam -> getCountry

		//23. getPosition

		//24. getPoints

		//25. getCards

		//26. isActive
			
		//Setters
		//27. setName

		//28. setSurname

		//29. setHeight

		//30. setWeight

		//31. setAge
			
		//32. setTeam

		//33. setPosition

		//34. setPoints
			
		//35. setActive
	}
}
