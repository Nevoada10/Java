/*
 * Program.java        20.10.2020
 *
 *
 * Copyright 2020 Joan Seculi <jseculi@escoladeltreball.org>
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package player;

import java.util.HashSet;
import java.util.Set;

public class PlayerMain {
	
	public static void main(String[] args) {

		// Part2

		Set<Player> players = new HashSet<>();
		Player mbappe1 = new Player("Kylian", "Mbappé", 1.78f, 80f, (byte) 23, Sex.MAN, 10, Team.PSG, Position.FORWARD,
				true);
		System.out.println(mbappe1.toString());

		Player xBusquets1 = new Player("Sergi", "Busquets", 1.89f, 85f, (byte) 10, Sex.MAN, -10, Team.PSG,
				Position.FORWARD, true);
		System.out.println(xBusquets1.toString());

		Player mLeon1 = new Player("Mapi", "Leon", 1.70f, 60f, (byte) 26, Sex.WOMAN, 100, Team.FCB, Position.DEFENDER,
				false);
		System.out.println(mLeon1.toString());

		Player leoMessi1 = new Player("Leo", "Messi", 1.70f, 70f, Team.PSG, Position.FORWARD);
		System.out.println(leoMessi1.toString());

		Player gerardPique1 = new Player("Gerard", "Pique", 1.94f, 84f, (byte) 35, Sex.MAN, 100, Team.FCB,
				Position.DEFENDER, true);
		System.out.println(gerardPique1.toString());

		Player alexiaPutellas1 = new Player("Alexia", "Putellas", 1.65f, 58f, (byte) 28, Sex.WOMAN, 200, Team.FCB,
				Position.MIDFIELDER, true);
		System.out.println(alexiaPutellas1.toString());

		Player alexiaPutellas2 = new Player("Alexia", "Putellas", 1.65f, 60f, (byte) 28, Sex.WOMAN, 100, Team.PSG,
				Position.DEFENDER, false);
		System.out.println(alexiaPutellas2.toString());

		Player gerardPique2 = new Player("Gerard", "Pique", 1.94f, 85f, (byte) 35, Sex.MAN, 300, Team.FCB,
				Position.MIDFIELDER, true);
		System.out.println(gerardPique2.toString());

		System.out.println(players.add(mbappe1));
		System.out.println(players.add(xBusquets1));
		System.out.println(players.add(mLeon1));
		System.out.println(players.add(leoMessi1));
		System.out.println(players.add(gerardPique1));
		System.out.println(players.add(alexiaPutellas1));
		System.out.println(players.add(alexiaPutellas2));
		System.out.println(players.add(gerardPique2));

		System.out.println("Print Collection: ");
		players.forEach(x -> System.out.println(x));

	}

}
