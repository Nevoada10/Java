/*
 * Mode.java        20.10.2020
 *
 *
 * Copyright 2020 Joan Seculi <jseculi@escoladeltreball.org>
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package skin;

import java.util.Arrays;

public class Mode {

	private Modes modeName;
	private Skin[] skins;
	private Zombi[] zombis;
	
	
	public Mode(Modes modeName, Skin[] skins, int numZombis) {
		this.modeName = modeName;
		this.skins = skins;
		this.zombis = new Zombi[numZombis];
		
		//Hem de crear els zombis en el constructor
		
        for(int i=0; i < zombis.length; i++){
            zombis[i] =  new Zombi(i);
        }
        
	}
	public Modes getModeName() {
		return modeName;
	}
	public void setModeName(Modes modeName) {
		this.modeName = modeName;
	}
	public Skin[] getSkins() {
		return skins;
	}
	public void setSkins(Skin[] skins) {
		this.skins = skins;
	}
	public Zombi[] getZombis() {
		return zombis;
	}
	public void setZombis(Zombi[] zombis) {
		this.zombis = zombis;
	}
	@Override
	public String toString() {
		return "Mode [modeName=" + modeName + ", skins=" + Arrays.toString(skins) + ", zombis="
				+ Arrays.toString(zombis) + "]";
	}
}
