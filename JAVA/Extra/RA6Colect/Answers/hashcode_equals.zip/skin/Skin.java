/*
 * Skin.java        01.02.2021
 *
 *
 * Copyright 2020 Joan Seculi <jseculi@escoladeltreball.org>
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package skin;

public class Skin {
	

	private String name;
	private Sex sex;
	private boolean available;
	private int price;
	private byte numberOfLifes;
	private int points;
	private Status status;
	private boolean[] accessories;
	private int id;
	
	public static int idNext=0;

	
	public Skin(String name, Sex sex, int price) {
		this.name = name;
		this.sex = sex;
		this.available = true;
		this.price = price;
		this.numberOfLifes = 3;
		this.points = 0;
		this.status = Status.RESTING;
		this.accessories = new boolean[] {false,false,false};
		this.id=idNext;
		idNext++;
	}
	
	public boolean loseLife() {
		if (this.numberOfLifes == 1) {
			this.available = false;
			
			this.numberOfLifes = 0;
			return true;
		}
		else  if (this.numberOfLifes > 1){
			this.numberOfLifes--;
			return true;
		}
		return false;
	}
	
	public boolean increaseLife() {
		if (this.available && this.numberOfLifes < 5) {
			this.numberOfLifes ++;
			return true;
		} else {
			return false;
		}
	}
	
	public boolean increasePoints(int points) {
		if (this.available) {
			this.points += points;
			return true;
		}
		return false;
	}
	public boolean decreasePoints(int points) {
		if (this.available) {
			if (this.points - points >= 0) {
				this.points -= points;
				
			}	else {
				this.points = 0;
			} 
			return true;
			
		} else {
			return false;
		}
		
	}
	public boolean resting() {
		if (this.available) {
			this.status = Status.RESTING;
			return true;
		} 
		return false;
	}
	public boolean battling() {
		if (this.available && 
				(  this.accessories[0] == true 
				|| this.accessories[1] == true 
				|| this.accessories[2] == true)) {
			this.status = Status.BATTLING;
			return true;
		} 
		return false;
		
	}
	public boolean eating() {
		if (this.available) {
			this.status = Status.EATING;
			return true;
		} 
		return false;
	}
	
	
	public boolean getSword() {
		if (this.available) {
			this.accessories[0] = true;
			return true;
		}
		return false;
	}
	public boolean getGun() {
		if (this.available) {
			this.accessories[1] = true;
			return true;
		}
		return false;
	}
	public boolean getRope() {
		if (this.available) {
			this.accessories[2] = true;
			return true;
		}
		return false;
	}
	
	public boolean[] getAccessories() {
		return accessories;
	}

	public void setAccessories(boolean[] accessories) {
		this.accessories = accessories;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Sex getSex() {
		return sex;
	}
	public void setSex(Sex sex) {
		this.sex = sex;
	}
	public boolean isAvailable() {
		return available;
	}
	public void setAvailable(boolean availability) {
		this.available = availability;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public byte getNumberOfLifes() {
		return numberOfLifes;
	}
	/*
	public void setNumberOfLifes(byte numberOfLifes) {
		this.numberOfLifes = numberOfLifes;
	}*/
	public int getPoints() {
		return points;
	}
	public void setPoints(int points) {
		this.points = points;
	}
	public Status getStatus() {
		return status;
	}
	public void setStatus(Status status) {
		this.status = status;
	}

	@Override
	public String toString() {
	/*	return "Skin [name=" + this.name + ", gender=" + this.sex + ", availability=" + this.avilable + ", price=" + this.price
				+ ", numberOfLifes=" + this.numberOfLifes + ", points=" + this.points + ", status=" + this.status + ", accessoris="
				+ Arrays.toString(accessories) + ", id" + id + "]";
		*/
		String text = "";
		text += String.format("%-5S%-15S%-10S%-10B%-10d%-10d%-10d%-10S", id, name, sex, available, price, numberOfLifes, points, status);
		return text;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((sex == null) ? 0 : sex.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof Skin))
			return false;
		Skin other = (Skin) obj;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equalsIgnoreCase(other.name))
			return false;
		if (sex != other.sex)
			return false;
		return true;
	}
	
	/*
	public String toString2() {
		return "Skin [name=" + this.name + ", gender=" + this.sex + ", availability=" + this.avilable + ", price=" + this.price
				+ ", numberOfLifes=" + this.numberOfLifes + ", points=" + this.points + ", status=" + this.status + ", accessoris="
				+ Arrays.toString(accessories) + ", id" + id + "]";
	}
*/
	
}
