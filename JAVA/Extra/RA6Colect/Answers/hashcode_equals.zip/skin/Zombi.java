/*
 * Zombi.java        20.10.2020
 *
 *
 * Copyright 2020 Joan Seculi <jseculi@escoladeltreball.org>
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package skin;

public class Zombi {
	private int code;
	private int strength;
	private boolean active;
	
	public Zombi(int code) {
		this.code = code;
		this.strength = 10;
		this.active = true;
	}
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public int getStrength() {
		return strength;
	}
	public void setStrength(int strength) {
		this.strength = strength;
	}
	public boolean isActive() {
		return active;
	}
	public void setActive(boolean active) {
		this.active = active;
	}
	@Override
	public String toString() {
		return "Zombis [code=" + code + ", strength=" + strength + ", active=" + active + "]";
	}
}
