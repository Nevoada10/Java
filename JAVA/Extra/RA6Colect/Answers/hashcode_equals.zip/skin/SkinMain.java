/*
 * SkinTest.java        20.10.2020
 *
 *
 * Copyright 2020 Joan Seculi <jseculi@escoladeltreball.org>
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package skin;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class SkinMain {

	public static void main(String[] args) {
		Skin skin1 = new Skin("Synth", Sex.MAN, 1500);
		
		Skin skin2 = new Skin("Lovely", Sex.WOMAN, 1200);
		
		System.out.println("1. print: " + skin1.toString());
		
		boolean life = skin1.loseLife();
		System.out.println("2. Lose life: " + life + " " + skin1.toString());
		
		life = skin1.loseLife();
		System.out.println("3. Lose life: " + life + " " + skin1.toString());
		
		life = skin1.loseLife();
		System.out.println("4. Lose life: " + life + " " + skin1.toString());
		
		//Ja no tenim m�s vides, no hauria de reduir vides
		life = skin1.loseLife();
		System.out.println("5. Lose life: " + life + " " + skin1.toString());
		
		life = skin1.increaseLife();
		System.out.println("6. Add life: " + life + " " + skin1.toString());
		
		
		//No pot guanyar punts perqu� esta a available false
		boolean points = skin1.increasePoints(100);
		System.out.println("7. Add points: " + points + " " + skin1.toString());
		
		
		
		//skin2
		System.out.println("1. print: " + skin2.toString());
		
		life = skin2.increaseLife();
		System.out.println("2. Add life: " + life + " " + skin2.toString());
		
		life = skin2.increaseLife();
		System.out.println("3. Add life: " + life + " " + skin2.toString());
		
		//No hauria de guanyar vides perqu� ja t� 5
		life = skin2.increaseLife();
		System.out.println("4. Add life: " + life + " " + skin2.toString());
		
		
		points = skin2.increasePoints(100);
		
		System.out.println("5. Add 100 points: " + points + " " + skin2.toString());
		
		points = skin2.decreasePoints(50);
		System.out.println("6. Decrease 100 points: " + points + " " + skin2.toString());
		
		//Es quedar� amb 0 points
		points = skin2.decreasePoints(150);
		System.out.println("7. Decrease 150 points: " + points + " " + skin2.toString());
		
		//False perqu� no t� accessories
		boolean status = skin2.battling();
		System.out.println("8. From resting to battling: " + status  + " " + skin2.toString());
		
		
		status = skin2.eating();
		System.out.println("9. From resting to eating: " + status  + " " + skin2.toString());
		

		status = skin2.resting();
		System.out.println("10. From eating to resting: " + status  + " " + skin2.toString());
		
		
		boolean accessori = skin2.getSword();
		System.out.println("11. Get sword: " + accessori  + " " +  skin2.toString());
		
		accessori = skin2.getGun();
		System.out.println("12. Get gun: " + accessori  + " " +  skin2.toString());
		
		accessori = skin2.getRope();
		System.out.println("13. Get rope: " + accessori  + " " +  skin2.toString());
		
		status = skin2.battling();
		System.out.println("13. From resting to battling: " + status  + " " + skin2.toString());
		
		status = skin2.battling();
		System.out.println("14. From resting to battling: " + status  + " " + skin2.toString());
		
		//Getters and setters
		
		System.out.println("1. getPrice: " + skin1.getPrice());

		System.out.println("2. getAccessories: " + Arrays.toString(skin2.getAccessories()));
		skin2.setPoints(1000);
		System.out.println("3. setPoints: " + skin2.getPoints());
		
		System.out.println("4. getStatus: " + skin2.getStatus());
		
		//ModeTest
		System.out.println("Mode Test");
		Skin[] skins = {
				new Skin("Orelia", Sex.WOMAN, 100),
				new Skin("Midas Rex", Sex.MAN, 100),
				new Skin("Lachlan", Sex.MAN, 100),
				new Skin("The Grefg", Sex.MAN, 100),
				new Skin("Blastoff", Sex.MAN, 100),
				new Skin("Hypersonic", Sex.MAN, 100),
				new Skin("Wanderlust", Sex.MAN, 100),
				new Skin("Hunter", Sex.MAN, 100),
				new Skin("The Mighty Volt", Sex.MAN, 100),
				new Skin("Backlash", Sex.WOMAN, 100)				
		};
		
		System.out.println("saveTheWorldMode");
		Mode saveTheWorldMode = new Mode(Modes.SAVE_THE_WORLD, skins, 500);
		
		
		System.out.println("Get Zombis and Skins");
		System.out.println("Skins: \n" + Arrays.toString(saveTheWorldMode.getSkins()));
		
		//Es tan llarg que no s'imprimeix
		//System.out.println(Arrays.toString(saveTheWorldMode.getZombis()));
		
		for (int i = 0; i < saveTheWorldMode.getZombis().length; i++) {
			System.out.println(saveTheWorldMode.getZombis()[i]);
		}
		
		System.out.println("battleRoyale");
		Mode battleRoyale = new Mode(Modes.BATTLE_ROYALE, skins, 500);
		
		System.out.println("Get Zombis and Skins");
		System.out.println("Skins: \n" + Arrays.toString(battleRoyale.getSkins()));
		
		//Es tan llarg que no s'imprimeix
		//System.out.println(Arrays.toString(saveTheWorldMode.getZombis()));
		
		for (int i = 0; i < battleRoyale.getZombis().length; i++) {
			System.out.println(battleRoyale.getZombis()[i]);
		}
		
		System.out.println("creative");
		Mode creative = new Mode(Modes.CREATIVE, skins, 500);
		
		System.out.println("Get Zombis and Skins");
		System.out.println("Skins: \n" + Arrays.toString(creative.getSkins()));
		
		//Es tan llarg que no s'imprimeix
		//System.out.println(Arrays.toString(saveTheWorldMode.getZombis()));
		
		for (int i = 0; i < creative.getZombis().length; i++) {
			System.out.println(creative.getZombis()[i]);
		}
		
		//Part 2
		System.out.println("Part 2");
		
		Set<Skin> skins2 = new HashSet<>();
		Skin s1 = new Skin("Synth", Sex.MAN, 1500);
		Skin s2 = new Skin("Orelia", Sex.WOMAN, 200);
		Skin s3 = new Skin("Midas Rex", Sex.MAN, 150);
		Skin s4 = new Skin("Lachlan", Sex.MAN, 3000);
		Skin s5 = new Skin("The Grefg", Sex.MAN, 400);
		Skin s6 = new Skin("Blastoff", Sex.MAN, 450);
		Skin s7 = new Skin("Hypersonic", Sex.MAN, 300);
		Skin s8 = new Skin("Wanderlust", Sex.MAN, 100);
		Skin s9 = new Skin("Wanderlust", Sex.WOMAN, 3500);
		Skin s10 = new Skin("Polarity", Sex.WOMAN, 400);
		Skin s11 = new Skin("Lachlan", Sex.MAN, 300);
		Skin s12 = new Skin("Polarity", Sex.WOMAN, 200);
		Skin s13 = new Skin("Orelia", Sex.WOMAN, 100);
		
		System.out.println(s1.toString());
		System.out.println(s2.toString());
		System.out.println(s3.toString());
		System.out.println(s4.toString());
		System.out.println(s5.toString());
		System.out.println(s6.toString());
		System.out.println(s7.toString());
		System.out.println(s8.toString());
		System.out.println(s9.toString());
		System.out.println(s10.toString());
		System.out.println(s11.toString());
		System.out.println(s12.toString());
		System.out.println(s13.toString());
		
		skins2.add(s1);
		skins2.add(s2);
		skins2.add(s3);
		skins2.add(s4);
		skins2.add(s5);
		skins2.add(s6);
		skins2.add(s7);
		skins2.add(s8);
		skins2.add(s9);
		skins2.add(s10);
		skins2.add(s11);
		skins2.add(s12);
		skins2.add(s13);
		
		System.out.println("Print collection:");
		
		skins2.forEach(x -> System.out.println(x));
		
		//Cannot add repeated objectes
		
		System.out.println(skins2.add(s1));
		
	}

}
