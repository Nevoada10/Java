/*
 * PersonTest.java        20.10.2020
 *
 *
 * Copyright 2020 Joan Seculi <jseculi@escoladeltreball.org>
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package client;

import java.util.HashSet;
import java.util.Set;

public class ClientMain {

	public static void main(String[] args) {

		
		System.out.println("Part 2");
		Client c1 = new Client("0000001", "Bugs", "Bunny", "US", "1111111", "11111111A", (byte)15);
		Client c2 = new Client("0000002", "Marilyn", "Monroe", "US", "2222222", "22222222B", (byte)27);
		Client c3 = new Client("0000003", "Peter", "Pan", "UK", "3333333", "33333333C", (byte)12);
		Client c4 = new Client("0000004", "Bart", "Simpson", "UK", "4444444", "44444444D", (byte)10);
		Client c5 = new Client("0000005", "Mafalda", "Srta.", "AR", "5555555", "55555555E", (byte)8);
		Client c6 = new Client("0000006", "Lisa", "Simpson", "US", "6666666", "66666666F", (byte)8);  
		Client c7 = new Client("0000007", "Charlie", "Brown", "UK", "7777777", "77777777G", (byte)8);  
		Client c8 = new Client("0000008", "SpongeBob", "SquarePants", "US", "8888888", "88888888H", (byte)5);  
		Client c9 = new Client("0000009", "Patrick", "Star", "US", "9999999", "99999999I", (byte)5);  
		
		Client c10 = new Client("0000010", "Homer", "Simpson", "US", "1212121", "10101010J", (byte)45);  
		Client c11 = new Client("0000010", "Maggie", "Simpson", "US", "1212121", "11111111K", (byte)30);  
		
		Client c12 = new Client("0000006", "Lisa", "Simpson", "US", "6666666", "66666666F", (byte)8);  
		Client c13 = new Client("0000007", "Charlie", "Brown", "UK", "7777777", "77777777G", (byte)8);  
				
		Set<Client> clients = new HashSet<>();
		System.out.println(clients.add(c1));
		System.out.println(clients.add(c2));
		System.out.println(clients.add(c3));
		System.out.println(clients.add(c4));
		System.out.println(clients.add(c5));
		System.out.println(clients.add(c6));
		System.out.println(clients.add(c7));
		System.out.println(clients.add(c8));
		System.out.println(clients.add(c9));
		System.out.println(clients.add(c10));
		System.out.println(clients.add(c11));
		System.out.println(clients.add(c12));
		System.out.println(clients.add(c13));
		
		System.out.println();
		System.out.println(c12);
		System.out.println(c13);
		System.out.println();
		
		clients.forEach(x -> System.out.println(x));
		
		System.out.println("Add repeated objects");
		System.out.println(clients.add(c1));
		System.out.println(clients.add(c2));
		System.out.println(clients.add(c3));
		System.out.println(clients.add(c4));
		System.out.println(clients.add(c5));
		
		clients.forEach(x -> System.out.println(x));
		
		
	}

}
