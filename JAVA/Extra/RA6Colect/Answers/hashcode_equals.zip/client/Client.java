/*
 * Person.java        20.10.2020
 *
 *
 * Copyright 2020 Joan Seculi <jseculi@escoladeltreball.org>
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package client;

public class Client {
	
	private String accountNum;
	private String name;
	private String surname;
	private String nationality;
	private String phone;
	private String dni;
	private byte age;
	private float debts;
	private boolean active;
	
	public Client(String accountNum, String name, String surname, String nationality, String phone, String dni, byte age) {
		this.accountNum = accountNum;
		this.name = name;
		this.surname = surname;
		this.nationality = nationality;
		this.phone = phone;
		this.dni = dni;
		this.age = age;
		//this.debts = 0; //NOT NECESSARY, BY DEFAULT IS 0
		this.active = true;
	}

	public Client(String accountNum, String name, String surname, String dni) {
		this.accountNum = accountNum;
		this.name = name;
		this.surname = surname;
		this.dni = dni;
		this.nationality = "ES";
		this.phone = "NOT_PROVIDED";
		this.age = 18;
		//this.debts = 0;  //NOT NECESSARY, BY DEFAULT IS 0
		this.active = true;
	}

	public String getAccount() {
		return accountNum;
	}

	public void setAccount(String accountNum) {
		this.accountNum = accountNum;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getDni() {
		return dni;
	}

	public void setDni(String dni) {
		this.dni = dni;
	}

	public byte getAge() {
		return age;
	}



	public void setAge(byte age) {
		this.age = age;
	}

	public float getDebts() {
		return debts;
	}

	
	public void setDebts(float debts) {
		this.debts = debts;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	@Override
	public String toString() {
		/*return "Client [accountNum=" + this.accountNum + ", name=" + this.name + ", surname=" + this.surname + ", nationality="
				+ this.nationality + ", phone=" + this.phone + ", dni=" + this.dni + ", age=" + this.age + ", debts=" + this.debts + ", active="
				+ this.active + "]";
		*/
		String text = "";
		text += String.format("%-10S%-15S%-15S%-7S%-10S%-10S%-4d%-10.2f%-5B", accountNum, name, surname, nationality, phone, dni, age, debts, active);
		return text;
	}
	
	/** Cancel debts only for active client
	 * @return true if the debt is cancelled
	 */
	public boolean cancelDebts() {
		if (this.active) {
			this.debts = 0;
			return true;
		}
		return false;
	}
	
	/** Reduce debts only for active client and amounts > 0
	 * @param amount	the amount to reduce, it must be > 0
	 * @return  		true if the debt is reduced
	 */
	public boolean reduceDebts(float amount) {
		if (this.active && amount > 0) {
			if (this.debts - amount >= 0) {
				this.debts -= amount;
				return true;
			} else {
				this.debts = 0;
				return true;
			}
		}
		return false;
	}


	/**Increase debt of person, only if client is active an amount > 0
	 * @param amount	the amount to add to debt
	 * @return			true if the debt is increased
	 */
	public boolean increaseDebts(float amount) {
		if (this.active && amount > 0) {
			this.debts += amount;
			return true;
		} 
		return false;
	}
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((accountNum == null) ? 0 : accountNum.hashCode());
		result = prime * result + ((dni == null) ? 0 : dni.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof Client))
			return false;
		Client other = (Client) obj;
		if (accountNum == null) {
			if (other.accountNum != null)
				return false;
		} else if (!accountNum.equalsIgnoreCase(other.accountNum))
			return false;
		if (dni == null) {
			if (other.dni != null)
				return false;
		} else if (!dni.equalsIgnoreCase(other.dni))
			return false;
		return true;
	}
}
