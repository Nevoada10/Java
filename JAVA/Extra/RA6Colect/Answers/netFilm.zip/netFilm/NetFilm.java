/*
 * NetFilm.java        01.04.2021
 *
 *
 * Copyright 2020 Joan Seculi <jseculi@escoladeltreball.org>
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package netFilm;

import java.util.ArrayList;
import java.util.List;

import com.joanseculi.timejump.TimeJump;

public class NetFilm {
   
    private String name;
    private List<Client> clients;


    public NetFilm( String name) {
       
        this.name = name;
        this.clients = new ArrayList<Client>();
       
    }
   
  
    public List<Client> getClients() {
		return clients;
	}

	public void setClients(List<Client> clients) {
		this.clients = clients;
	}



    /**
     * Sign a subscriber.
     * 
     * @param client	client
     * @return true 	true if the client is added
     */
    public boolean signSubscription(Client client) {

    	//add only if client is not in the list
    	if (!this.clients.contains(client)) {
    		for (Client cl : clients) {
    			if (cl.getDni().equals(client.getDni())) {
    				return false;
    			}
    		}
    		return this.clients.add(client); // Sign subscription
    	} else {
    		return false;
    	}
    }
    
    /**
     * Count subscribers 
     * 
     * @return number of subscribers
     */
    public int countSubscriptions() {
    	
    	return this.clients.size();
    	
 
    }
    
    
    /**
     * End subscription of a client knowing the code
     * 
     * @param code	Client code
     * @param date	a date
     * @return true if the subscription is ended, false otherwise
     */
    public boolean endSubscription(String code, String date) {
    	
    	Client client = searchClient(code);
    	if (client != null) {
    		if (TimeJump.compareStringDates(date, client.getInitialDate()) >= 0 ) {
        		client.setEndDate(date);
        		return true;
        	}
    	}
    	return false;
    	
    }
    

    /**
     * Count subscribers on a certain date
     * 
     * @param date a date
     * @return number of subscribers
     */
    public int countSubscriptionsDate(String date) {
    	
    	int count = 0;
    	for (Client client : clients) {

    		if (TimeJump.compareStringDates(client.getInitialDate(), date) <= 0 
    				&& TimeJump.compareStringDates(client.getEndDate(), date) >= 0){
    			count++;
    		}
    	}
    	
        return count++;
    }


	
	/**
	 * Calculates the number of days of a subscription
	 * 
	 * @return the contract's number of days.
	 */
	public long duration(String code) {
		Client selectClient = searchClient(code);
    	
    	if (selectClient != null) {
    		return TimeJump.getDays(selectClient.getInitialDate(), selectClient.getEndDate());
    	}
		
		else return -1;
	}
	

	/**
	 *  Search a Client knowing the code
	 
	 * @param code 	Client code
	 * @return return the Client or null if code does not exist
	 */
	public Client searchClient(String code) {
		
    	for(Client c : clients) {
    		if(c.getCode().equals(code)) {
    			return c;
    		}
    	}
    	return null;
   
	}
	
	

	
	/**
	 * Get the monthly fee of a Client
	 * @param code 	Client code
	 * @return		the monthly fee of a client, -1 if the code does not exist
	 */
	public float getMonthlyFee(String code) {
		Client selectClient = searchClient(code);
		if (selectClient != null) {
			return selectClient.getSubscription().getFee();
		}
    	
    	return -1;
	}
	
	
    /**
     * List all active subscribers on a certain date
     * @param date	a date
     * @return a list of active subscribers
     */
    public List<Client> listActiveSubscriptions(String date) {
    	List<Client> activeClients = new ArrayList<Client>();
    	for (Client client : clients) {
    		if (TimeJump.compareStringDates(client.getInitialDate(), date) <= 0 
    				&& TimeJump.compareStringDates(client.getEndDate(), date) >= 0){
    			activeClients.add(client);
    		}
    	}
    	return activeClients;
    	
    	//Option 2:
		/*
		 * Date toDate; toDate = TimeClass.stringToDate(date);
		 * 
		 * List<Client> activeClients = new ArrayList<Client>(); 
		 * for (Client client : clients) {
		 * 
		 * Date init = TimeClass.stringToDate(client.getInitialDate()); 
		 * Date end = TimeClass.stringToDate(client.getEndDate());
		 * 
		 * if ( TimeClass.compare(init, toDate) <= 0 && TimeClass.compare(end, toDate) >= 0){ 
		 *     activeClients.add(client); 
		 *     } 
		 * } 
		 * 
		 * return activeClients;
		 */
    		
    	
    }
    
    /**
     * Change subscription of a client knowing the code if a date is between initial date and end date
     * @param code	Client code
     * @param date	a date
     * @param subscription
     * @return true if the subscription is changed
     */
    public boolean changeSubscription(String code, String date, Subscription subscription) {
    
    	Client client = searchClient(code);
    	
    	if (client != null) {
    		if(TimeJump.compareStringDates(date, client.getInitialDate()) >= 0 && 
    				TimeJump.compareStringDates(date, client.getEndDate()) <= 0	) {
        		client.setSubscription(subscription);
        		return true;
        	}
    	}

    	return false;
    }


	
    
    
    
   
	
	/**
	 * Total of amount that the company will get of all subscriptions on a specific date
	 * @param date	a date
	 * @return	total amount
	 */
	public float totalValue(String date) {	
		float total = 0;
    	for (Client client : clients) {
    		if (TimeJump.compareStringDates(client.getInitialDate(), date) <= 0 
    				&& TimeJump.compareStringDates(client.getEndDate(), date) >= 0){
    			total += client.getSubscription().getFee();
    		}
    	}
		return total;
	}

	/**
	 *
	 */
	@Override
	public String toString() {
		String text = "------------------------------------------------------------------------------------------------------------------------\n";
		text += String.format("%-15S%-20S%-15S%-15S%-15S%-15S%-15S%-15S\n", "CODE", "NAME", "DNI", "SUBSCR.", "INIT", "END", "IBAN", "BANK");
		text +=       "------------------------------------------------------------------------------------------------------------------------\n";
			
		for (Client client : clients) {
			text += client + "\n";
		}
		//return "NetFilm [code=" + code + ", name=" + name + ", clients=" + clients + "]";
		return text;
	}

//	public boolean removeClient(String code) {
//		for (Client client : clients) {
//			if (client.getCode().equals(code)) {
//				return this.clients.remove(client);
//			}
//		}
//		
//		return false;
//	}


}