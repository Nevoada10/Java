/*
 * Subscrition.java        01.04.2021
 *
 *
 * Copyright 2020 Joan Seculi <jseculi@escoladeltreball.org>
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package netFilm;

public enum Subscription {
	BASIC_ADVERTS (5.49f), BASIC (7.99f), STANDARD(9.99f), PREMIUM(15.99f);

	
	private final float fee;
	
	private Subscription(float fee) {
		this.fee = fee;
	}

	public float getFee() {
		return this.fee;
	}
}
