/*
 * NetFilmTest2.java 11 Mar 2023
 *
 *
 * \u00A9 Copyright 2023 Joan S�culi  
 * Email: jseculi@escoladeltreball.org
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package netFilm;

import java.util.List;
import java.util.Locale;
import java.util.Scanner;

import com.joanseculi.timejump.TimeJump;


public class NetFilmMain {

private static final byte DECIMALS = 2;
public static Scanner scanner = new Scanner(System.in).useLocale(Locale.UK);
	
	/**
	* The main method test all methods of the class
	*
	* @since   21/10/2021 
	* @param args 	args are not used 
	*/
	public static void main(String[] args)  {
	
		NetFilmMain p = new NetFilmMain();
		//Instantiate NetFilm
		NetFilm netFilm = p.loadClient("NETFILM");
		
		//Available banks
		Bank freeBank = new Bank("FreeBank", "FREEMMYES");
		Bank coolBank = new Bank("CoolBank", "COOLSSES");
		
		System.out.println(freeBank.toString());
		System.out.println(coolBank.toString());
		
		
		
		byte option = menu();
		if (option == 0) {
			System.out.println("Bye!");
		}
		while (option !=0 ) {
				switch (option) {
				case 1:
					System.out.println("1. SHOW ALL CLIENTS");
					System.out.println(netFilm.toString());
					
					
					break;
				case 2:
					scanner.nextLine();
					System.out.println("2. SIGN A NEW SUBSCRIPTION");
					
					
					//Request name
					String name = dataEntryString("ENTER NAME CLIENT: ");
					
					//Request dni
					String dni = dataEntryString("ENTER DNI CLIENT: ");
					
					//Show subscriptions  1. BASIC_ADVERT, 2. BASIC, 3. STANDARD  4. PREMIUM
					//Request subscriptions
					Subscription subscription;
					byte subs = dataEntryByteMinMax("SELECT SUBSCRIPTION: 1.BAISC_ADVERT, 2.BASIC, 3,STANDARD, 4.PREMIUM: ", (byte)1, (byte)4);
					if (subs == 1) 	{
						subscription = Subscription.BASIC_ADVERTS;
					} else if (subs == 2) {
						subscription = Subscription.BASIC;
					} else if (subs == 3) {
						subscription = Subscription.STANDARD;
					} else {
						subscription = Subscription.PREMIUM;
					}
					
					
					
					scanner.nextLine();
					//Request initialDate
					//Has de comprovar que es Valida o que est� buida!!!
					//If empty, assign TimeClass.todayDate()
					String initialDate = dataEntryDate("ENTER INITIAL DATE: ");
					
					if (initialDate.equals("")) {
						initialDate = TimeJump.todayDate();
					}
					
					//Request endDate
					//Has de comprovar que es Valida o que est� buida!!!
					//If empty, assign "31/12/9999"
					String endDate = dataEntryDate("ENTER END DATE: ");
					
					if (endDate.equals("")) {
						endDate = TimeJump.END_DATE;
					}
					
					
					//Request IBAN
					String iban = dataEntryString("ENTER IBAN: ");
					
					//Show list of banks  (for all banks 1. FREEBANK, 2. COOLBANK)
					//Request banks
					System.out.println("Select Bank:");
					Bank bank;
					byte selectBank = dataEntryByteMinMax("SELECT BANK: 1.FREEBANK, 2.COOLBANK: ", (byte)1, (byte)2);
					if (selectBank == 1) 	{
						bank = freeBank;
					} else {
						bank = coolBank;
					}
					
					//Instantiate client
					//Client c = new Client(...);
					Client newClient = new Client(name, dni, subscription, initialDate, endDate, iban, bank);
					
					
					//Call signSubscription
					//Retorna true or false
					//netfilm.signSubsctription(c);					
					netFilm.signSubscription(newClient);
					
					
					break;
				case 3:
					System.out.println("3. END A SUBSCRIPTION ON A DATE");
					scanner.nextLine();

					String code = dataEntryString("ENTER CODE CLIENT: ");
					
					endDate = dataEntryDate("ENTER END DATE: ");
					
					System.out.println("END SUBS.: " + netFilm.endSubscription(code, endDate));
					
					
					break;
				case 4:
					System.out.println("4. CHANGE SUBSCRIPTION OF A CLIENT ON A DATE");
					scanner.nextLine();

					code = dataEntryString("ENTER CODE CLIENT: ");
					
					String date = dataEntryDate("ENTER DATE: ");
					
					subs = dataEntryByteMinMax("SELECT SUBSCRIPTION: 1.BAISC_ADVERT, 2.BASIC, 3,STANDARD, 4.PREMIUM: ", (byte)1, (byte)4);
					
					if (subs == 1) 	{
						subscription = Subscription.BASIC_ADVERTS;
					} else if (subs == 2) {
						subscription = Subscription.BASIC;
					} else if (subs == 3) {
						subscription = Subscription.STANDARD;
					} else {
						subscription = Subscription.PREMIUM;
					}
					
					System.out.println("CHANGE SUBS.: " + netFilm.changeSubscription(code, date, subscription));
					
					break;
				
				case 5:
					System.out.println("5. COUNT ACTIVE SUBSCRITIONS ON A DATE");
					scanner.nextLine();
					date = dataEntryDate("ENTER DATE: ");
					System.out.println("NUM: " + netFilm.countSubscriptionsDate(date));
					
					break;
				case 6:
					System.out.println("6. DAYS OF SUBSCRIPTION");
					scanner.nextLine();
					code = dataEntryString("ENTER CODE CLIENT: ");
					System.out.println("NUM DAYS: " + netFilm.duration(code));
					
					break;
			
				case 7:
					scanner.nextLine();
					System.out.println("7. LIST ACTIVE SUBSCRIPTIONS ON A DATE");
					date = dataEntryDate("ENTER DATE: ");
					List<Client> activeSubscriptors = netFilm.listActiveSubscriptions(date);
					
					activeSubscriptors.forEach(System.out::println);
					
					break;
				case 8:
					scanner.nextLine();
					System.out.println("9. TOTAL VALUE ON A DATE");
					date = dataEntryDate("ENTER DATE: ");
					System.out.println("TOTAL VALUE: " + round(netFilm.totalValue(date), DECIMALS));
					break;
				case 9:
					scanner.nextLine();
					System.out.println("9. GET MONTLY FEE O A CLIENT");
					code = dataEntryString("ENTER CODE CLIENT: ");
					System.out.println("FEE: " + netFilm.getMonthlyFee(code));
					break;
					
			
				default:
					System.out.println(
							"WRONG ENTRY, PLEASE ENTER A NUMBER FROM 0 TO 13: ");
					break;
				}
				option = menu();
				if (option == 0) {
					System.out.println("Bye!");
				}
				
			}
			scanner.close();
	}

	private NetFilm loadClient(String name) {
		System.out.println("Instantiate NetFilm");
		NetFilm netFilm = new NetFilm(name);
		
		//Instantiate a Bank object
		System.out.println("Instantiate Bank");
		Bank freeBank = new Bank("FreeBank", "FREEMMYES");
		System.out.println(freeBank.toString());
		Bank coolBank = new Bank("CoolBank", "COOLSSES");
		System.out.println(freeBank.toString());
		
		
		//Instantiate clients
		System.out.println("Instantiate Clients");
		Client cl1 = new Client("Kate Winslet", "11111111A", Subscription.BASIC_ADVERTS, "01/01/2010", "31/12/2022", "ES001111", freeBank);
		Client cl2 = new Client("Timothée Chalamet", "22222222A", Subscription.BASIC, "01/02/2000", "28/02/2022", "ES002222", freeBank);
		Client cl3 = new Client("Viola Davis", "33333333A", Subscription.STANDARD, "01/01/2000", "31/01/2000", "ES003333", freeBank);
		Client cl4 = new Client("Chris Evans", "44444444A", Subscription.PREMIUM, "01/03/2001", "30/03/2001", "ES004444", freeBank);
		Client cl5 = new Client("Robert Downey Jr", "55555555A", Subscription.BASIC, "01/01/2021", "ES005555", freeBank);
		Client cl6 = new Client("Jennifer Lawrence", "66666666A", Subscription.BASIC, "01/01/2020", "ES006666", freeBank);
		Client cl7 = new Client("Channing Tatum", "77777777A", Subscription.STANDARD, "01/03/2000", "ES007777", coolBank);
		Client cl8 = new Client("Johnny Depp", "88888888A", Subscription.PREMIUM, "ES008888", coolBank);
		Client cl9 = new Client("Jared Leto", "99999999A", Subscription.PREMIUM, "ES009999", coolBank);
		Client cl10 = new Client("Kate Winslet", "00000000A", Subscription.BASIC_ADVERTS, "ES009999", coolBank);
		
		//Same dni
		Client cl11 = new Client("Cate Blanchett", "99999999A", Subscription.BASIC, "ES009999", freeBank);
		Client cl12 = new Client("Audrey Hepburn", "00000000A", Subscription.BASIC, "01/01/2000", "ES009999", freeBank);
				
		System.out.println("Print Clients");
		System.out.println(cl1.toString());
		System.out.println(cl2.toString());
		System.out.println(cl3.toString());
		System.out.println(cl4.toString());
		System.out.println(cl5.toString());
		System.out.println(cl6.toString());
		System.out.println(cl7.toString());
		System.out.println(cl8.toString());
		System.out.println(cl9.toString());
		System.out.println(cl10.toString());
		System.out.println(cl11.toString());  //Duplicated dni
		System.out.println(cl12.toString());  //Duplicated dni
		
		System.out.println("Sign Subscriptions");
		System.out.println(netFilm.signSubscription(cl1));
		System.out.println(netFilm.signSubscription(cl2));
		System.out.println(netFilm.signSubscription(cl3));
		System.out.println(netFilm.signSubscription(cl4));
		System.out.println(netFilm.signSubscription(cl5));
		System.out.println(netFilm.signSubscription(cl6));
		System.out.println(netFilm.signSubscription(cl7));
		System.out.println(netFilm.signSubscription(cl8));
		System.out.println(netFilm.signSubscription(cl9));
		System.out.println(netFilm.signSubscription(cl10));
		System.out.println(netFilm.signSubscription(cl11));
		System.out.println(netFilm.signSubscription(cl12));
		
		
		return netFilm;

	}
	public static byte menu() {
		System.out.println("MENU");
		System.out.println("1. SHOW ALL CLIENTS");
		System.out.println("2. SIGN A NEW SUBSCRIPTION");
		System.out.println("3. END A SUBSCRIPTION");
		System.out.println("4. CHANGE SUBSCRIPTION OF A CLIENT");
		System.out.println("5. COUNT ACTIVE SUBSCRITIONS");
		System.out.println("6. DAYS OF SUBSCRIPTION");
		System.out.println("7. LIST ACTIVE SUBSCRIPTIORS");
		System.out.println("8. TOTAL VALUE");
		System.out.println("9. GET MONTHLY FEE OF A CLIENT");
	
		
		System.out.println("0. QUIT");
		
		
		
		byte option = dataEntryByteMinMax("CHOOSE MENU OPTION: ", (byte)0, (byte)13);
		return option;
	}
	
	public static String dataEntryDate(String text) {
		String str = "";
		System.out.print(text);
		boolean isValid = false;
		while (!isValid) {
			str = scanner.nextLine();
			if(TimeJump.isValidDate(str) || str.isEmpty()) {
				isValid = true;
				
			}
			else System.out.print("Error! " + text);
		}
		return str;
	}
	
	
	public static byte dataEntryByteMinMax(String text, byte min, byte max) {
		byte number = 0;
		System.out.print(text);
		boolean isValid = false;
		while (!isValid) {
			if (scanner.hasNextByte()) {
				number = scanner.nextByte();
				if(number <= max && number >= min) {
					isValid = true;
				}
				else {
					
					System.out.print("Error! " + text);
				}
			} else {
				scanner.next();  //Consume next line
				System.out.print("Error! " + text);
			}
		}
		return number;
	}


	public static String dataEntryString(String text) {
		
		System.out.print(text);

		return scanner.nextLine();
	}
	
	   /* Round to a specific number of decimals
     * 
     * @param num   real number to round
     * @param dec   decimal numbers
     * @return 		the rounded number
     */
	public static double round(double num, byte dec) {
		return  Math.round(num * Math.pow(10.0, dec)) / Math.pow(10.0, dec);
	}
	
	
	
	public float roundFloat(float num, byte decimals) {
		return (int) (Math.round(num*Math.pow(10, decimals))) / (float)Math.pow(10, decimals);
	
	}
	
	
}
