/*
 * Client.java        01.04.2021
 *
 *
 * Copyright 2021 Joan Seculi <jseculi@escoladeltreball.org>
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package netFilm;

import com.joanseculi.timejump.TimeJump;

public class Client  {

//	private static final String END_DATE = "31/12/9999";
	private String code;
	private String name;
	private String dni;
	private Subscription subscription;
	/** initial date, with format DD/MM/YYYY. */
	private String initialDate;
	/** end date, with format DD/MM/YYYY. */
	private String endDate;
	private String iban;
	private Bank bank;
	
	private static int idNext = 1;


	/**
	 * @param name
	 * @param dni
	 * @param subscription
	 * @param iban
	 * @param bank
	 */
	public Client(String name, String dni, Subscription subscription, String iban, Bank bank) {
		this.code = generateCode(dni);
		this.name = name;
		this.dni = dni;
		this.subscription = subscription;
		this.iban = iban;
		this.bank = bank;
		this.initialDate = TimeJump.todayDate();
		this.endDate = TimeJump.END_DATE;

	}

	/**
	 * @param dni
	 * @return
	 */
	private String generateCode(String dni) {
		String text = String.format("%05d", idNext) + "-";
		
		if (dni.length() >= 4)
			text += dni.substring(dni.length() - 4, dni.length());
		else 
			text += dni;
		idNext++;
		return text;
	}


	/**
	 * @param name
	 * @param dni
	 * @param subscription
	 * @param initialDate
	 * @param endDate
	 * @param iban
	 * @param bank
	 */
	public Client(String name, String dni, Subscription subscription, String initialDate, String endDate, String iban, Bank bank) {
		this.code = generateCode(dni);
		this.name = name;
		this.dni = dni;
		this.subscription = subscription;
		this.initialDate = initialDate;
		this.endDate = endDate;
		this.iban = iban;
		this.bank = bank;

	}


	/**
	 * @param name
	 * @param dni
	 * @param subscription
	 * @param initialDate
	 * @param iban
	 * @param bank
	 */
	public Client( String name, String dni, Subscription subscription, String initialDate, String iban, Bank bank) {
		this.code = generateCode(dni);
		this.name = name;
		this.dni = dni;
		this.subscription = subscription;
		this.initialDate = initialDate;
		this.endDate = TimeJump.END_DATE;
		this.iban = iban;
		this.bank = bank;

	}



	
	/**
	 * @return
	 */
	public String getEndDate() {
		return this.endDate;
	}
/*
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + code;
		result = prime * result + ((dni == null) ? 0 : dni.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Client other = (Client) obj;
		if (code != other.code)
			return false;
		if (dni == null) {
			if (other.dni != null)
				return false;
		} else if (!dni.equals(other.dni))
			return false;
		return true;
	}
*/
	public String getInitialDate() {
		return this.initialDate;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDni() {
		return dni;
	}

	public void setDni(String dni) {
		this.dni = dni;
	}

	public String getIban() {
		return iban;
	}

	public void setIban(String iban) {
		this.iban = iban;
	}

	public Bank getBank() {
		return bank;
	}

	public void setBank(Bank bank) {
		this.bank = bank;
	}

	public void setInitialDate(String initialDate) {
		this.initialDate = initialDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public Subscription getSubscription() {
		return subscription;
	}

	public void setSubscription(Subscription subscription) {
		this.subscription = subscription;
	}

	@Override
	public String toString() {
		String text = "";
		text += String.format("%-15S%-20S%-15S%-15S%-15S%-15S%-15S%-15S", code, name,dni, subscription, initialDate, endDate, iban, bank.getName());
		
		//return "Client [code=" + code + ", name=" + name + ", dni=" + dni + ", subscription=" + subscription
		//		+ ", initialDate=" + initialDate + ", endDate=" + endDate + ", iban=" + iban + ", bank=" + bank + "]";
		return text;
	}

	

}
