/*
* NetFilmTest.java 1 Feb 2025
*
*
* © Copyright 2025 Joan Sèculi <jseculi@escoladeltreball.org>
*
* This is free software, licensed under the GNU General Public License v3.
* See http://www.gnu.org/licenses/gpl.html for more information.
*/
package netFilm;


import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class NetFilmTest {
    private NetFilm netFilm;
    private Bank freeBank, coolBank;
    private Client cl1, cl2, cl3, cl4, cl5, cl6, cl7, cl8, cl9, cl10, cl11, cl12;

    @BeforeEach
    void setUp() {
        netFilm = new NetFilm("NETFILM");
        
        freeBank = new Bank("FreeBank", "FREEMMYES");
        coolBank = new Bank("CoolBank", "COOLSSES");
        
        cl1 = new Client("Kate Winslet", "11111111A", Subscription.BASIC_ADVERTS, "01/01/2010", "31/12/2022", "ES001111", freeBank);
        cl2 = new Client("Timothée Chalamet", "22222222A", Subscription.BASIC, "01/02/2000", "28/02/2022", "ES002222", freeBank);
        cl3 = new Client("Viola Davis", "33333333A", Subscription.STANDARD, "01/01/2000", "31/01/2000", "ES003333", freeBank);
        cl4 = new Client("Chris Evans", "44444444A", Subscription.PREMIUM, "01/03/2001", "30/03/2001", "ES004444", freeBank);
        cl5 = new Client("Robert Downey Jr", "55555555A", Subscription.BASIC, "01/01/2021", "ES005555", freeBank);
        cl6 = new Client("Jennifer Lawrence", "66666666A", Subscription.BASIC, "01/01/2020", "ES006666", freeBank);
        cl7 = new Client("Channing Tatum", "77777777A", Subscription.STANDARD, "01/03/2000", "ES007777", coolBank);
        cl8 = new Client("Johnny Depp", "88888888A", Subscription.PREMIUM, "ES008888", coolBank);
        cl9 = new Client("Jared Leto", "99999999A", Subscription.PREMIUM, "ES009999", coolBank);
        cl10 = new Client("Kate Winslet", "00000000A", Subscription.BASIC_ADVERTS, "ES009999", coolBank);
        cl11 = new Client("Cate Blanchett", "99999999A", Subscription.BASIC, "ES009999", freeBank);
        cl12 = new Client("Audrey Hepburn", "00000000A", Subscription.BASIC, "01/01/2000", "ES009999", freeBank);

        System.out.println("Print Clients");
		System.out.println(cl1.toString());
		System.out.println(cl2.toString());
		System.out.println(cl3.toString());
		System.out.println(cl4.toString());
		System.out.println(cl5.toString());
		System.out.println(cl6.toString());
		System.out.println(cl7.toString());
		System.out.println(cl8.toString());
		System.out.println(cl9.toString());
		System.out.println(cl10.toString());
		System.out.println(cl11.toString());  //Duplicated DNI
		System.out.println(cl12.toString());  //Duplicated DNI
		
		
    
    }

    @Test
    @Order(1)
    void testSignSubscription() {
        assertTrue(netFilm.signSubscription(cl1));
        assertTrue(netFilm.signSubscription(cl2));
        assertTrue(netFilm.signSubscription(cl3));
        assertTrue(netFilm.signSubscription(cl4));
        assertTrue(netFilm.signSubscription(cl5));
        assertTrue(netFilm.signSubscription(cl6));
        assertTrue(netFilm.signSubscription(cl7));
        assertTrue(netFilm.signSubscription(cl8));
        assertTrue(netFilm.signSubscription(cl9));
        assertTrue(netFilm.signSubscription(cl10));
        
        assertFalse(netFilm.signSubscription(cl11)); // Same DNI
        assertFalse(netFilm.signSubscription(cl12)); // Same DNI
    }

    @Test
    @Order(2)
    void testCountSubscriptions() {
        netFilm.signSubscription(cl1);
        netFilm.signSubscription(cl2);
        assertEquals(2, netFilm.countSubscriptions());
    }

    @Test
    @Order(3)
    void testEndSubscription() {
        netFilm.signSubscription(cl1);
        assertTrue(netFilm.endSubscription(cl1.getCode(), "31/12/2022"));
        assertFalse(netFilm.endSubscription("99999-0000", "31/12/2022"));
    }

    @Test
    @Order(4)
    void testCountSubscriptionsDate() {
        netFilm.signSubscription(cl1);
        netFilm.signSubscription(cl2);
        assertEquals(2, netFilm.countSubscriptionsDate("01/01/2021"));
    }

    @Test
    @Order(5)
    void testListActiveSubscriptors() {
        netFilm.signSubscription(cl1);
        netFilm.signSubscription(cl2);
        List<Client> activeClients = netFilm.listActiveSubscriptions("01/01/2021");
        assertEquals(2, activeClients.size());
        assertTrue(netFilm.getClients().contains(cl1));
        assertTrue(netFilm.getClients().contains(cl2));
        
    }

    @Test
    @Order(6)
    void testChangeSubscription() {
        netFilm.signSubscription(cl1);
        assertTrue(netFilm.changeSubscription(cl1.getCode(), "01/01/2021", Subscription.PREMIUM));
        assertEquals(Subscription.PREMIUM, cl1.getSubscription());
    }

    @Test
    @Order(7)
    void testTotalValue() {
        netFilm.signSubscription(cl1);
        netFilm.signSubscription(cl2);
        float total = netFilm.totalValue("01/01/2021");
        assertEquals(5.49f + 7.99f, total, 0.01);
    }
    
    
    @Test
    @Order(8)
    void testDuration() {
        netFilm.signSubscription(cl1);
        netFilm.signSubscription(cl2);
        long days = netFilm.duration(cl1.getCode());
        assertEquals(days, 4748);
    }
}


