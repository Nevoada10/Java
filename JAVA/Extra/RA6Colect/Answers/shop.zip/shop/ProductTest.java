/*
* ProductTest.java 2 Feb 2025
*
*
* © Copyright 2025 Joan Sèculi <jseculi@escoladeltreball.org>
*
* This is free software, licensed under the GNU General Public License v3.
* See http://www.gnu.org/licenses/gpl.html for more information.
*/
package shop;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class ProductTest {
    private Product p1, p2, p3, p4, p5, p6, p7, p8, p9, p10;
    private Product p11, p12, p13, p14, p15, p16, p17, p18, p19, p20;

    @BeforeEach
    void setUp() {
        p1 = new Product("TSHIRT", Size.XXS, 30.25f, true);
        p2 = new Product("CAP", Size.XS, 25.75f, true);
        p3 = new Product("TROUSERS", Size.S, 30.25f, true);
        p4 = new Product("SKIRT", Size.M, 28.25f, true);
        p5 = new Product("GLOVES", Size.L, 32.35f, true);
        p6 = new Product("T", Size.XL, 23.79f, true);
        p7 = new Product("T", Size.XXL, 35.25f, true);
        p8 = new Product("JACKET", Size.XL, 59.97f, true);
        p9 = new Product("TSHIRT", Size.XS, 29.95f, true);
        p10 = new Product("LONG-SHIRT", Size.XS, 20.56f, true);
        p11 = new Product("TANK-TSHIRT", Size.XL, 16.55f, true);
        p12 = new Product("TSHIRT", Size.M, 29.15f, true);
        p13 = new Product("TANK-TSHIRT", Size.XXL, 24.45f, true);
        p14 = new Product("TSHIRT", Size.XS, 32.50f, true);
        p15 = new Product("LONG-SHIRT", Size.XS, 32.70f, false);
        p16 = new Product("SHIRT", Size.XS, 34.50f, false);
        p17 = new Product("T-SHIRT", Size.XS, 33.25f, false);
        p18 = new Product("SLEEVELESS-SHIRT", Size.XS, 32.50f, false);
        p19 = new Product("TSHIRT", Size.XS, 28.50f, false);
        p20 = new Product("TSHIRT", Size.S, 29.50f, false);
    }
    
    @Test
    @Order(1)
    void testGenerateId() {
        assertNotNull(p1.getId());
        assertEquals(p1.getId(), "00001-TSHIR-XXS");
        assertNotNull(p2.getId());
        assertEquals(p2.getId(), "00002-CAP-XS");
        assertNotNull(p3.getId());
        assertEquals(p3.getId(), "00003-TROUS-S");
        
    }

    @Test
    void testProductAttributes() {
        assertEquals("TSHIRT", p1.getName());
        assertEquals(Size.XXS, p1.getSize());
        assertTrue(p1.isActive());

        assertEquals("CAP", p2.getName());
        assertEquals(Size.XS, p2.getSize());
        assertTrue(p2.isActive());

        assertEquals("TROUSERS", p3.getName());
        assertEquals(Size.S, p3.getSize());
        assertTrue(p3.isActive());

        assertFalse(p15.isActive());
        assertFalse(p16.isActive());
    }

    @Test
    void testSetters() {
        p1.setName("NEW-TSHIRT");
        assertEquals("NEW-TSHIRT", p1.getName());

        p2.setSize(Size.L);
        assertEquals(Size.L, p2.getSize());

        p3.setPrice(40.00f);
        assertEquals(40.00f, p3.getPrice());

        p4.setActive(false);
        assertFalse(p4.isActive());
    }

   

    @Test
    void testToString() {
        String expected = "Product [id=" + p1.getId() + ", name=TSHIRT, size=XXS, price=" + p1.getPrice() + ", active=true]";
        assertEquals(expected, p1.toString());
    }

    @Test
    void testRoundMethod() {
        assertEquals(29.99f, Product.round(29.987f, (byte) 2));
        assertEquals(30.00f, Product.round(29.995f, (byte) 2));
    }
}
