/*
 * ExamenTest.java 24 Mar 2023
 *
 *
 * \u00A9 Copyright 2023 Joan S�culi
 * Email: jseculi@escoladeltreball.org
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package shop;

import java.util.List;
import java.util.Scanner;

public class ShopMain {

	public static void main(String[] args) {
		
		//1.Instantiate Shop
		System.out.println("1. Instantiate Shop:");
		Shop shop = new Shop("SHOP");
		
		//2.Instantiate Products
		System.out.println("\n2. Instantiate 20 Products with different sizes and prices:");
		
		Product p1 = new Product("TSHIRT", Size.XXS, 30.25f, true);
		Product p2 = new Product("CAP", Size.XS, 25.75f, true);
		Product p3 = new Product("TROUSERS", Size.S, 30.25f, true);
		Product p4 = new Product("SKIRT", Size.M, 28.25f, true);
		Product p5 = new Product("GLOVES", Size.L, 32.35f, true);
		Product p6 = new Product("T", Size.XL, 23.79f, true);
		Product p7 = new Product("T", Size.XXL, 35.25f, true);
		Product p8 = new Product("JACKET", Size.XL, 59.97f, true);
		Product p9 = new Product("TSHIRT", Size.XS, 29.95f, true);
		Product p10 = new Product("LONG-SHIRT", Size.XS, 20.56f, true);
		Product p11 = new Product("TANK-TSHIRT", Size.XL, 16.55f, true);
		Product p12 = new Product("TSHIRT", Size.M, 29.15f, true);
		Product p13 = new Product("TANK-TSHIRT", Size.XXL, 24.45f, true);
		Product p14 = new Product("TSHIRT", Size.XS, 32.50f, true);
		Product p15 = new Product("LONG-SHIRT", Size.XS, 32.70f, false);
		Product p16 = new Product("SHIRT", Size.XS, 34.50f, false);
		Product p17 = new Product("T-SHIRT", Size.XS, 33.25f, false);
		Product p18 = new Product("SLEEVELESS-SHIRT", Size.XS, 32.50f, false);
		Product p19 = new Product("TSHIRT", Size.XS, 28.50f, false);
		Product p20 = new Product("TSHIRT", Size.S, 29.50f, false);
		
		//3.Add products Shop
		System.out.println("\n3. Add products Shop:");
		System.out.println(shop.addProduct(p1));
		System.out.println(shop.addProduct(p2));
		System.out.println(shop.addProduct(p3));
		System.out.println(shop.addProduct(p4));
		System.out.println(shop.addProduct(p5));
		System.out.println(shop.addProduct(p6));
		System.out.println(shop.addProduct(p7));
		System.out.println(shop.addProduct(p8));
		System.out.println(shop.addProduct(p9));
		System.out.println(shop.addProduct(p10));
		System.out.println(shop.addProduct(p11));
		System.out.println(shop.addProduct(p12));
		System.out.println(shop.addProduct(p13));
		System.out.println(shop.addProduct(p14));
		System.out.println(shop.addProduct(p15));
		System.out.println(shop.addProduct(p16));
		System.out.println(shop.addProduct(p17));
		System.out.println(shop.addProduct(p18));
		System.out.println(shop.addProduct(p19));
		System.out.println(shop.addProduct(p20));
		
		//4.Print all products
		System.out.println("\n4. Print all products:");
		System.out.println(p1);
		System.out.println(p2);
		System.out.println(p3);
		System.out.println(p4);
		System.out.println(p5);
		System.out.println(p6);
		System.out.println(p7);
		System.out.println(p8);
		System.out.println(p9);
		System.out.println(p10);
		System.out.println(p11);
		System.out.println(p12);
		System.out.println(p13);
		System.out.println(p14);
		System.out.println(p15);
		System.out.println(p16);
		System.out.println(p17);
		System.out.println(p18);
		System.out.println(p19);
		System.out.println(p20);
		
		//5.Print Number Products
		System.out.println("\n5. Num Products:");
		System.out.println(shop.numProducts());
				
		
		//6. Get total price
		System.out.println("\n6. Get total");
		System.out.println(shop.total());
				
		
		
		//7. Get total of products
		System.out.println("\n7. Get total by size");
		System.out.println(shop.totalBySize(Size.XS));
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("1. XS, 2.S, 3.M, ... 6.XXL");
		byte option = scanner.nextByte();
		Size size = Size.XS;
		if (option == 1) size = Size.XS;
		else if (option == 2) size = Size.S;
		else size = Size.XXL;
		
		System.out.println(shop.totalBySize(size));
		
		//8. List products with name "SHIRT" and size "XS"
		System.out.println("\n8. List products with name \"SHIRT\" and size \"XS\":");
		
		//Opcio 1
		List<Product> list = shop.listProductsNameAndSize("SHIRT", Size.XS);
		
		for (Product p : list) {
			System.out.println(p);
		}
		
		//Opcio 2
		shop.listProductsNameAndSize("SHIRT", Size.XS).forEach(System.out::println);

		shop.listProductsNameAndSize("SHIRT", Size.XS).forEach(p -> System.out.println(p));
		
		//9. List products with name "t" and size "XL"
		System.out.println("\n9. List products with name \"t\" and size \"XL\":");
		shop.listProductsNameAndSize("t", Size.XL).forEach(System.out::println);
	
		//9.2 List with streams
		//System.out.println("\n9.2 List products with name \"t\" and size \"XL\" with streams:");
		//shop.listProductsNameAndSize2("t", Size.XL).forEach(System.out::println);
	
		
		//10. Remove a product by id
		System.out.println("\n10. Remove product by id");
		System.out.println(shop.removeProductById("00011-TANK--XL"));
		
		//List number of products
		System.out.println(shop.numProducts());
		

		//10.2 Remove a product by id stream
		//System.out.println("\n10.2 Remove product by id using stream");
		//System.out.println(shop.removeProductById2("00018-SLEEV-XS"));
		
		//List number of products
		//System.out.println(shop.numProducts());
		
		
		//11. Remove a product
		System.out.println("\n11. Remove product by object");
		System.out.println(shop.removeProduct(p18));
				
		//List number of products
		System.out.println(shop.numProducts());
							
		//12. Average active products
		System.out.println("\n12. Average acrive products");
		System.out.println(Product.round(shop.average(), (byte)2));
						
					
	}

}
