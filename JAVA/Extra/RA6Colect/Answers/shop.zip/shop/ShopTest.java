/*
* ShopTest.java 1 Feb 2025
*
*
* © Copyright 2025 Joan Sèculi <jseculi@escoladeltreball.org>
*
* This is free software, licensed under the GNU General Public License v3.
* See http://www.gnu.org/licenses/gpl.html for more information.
*/
package shop;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.List;

class ShopTest {

    private Shop shop;
    private Product p1, p2, p3, p4, p5, p6, p7, p8, p9, p10;

    @BeforeEach
    void setUp() {
        shop = new Shop("MyShop");
        p1 = new Product("TSHIRT", Size.XXS, 30.25f, true);
        p2 = new Product("CAP", Size.XS, 25.75f, true);
        p3 = new Product("TROUSERS", Size.S, 30.25f, true);
        p4 = new Product("SKIRT", Size.M, 28.25f, true);
        p5 = new Product("GLOVES", Size.L, 32.35f, true);
        p6 = new Product("T", Size.XL, 23.79f, true);
        p7 = new Product("T", Size.XXL, 35.25f, true);
        p8 = new Product("JACKET", Size.XL, 59.97f, true);
        p9 = new Product("TSHIRT", Size.XS, 29.95f, true);
        p10 = new Product("LONG-SHIRT", Size.XS, 20.56f, true);

        shop.addProduct(p1);
        shop.addProduct(p2);
        shop.addProduct(p3);
        shop.addProduct(p4);
        shop.addProduct(p5);
        shop.addProduct(p6);
        shop.addProduct(p7);
        shop.addProduct(p8);
        shop.addProduct(p9);
        shop.addProduct(p10);
    }

    @Test
    void testAddProduct() {
        Product p11 = new Product("TANK-TSHIRT", Size.XL, 16.55f, true);
        assertTrue(shop.addProduct(p11));
        assertEquals(11, shop.numProducts());
    }

    @Test
    void testRemoveProduct() {
        assertTrue(shop.removeProduct(p1));
        assertEquals(9, shop.numProducts());
    }

    @Test
    void testRemoveProductById() {
        String idToRemove = p3.getId();
        assertTrue(shop.removeProductById(idToRemove));
        assertEquals(9, shop.numProducts());
    }

    @Test
    void testTotalPrice() {
        float expectedTotal = p1.getPrice() + p2.getPrice() + p3.getPrice() + p4.getPrice() + p5.getPrice() +
                p6.getPrice() + p7.getPrice() + p8.getPrice() + p9.getPrice() + p10.getPrice();
        assertEquals(expectedTotal, shop.total(), 0.01);
    }

    @Test
    void testTotalBySize() {
        float expectedTotal = p2.getPrice() + p9.getPrice() + p10.getPrice();
        assertEquals(expectedTotal, shop.totalBySize(Size.XS), 0.01);
    }

    @Test
    void testListProductsNameAndSize() {
        List<Product> results = shop.listProductsNameAndSize("TSHIRT", Size.XXS);
        assertEquals(1, results.size());
        assertEquals("TSHIRT", results.get(0).getName());
    }

    @Test
    void testAveragePrice() {
        float expectedAvg = shop.total() / shop.numProducts();
        assertEquals(expectedAvg, shop.average(), 0.01);
    }
}