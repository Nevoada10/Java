/*
 * Shop.java 24 Mar 2023
 *
 *
 * \u00A9 Copyright 2023 Joan S�culi
 * Email: jseculi@escoladeltreball.org
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package shop;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Shop {
	
	private String name;
	private List<Product> products;
	
	public Shop(String name) {
		this.name = name;
		products = new ArrayList<Product>();
	}
	
	public boolean addProduct(Product product) {
		return products.add(product);

	}
	
	public boolean removeProduct(Product product) {
		
		return products.remove(product);
	}
	
	public boolean removeProductById(String id) {
		Product pr;
		for (Product p : products) {
			if(p.getId().equals(id)) {
				pr = p;
				return products.remove(pr);
			}
		}
		return false;
	}
	
	//El mateix però utilitzant expressions lambdas
	public boolean removeProductById2(String id) {
		int initialSize = products.size(); // Guardem la mida inicial

	    products = products.stream()
	            .filter(p -> !p.getId().equals(id))
	            .collect(Collectors.toList());

	    return products.size() < initialSize; // Retorna true si s'ha eliminat algun element
	}
	
	//El mateix però utilitzant expressions lambdas
	public boolean removeProductById3(String id) {
	
		return products.removeIf(p -> p.getId().equals(id));
	}
	
	
	
	public int numProducts() {
		return products.size();
	}
	
	//Utilitzant streams
	public float numProducts2() {
		
		return products.stream()
				.count();
	}

	public float total() {
		float total = 0;
		for (Product p : products) {
			total += p.getPrice();
		}
		return total;
	}
	
	//Utilitzant streams
	public float total2() {
		
		return (float)products.stream()
				.mapToDouble(p -> p.getPrice())
				.sum();
	}
	
	
	
	public float totalBySize(Size size) {
		float total = 0;
		for (Product p : products) {
			if (p.getSize() == size)
				total += p.getPrice();
		}
		return total;
	}
	
	//Utilitzant streams
	public float totalBySize2(Size size) {
		return (float)products.stream()
				.filter(p -> p.getSize() == size)
				.mapToDouble(p -> p.getPrice()).sum();
	}
	
	
	public List<Product> listProductsNameAndSize(String text, Size size) {
		List<Product> listP = new ArrayList<>();
		for (Product p : products) {
			if (p.isActive() 
					&& p.getName().toUpperCase().contains(text.toUpperCase()) 
					&& p.getSize() == size) {
				listP.add(p);
			}
		}
		return listP;
	}

	//El mateix però utilitzant expressions lambdas
	public List<Product> listProductsNameAndSize2(String text, Size size) {
		
		return products.stream()
				.filter(
						p -> (	p.isActive() &&  
								p.getName().toUpperCase().contains(text.toUpperCase()) &&
								p.getSize() == size))
				.collect(Collectors.toList());
		
		
	}
	
	public float average() {
		float avg = 0;
		for (Product p : products) {
			if (p.isActive())
			avg += p.getPrice();	
		}
		return avg / products.size();
	}
	
	public float average2() {
		return (float) products.stream()
                .filter(Product::isActive)  // Filtra només productes actius
                .mapToDouble(Product::getPrice) // Converteix a FloatStream per fer l'average()
                .average()  // Retorna un OptionalFloat
                .orElse(0.0);  // Si no hi ha productes actius, retorna 0
	}
	
}
