/*
 * ExamenTest.java 24 Mar 2023
 *
 *
 * \u00A9 Copyright 2023 Joan Seculi
 * Email: jseculi@escoladeltreball.org
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package shop;

public class ShopMainAlumne {

	public static void main(String[] args) {
		
		//1.Instantiate Shop
		System.out.println("1. Instantiate Shop:");
		
		//2.Instantiate Products
		System.out.println("\n2. Instantiate 20 Products with different sizes and prices:");
		
		//3.Add products Shop
		System.out.println("\n3. Add products Shop:");

		
		//4.Print all products
		System.out.println("\n4. Print all products:");
		
		//5.Print Number Products
		System.out.println("\n5. Num Products:");
				
		
		//6. Get total price
		System.out.println("\n6. Get total");			
		
		//7. Get total of products
		System.out.println("\n7. Get total by size");
		
		//8. List products with name contains "SHIRT" and size "XS"
		System.out.println("\n8. List products with name \"SHIRT\" and size \"XS\":");

		//9. List products with name contains "t" and size "XL"
		System.out.println("\n9. List products with name \"t\" and size \"XL\":");
	
		
		//10. Remove a product by id
		System.out.println("\n10. Remove product by id");
		
		//Print number of products
		
		//11. Remove a product
		System.out.println("\n11. Remove product by object");
				
		//Print number of products
							
	}
}
