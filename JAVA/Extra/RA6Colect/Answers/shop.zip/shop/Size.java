/*
 * Size.java 28 Mar 2023
 *
 *
 * \u00A9 Copyright 2023 Joan S�culi
 * Email: jseculi@escoladeltreball.org
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package shop;

public enum Size {
	XXS(0f),
	XS(0f),
	S(0f),
	M(0f),
	L(1.05f),
	XL(1.75f),
	XXL(2.55f);
	
	private float extraPrice;

	private Size(float extraPrice) {
		this.extraPrice = extraPrice;
	}

	public float getExtraPrice() {
		return extraPrice;
	}
	
	
}
