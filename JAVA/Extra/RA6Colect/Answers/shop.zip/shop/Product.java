/*
 * Product.java 24 Mar 2023
 *
 *
 * \u00A9 Copyright 2023 Joan Seculi
 * Email: jseculi@escoladeltreball.org
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package shop;

public class Product {	
	private String id;
	private String name;
	private Size size;
	private float price;
	private boolean active;
	
	private static int idNext = 1;
	
	public Product(String name, Size size, float price, boolean active) {
		this.name = name;
		this.size = size;
		this.price = round(price + size.getExtraPrice(), (byte)2);
		this.active = active;
		id = generateId();
		
	}
	
	public static float round(float price, byte dec) {
		return (int) (Math.round(price*Math.pow(10, dec))) / (float)Math.pow(10, dec);
	
	}

	private String generateId() {
		String text = "";
		String nameSubString = name.length() >=5 ? name.substring(0,5) : name;
		text += String.format("%05d-%S-%S", idNext, nameSubString, size);
		idNext++;
		return text;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Size getSize() {
		return size;
	}

	public void setSize(Size size) {
		this.size = size;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public String getId() {
		return id;
	}

	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", size=" + size + ", price=" + round(price, (byte)2) + 
				", active=" + active + "]";
	}
	

}
