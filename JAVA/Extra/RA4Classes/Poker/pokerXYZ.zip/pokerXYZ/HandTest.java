/*
* HandTest.java 28 Jan 2025
*
*
* © Copyright 2025 Joan Sèculi <jseculi@escoladeltreball.org>
*
* This is free software, licensed under the GNU General Public License v3.
* See http://www.gnu.org/licenses/gpl.html for more information.
*/
package pokerXYZ;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class HandTest {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

    @Test
    public void testHandInitialization() {
        Hand hand = new Hand();
        
        // Comprovar que les cartes inicials són null
        for (Card card : hand.getCards()) {
            assertNull(card);
        }
    }

    @Test
    public void testSetCards() {
        Hand hand = new Hand();
        Card[] cards = new Card[5];
        cards[0] = new Card(Suit.HEARTS, Value.ACE);
        cards[1] = new Card(Suit.DIAMONDS, Value.KING);
        cards[2] = new Card(Suit.CLUBS, Value.QUEEN);
        cards[3] = new Card(Suit.SPADES, Value.JACK);
        cards[4] = new Card(Suit.HEARTS, Value.TEN);

        hand.setCards(cards);

        // Comprovar que les cartes s'han assignat correctament
        assertArrayEquals(cards, hand.getCards());
    }

    @Test
    public void testAddCard() {
        Hand hand = new Hand();
        Card card = new Card(Suit.HEARTS, Value.ACE);

        hand.addCard(0, card);

        // Comprovar que la carta s'ha afegit correctament
        assertEquals(card, hand.getCards()[0]);
    }

    @Test
    public void testToString() {
        Hand hand = new Hand();
        Card[] cards = new Card[5];
        cards[0] = new Card(Suit.HEARTS, Value.ACE);
        cards[1] = new Card(Suit.DIAMONDS, Value.KING);
        cards[2] = new Card(Suit.CLUBS, Value.QUEEN);
        cards[3] = new Card(Suit.SPADES, Value.JACK);
        cards[4] = new Card(Suit.HEARTS, Value.TEN);

        hand.setCards(cards);

        // Comprovar que el mètode toString retorna una representació esperada
        String expected = "[HEARTS A, DIAMONDS K, CLUBS Q, SPADES J, HEARTS 10]";
        assertEquals(expected, hand.toString());
    }

}
