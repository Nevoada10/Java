/*
* PokerTest.java 28 Jan 2025
*
*
* © Copyright 2025 Joan Sèculi <jseculi@escoladeltreball.org>
*
* This is free software, licensed under the GNU General Public License v3.
* See http://www.gnu.org/licenses/gpl.html for more information.
*/
package pokerXYZ;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class PokerTest {


    private Poker poker;
    private Player[] players;

    @BeforeEach
    public void setUp() {
        players = new Player[] {
            new Player("Alice", "Smith"),
            new Player("Bob", "Brown"),
            new Player("Charlie", "Johnson")
        };
        poker = new Poker(players);
    }

    @Test
    public void testInitialization() {
        poker.initialize();

        for (Player player : players) {
           // assertNull(player.getHand());
            assertEquals(0, player.getPoints());
        }
    }

    @Test
    public void testGiveCard() {
        Card card = poker.giveCard();

        // Comprovar que la carta generada no és nul·la
        assertNotNull(card);
        assertNotNull(card.getSuit());
        assertNotNull(card.getValue());
    }

    @Test
    public void testGiveHand() {
        Player player = players[0];
        Hand hand = poker.giveHand(player);

        // Comprovar que el jugador ha rebut una mà amb 5 cartes
        assertNotNull(hand);
        assertEquals(5, hand.getCards().length);

        for (Card card : hand.getCards()) {
            assertNotNull(card);
        }

        // Comprovar que la mà s'ha assignat al jugador
        assertEquals(hand, player.getHand());
    }

    @Test
    public void testGetRank() {
        Player player = players[0];
        poker.giveHand(player);

        int rank = poker.getRank(player);

        // Comprovar que el rang del jugador coincideix amb la suma de les cartes
        int expectedRank = 0;
        for (Card card : player.getHand().getCards()) {
            expectedRank += card.getValue().getNumber();
        }

        assertEquals(expectedRank, rank);
        assertEquals(expectedRank, player.getPoints());
    }

    @Test
    public void testOrderClassification() {
        // Assignar punts als jugadors per fer proves
        players[0].setPoints(50);
        players[1].setPoints(100);
        players[2].setPoints(75);

        Player[] orderedPlayers = poker.orderClassification();

        // Comprovar que els jugadors estan ordenats correctament
        assertEquals(players[1], orderedPlayers[0]); // Bob amb 100 punts
        assertEquals(players[2], orderedPlayers[1]); // Charlie amb 75 punts
        assertEquals(players[0], orderedPlayers[2]); // Alice amb 50 punts
    }

    @Test
    public void testToString() {
        String pokerString = poker.toString();

        // Comprovar que la representació en cadena inclou tots els jugadors
        for (Player player : players) {
            assertTrue(pokerString.contains(player.getCode()));
        }
    }

}
