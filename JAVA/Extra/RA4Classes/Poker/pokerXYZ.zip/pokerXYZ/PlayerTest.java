/*
* PlayerTest.java 28 Jan 2025
*
*
* © Copyright 2025 Joan Sèculi <jseculi@escoladeltreball.org>
*
* This is free software, licensed under the GNU General Public License v3.
* See http://www.gnu.org/licenses/gpl.html for more information.
*/
package pokerXYZ;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class PlayerTest {

	 @BeforeEach
	    public void resetIdNext() {
	        // Reset the static idNext counter before each test
	        Player.setIdNext(1);
	    }

	    @Test
	    public void testPlayerInitialization() {
	        Player player = new Player("John", "Doe");

	        // Comprovar que el nom, cognom i codi s'han assignat correctament
	        assertEquals("John", player.getFirstName());
	        assertEquals("Doe", player.getLastName());
	        assertEquals("001-JD", player.getCode());

	        // Comprovar que la mà està inicialitzada correctament
	        assertNotNull(player.getHand());
	    }

	    @Test
	    public void testGenerateCode() {
	        Player player1 = new Player("Alice", "Smith");
	        Player player2 = new Player("Bob", "Brown");

	        // Comprovar que els codis generats són únics i correctes
	        assertEquals("001-AS", player1.getCode());
	        assertEquals("002-BB", player2.getCode());
	    }

	    @Test
	    public void testSetAndGetPoints() {
	        Player player = new Player("John", "Doe");

	        player.setPoints(50);

	        // Comprovar que els punts s'han assignat correctament
	        assertEquals(50, player.getPoints());
	    }

	    @Test
	    public void testShowCards() {
	        Player player = new Player("John", "Doe");

	        // Afegir cartes a la mà del jugador
	        Hand hand = player.getHand();
	        hand.addCard(0, new Card(Suit.HEARTS, Value.ACE));
	        hand.addCard(1, new Card(Suit.DIAMONDS, Value.KING));
	        hand.addCard(2, new Card(Suit.CLUBS, Value.QUEEN));
	        hand.addCard(3, new Card(Suit.SPADES, Value.JACK));
	        hand.addCard(4, new Card(Suit.HEARTS, Value.TEN));

	        // Comprovar que el mètode showCards retorna la representació esperada
	        String expected = "[HEARTS A, DIAMONDS K, CLUBS Q, SPADES J, HEARTS 10]";
	        assertEquals(expected, player.showCards());
	    }

	    @Test
	    public void testToString() {
	        Player player = new Player("John", "Doe");
	        player.setPoints(100);

	        // Comprovar que el mètode toString retorna la cadena esperada
	        assertEquals("001-JD 100", player.toString());
	    }

}
