/*
* Player.java 27 Jan 2025
*
*
* © Copyright 2025 Joan Sèculi <jseculi@escoladeltreball.org>
*
* This is free software, licensed under the GNU General Public License v3.
* See http://www.gnu.org/licenses/gpl.html for more information.
*/
package pokerXYZ;


public class Player {
	private String code;
	private String firstName;
	private String lastName;
	private int points;
	private Hand hand;
	
	
	

}
