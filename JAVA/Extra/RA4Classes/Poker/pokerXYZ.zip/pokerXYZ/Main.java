/*
* Main.java 27 Jan 2025
*
*
* © Copyright 2025 Joan Sèculi <jseculi@escoladeltreball.org>
*
* This is free software, licensed under the GNU General Public License v3.
* See http://www.gnu.org/licenses/gpl.html for more information.
*/
package pokerXYZ;


public class Main {
    // Test main
    public static void main(String[] args) {
    	
    	//1. Card
    	System.out.println("1. Card");
    	//1.1 Instantiate a card "ACE of HEARTS"
    	System.out.println("1.1 Instantiate a Card \"ACE of HEARTS\"");
       
        //1.2 Show card
        System.out.println("1.2 Show card");
        
        //1.3 Instantiate a card "THREE of SPADES"
    	System.out.println("1.3 Instantiate a Card \"THREE of SPADES\"");
       
        
        //1.4 Show card
    	System.out.println("1.4 Show card");
        
        
        
        //1.5 Instantiate a Card "FIVE of CLUBS"
    	System.out.println("1.5 Instantiate a Card \"FIVE of CLUBS\"");
        
        //1.6 Show card
    	System.out.println("1.6 Show card");
        
        
        //1.7 Instantiate a Card "KING of DIAMONDS"
    	System.out.println("1.7 Instantiate a Card \"KING of DIAMONDS\"");
        
        //1.8 Show card
    	System.out.println("1.8 Show card");
        
        
        
        //1.9 Instantiate a Card "KING of CLUBS"
    	System.out.println("1.9 Instantiate a Card \"KING of CLUBS\"");
        
        //1.10 Show card
    	System.out.println("1.10 Show card");
        
        
        //1.11 Show number and code of card
        System.out.println("1.11 Show number and code of card");
        
        
        //2. Hand
        System.out.println("\n2. Hand");
        //2.1 Instantiate a Hand
        System.out.println("\\n2.1 Instantiate a Hand");
        
        //2.2 Create an array of 5 Card
        System.out.println("\\n2.2 Create an array of 5 cards");
       
        
        //2.3 assign the 5 cards to hand
        System.out.println("\n2.3 Assign the 5 cards to hand");
        
        
        //2.4 Show hand
        System.out.println("\n2.4 Show hand");
        
        
        
        
        
        //3. Player
        System.out.println("\n3. Player");
        //3.1 Instantiate 2 players
        System.out.println("\n3.1 Instantiate 3 players");
        
        
        //3.2 Show players
        System.out.println("\n3.2 Instantiate 3 players");
      
        
        //3.3 Create an array of 3 players
        System.out.println("\n3.3 Create an array of 3 players");
        

        //4. Poker
        System.out.println("\n4. Poker");
        //4.1 Instantiate Poker with 2 players
        System.out.println("\n4.1 Instantiate Poker with 3 players");
        
        
        //4.2 Show poker
        System.out.println("\n4.2 Show poker");
        
        
        
        //4.3 Initialize poker
        System.out.println("4.3 Initialize poker");
        
        
        //4.4 Show poker
        System.out.println("\n4.4 Show poker");
        
        
        //4.5 Give a hand to player
        System.out.println("\n4.5 Give a hand to players");
       
        
        
        //4.6 Show player cards
        System.out.println("\n4.6 Show player cards");
       
        
        //4.7 Get rank of players
        System.out.println("\n4.7 Get rank of players");
      
        
        
        //4.8 Show players
        System.out.println("\n4.8 Show players");
       
        
        //4.9 Show players order by points
        System.out.println("\n4.9 Show players order by points");
        
        
    }
}
