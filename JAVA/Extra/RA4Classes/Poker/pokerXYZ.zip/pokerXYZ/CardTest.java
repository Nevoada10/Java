/*
* CardTest.java 28 Jan 2025
*
*
* © Copyright 2025 Joan Sèculi <jseculi@escoladeltreball.org>
*
* This is free software, licensed under the GNU General Public License v3.
* See http://www.gnu.org/licenses/gpl.html for more information.
*/
package pokerXYZ;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CardTest {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
    public void testCardCreation() {
        Card card = new Card(Suit.HEARTS, Value.ACE);
        
        // Comprovar si els valors de Suit i Value són correctes
        assertEquals(Suit.HEARTS, card.getSuit());
        assertEquals(Value.ACE, card.getValue());
    }

    @Test
    public void testCardToString() {
        Card card = new Card(Suit.SPADES, Value.KING);
        
        // Comprovar si el mètode toString retorna la cadena esperada
        assertEquals("SPADES K", card.toString());
    }

    @Test
    public void testValueProperties() {
        Value value = Value.QUEEN;
        
        // Comprovar el número associat
        assertEquals(12, value.getNumber());

        // Comprovar el codi associat
        assertEquals("Q", value.getCode());
    }

    @Test
    public void testSuitEnum() {
        // Comprovar que els valors del Suit existeixen correctament
        assertNotNull(Suit.HEARTS);
        assertNotNull(Suit.DIAMONDS);
        assertNotNull(Suit.CLUBS);
        assertNotNull(Suit.SPADES);
    }

}
