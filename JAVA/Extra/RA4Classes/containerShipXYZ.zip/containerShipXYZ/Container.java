/*
* Container.java 6 Feb 2025
*
*
* © Copyright 2025 Joan Sèculi <jseculi@escoladeltreball.org>
*
* This is free software, licensed under the GNU General Public License v3.
* See http://www.gnu.org/licenses/gpl.html for more information.
*/
package containerShipXYZ;


class Container {
    private String id; // Unique id CONT0001, CONT0002, etc.
    private int location;
    private int weight; // Weight in kg
    private ContainerType type; // Type of container
    private double transportCost; // transport price  
    
    
}
