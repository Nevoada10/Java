/*
* ContainerTest.java 7 Feb 2025
*
*
* © Copyright 2025 Joan Sèculi <jseculi@escoladeltreball.org>
*
* This is free software, licensed under the GNU General Public License v3.
* See http://www.gnu.org/licenses/gpl.html for more information.
*/
package containerShipXYZ;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.ClassOrderer.OrderAnnotation;



import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class ContainerTest {
    private static Container c1, c2, c3, c4, c5, c6, c7, c8, c9, c10;

    @BeforeAll
    static void setUpBeforeClass() throws Exception {  
    	c1 = new Container(1500, ContainerType.STANDARD);
        c2 = new Container(2000, ContainerType.FREEZE);
        c3 = new Container(2500, ContainerType.TANK);
        c4 = new Container(2200, ContainerType.OPEN_TOP);
        c5 = new Container(2100, ContainerType.STANDARD);
        c6 = new Container(1600, ContainerType.FREEZE);
        c7 = new Container(1800, ContainerType.TANK);
        c8 = new Container(2300, ContainerType.OPEN_TOP);
        c9 = new Container(2500, ContainerType.STANDARD);
        c10 = new Container(1500, ContainerType.FREEZE);
    }
    
    @BeforeEach
    void setUp() {
        
    }

    @Test
    @Order(1)
    void testIdGeneration() {
        assertEquals("CONT0001", c1.getId());
        assertEquals("CONT0002", c2.getId());
        assertEquals("CONT0003", c3.getId());
        assertEquals("CONT0004", c4.getId());
        assertEquals("CONT0005", c5.getId());
        assertEquals("CONT0006", c6.getId());
        assertEquals("CONT0007", c7.getId());
        assertEquals("CONT0008", c8.getId());
        assertEquals("CONT0009", c9.getId());
        assertEquals("CONT0010", c10.getId());
    }

    @Test
    @Order(2)
    void testInitialLocation() {
        assertEquals(-1, c1.getLocation());
        assertEquals(-1, c2.getLocation());
    }

    @Test
    @Order(3)
    void testWeightAssignment() {
        assertEquals(1500, c1.getWeight());
        assertEquals(2000, c2.getWeight());
    }

    @Test
    @Order(4)
    void testContainerType() {
        assertEquals(ContainerType.STANDARD, c1.getType());
        assertEquals(ContainerType.FREEZE, c2.getType());
    }

    @Test
    @Order(5)
    void testTransportCostCalculation() {
        assertEquals(1000.0, c1.getTransportCost());
        assertEquals(1200.0, c2.getTransportCost());
        assertEquals(1000.0, c3.getTransportCost());
        assertEquals(1200.0, c4.getTransportCost());
        assertEquals(1000.0, c5.getTransportCost());
        assertEquals(1200.0, c6.getTransportCost());
        assertEquals(1000.0, c7.getTransportCost());
        assertEquals(1200.0, c8.getTransportCost());
        assertEquals(1000.0, c9.getTransportCost());
        assertEquals(1200.0, c10.getTransportCost());
    }
    
    @Test
    @Order(5)
    void testToStringNotNull() {
        assertNotNull(c1.toString());
        assertNotNull(c2.toString());
        assertNotNull(c3.toString());
        assertNotNull(c4.toString());
        assertNotNull(c5.toString());
        assertNotNull(c6.toString());
        assertNotNull(c7.toString());
        assertNotNull(c8.toString());
        assertNotNull(c9.toString());
        assertNotNull(c10.toString());
    }
    
    @Test
    @Order(6)
    void testToString() {
    	System.out.println(c1);
        assertTrue(c1.toString().contains("CONT0001") && c1.toString().contains("-1") && c1.toString().contains("1500") && c1.toString().contains("STANDARD") && c1.toString().contains("1000.0"));
        assertTrue(c1.toString().contains("  CONT0001        -1      1500  STANDARD    1000.0"));
        
        assertTrue(c2.toString().contains("CONT0002") && c2.toString().contains("-1") && c2.toString().contains("2000") && c2.toString().contains("FREEZE") && c2.toString().contains("1200.0"));
        assertTrue(c2.toString().contains("  CONT0002        -1      2000    FREEZE    1200.0"));
        
    }
}
