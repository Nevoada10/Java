/*
* RouteTest.java 7 Feb 2025
*
*
* © Copyright 2025 Joan Sèculi <jseculi@escoladeltreball.org>
*
* This is free software, licensed under the GNU General Public License v3.
* See http://www.gnu.org/licenses/gpl.html for more information.
*/
package containerShipXYZ;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class RouteTest {

	//private static Container c1, c2, c3, c4, c5, c6, c7, c8, c9, c10;
	private static ContainerShip ship;
	private static Route r1;

	
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
//		c1 = new Container(1500, ContainerType.STANDARD);
//		c2 = new Container(2000, ContainerType.FREEZE);
//		c3 = new Container(2500, ContainerType.TANK);
//		c4 = new Container(2200, ContainerType.OPEN_TOP);
//		c5 = new Container(2100, ContainerType.STANDARD);
//		c6 = new Container(1600, ContainerType.FREEZE);
//		c7 = new Container(1800, ContainerType.TANK);
//		c8 = new Container(2300, ContainerType.OPEN_TOP);
//		c9 = new Container(2500, ContainerType.STANDARD);
//		c10 = new Container(1500, ContainerType.FREEZE);

		ship = new ContainerShip("Ever Given", 25, 15000, 10);
		r1 = new Route("Lisboa", "Buenos Aires", 9600, ship);
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

    @Test
    @Order(1)
    void testGetTime() {
        double expectedTime = 207.3434;
        assertEquals(expectedTime, r1.getTime(), 0.01);
    }
}


