/*
* ContainerTestTest.java 7 Feb 2025
*
*
* © Copyright 2025 Joan Sèculi <jseculi@escoladeltreball.org>
*
* This is free software, licensed under the GNU General Public License v3.
* See http://www.gnu.org/licenses/gpl.html for more information.
*/
package containerShipXYZ;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class ContainerShipTest {

	private static Container c1, c2, c3, c4, c5, c6, c7, c8, c9, c10;
    private static ContainerShip ship;

    
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		c1 = new Container(1500, ContainerType.STANDARD);
		c2 = new Container(2000, ContainerType.FREEZE);
		c3 = new Container(2500, ContainerType.TANK);
		c4 = new Container(2200, ContainerType.OPEN_TOP);
		c5 = new Container(2100, ContainerType.STANDARD);
		c6 = new Container(1600, ContainerType.FREEZE);
		c7 = new Container(1800, ContainerType.TANK);
		c8 = new Container(2300, ContainerType.OPEN_TOP);
		c9 = new Container(2500, ContainerType.STANDARD);
		c10 = new Container(1500, ContainerType.FREEZE);

	    ship = new ContainerShip("Ever Given", 25, 15000, 10);
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	
	
    @Test
    @Order(1)
    void testAddContainersToShip() {
        assertTrue(ship.addContainer(c1));
        assertEquals(1, c1.getLocation());
        
        assertTrue(ship.addContainer(c2));
        assertEquals(2, c2.getLocation());
        
        assertTrue(ship.addContainer(c3));
        assertEquals(3, c3.getLocation());
        
        assertTrue(ship.addContainer(c4));
        assertEquals(4, c4.getLocation());
        
        assertTrue(ship.addContainer(c5));
        assertEquals(5, c5.getLocation());
        
        assertTrue(ship.addContainer(c6));
        assertEquals(6, c6.getLocation());
        
        assertTrue(ship.addContainer(c7));
        assertEquals(7, c7.getLocation());
        
        assertFalse(ship.addContainer(c8)); // Should fail due to weight limit
        assertEquals(-1, c8.getLocation());
        
        assertFalse(ship.addContainer(c9)); // Should fail due to weight limit
        assertEquals(-1, c9.getLocation());
        
        assertFalse(ship.addContainer(c10)); // Should fail due to weight limit
        assertEquals(-1, c10.getLocation());
    }
    
    @Test
    @Order(2)
    void testAddContainersToShip2() {
        ship.addContainer(c1);
        ship.addContainer(c2);
        ship.addContainer(c3);
        ship.addContainer(c4);
        ship.addContainer(c5);
        ship.addContainer(c6);
        ship.addContainer(c7);
        ship.addContainer(c8);
        ship.addContainer(c9);
        
        assertEquals(7, ship.getNumContainers());
        assertEquals(13700, ship.getCurrentWeight());
        assertEquals(7600.0, ship.totalTransportCost());
        
        assertFalse(ship.addContainer(c10)); // Should fail due to weight limit
        assertEquals(-1, c10.getLocation());
    }

    @Test
    @Order(3)
    void testOrderContainers() {
        ship.addContainer(c1);
        ship.addContainer(c2);
        ship.addContainer(c3);
        ship.addContainer(c4);
        ship.addContainer(c5);
        ship.addContainer(c6);
        ship.addContainer(c7);
        ship.addContainer(c8);
        ship.addContainer(c9);
        
        Container[] ordered = ship.orderContainers();
        assertNotNull(ordered);
        for (int i = 0; i < ordered.length - 1; i++) {
            if (ordered[i] != null && ordered[i + 1] != null) {
                assertTrue(ordered[i].getWeight() <= ordered[i + 1].getWeight());
            }
        }
    }

}
