/*
* Route.java 6 Feb 2025
*
*
* © Copyright 2025 Joan Sèculi <jseculi@escoladeltreball.org>
*
* This is free software, licensed under the GNU General Public License v3.
* See http://www.gnu.org/licenses/gpl.html for more information.
*/
package containerShipXYZ;

public class Route {
	private String origin;
	private String destination;
	private float distance;
	private ContainerShip ship;
	
}
