/*
* ContainerShip.java 6 Feb 2025
*
*
* © Copyright 2025 Joan Sèculi <jseculi@escoladeltreball.org>
*
* This is free software, licensed under the GNU General Public License v3.
* See http://www.gnu.org/licenses/gpl.html for more information.
*/
package containerShipXYZ;

import java.util.Arrays;

class ContainerShip {
    private String name;
    private Container[] containers;
    private int numContainers;
    private int currentWeight;
    private float maxSpeed;  //knots = nusos => 1 nus = 1.852 km / h
    private int maxWeight;
    private int nextLocation;

  
}