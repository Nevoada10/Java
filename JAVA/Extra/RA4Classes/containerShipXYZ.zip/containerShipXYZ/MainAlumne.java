/*
* MainAlumne.java 6 Feb 2025
*
*
* © Copyright 2025 Joan Sèculi <jseculi@escoladeltreball.org>
*
* This is free software, licensed under the GNU General Public License v3.
* See http://www.gnu.org/licenses/gpl.html for more information.
*/
package containerShipXYZ;

public class MainAlumne {
	public static void main(String[] args) {
		
		//1. Create container Ship
		
        //System.out.println(ship);
        
        //2.1 Instantiate Containers
        
        //2.2 Print containers
         
        //3.1 Add container c1
       
        //3.2 Check weight containership 
        
        //4.1 Add container c2
        
        //4.2 Check weight containership 
        
        //5.1 Add container c3
        
        //5.2 Check weight containership 
        
        
        //6.1 Add container c4
        
        //6.2 Check weight containership 
        
        //6.1 Add container c5
        
        
        //6.2 Check weight containership 
        
        
        //7.1 Add container c6
        
        //7.2 Check weight containership 
        
        
        //8.1 Add container c7
        
        
        //8.2 Check weight containership 
        
        //9.1 Add container c8
        
        //9.2 Check weight containership 
        
        //10.1 Add container c9
        
        
        //10.2 Check weight containership 
        
        
        //11.1 Add container c9
        
       
        
        
        //11.2 Check weight containership 
        
      
        //12.1 Print ship
        
        
        
        
        //12.2 Print Total Transport Cost
        
	
        //12.3 Order ContainerShip
       
        
        
        //13.1 Instantiate Route Lisbon to Buenos Aires with 9600 km
        
        //13.2 Get time of route
	}
}
