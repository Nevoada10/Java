/*
 * League.java        20.10.2020
 *
 *
 * Copyright 2020 Joan Seculi <jseculi@escoladeltreball.org>
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package leagueXYZ;


public class League {
	private Team[] teams;
	private Match[] matches;
	
	
	
}
