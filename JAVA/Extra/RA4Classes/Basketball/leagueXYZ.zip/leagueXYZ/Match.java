/*
 * Match.java        01.02.2021
 *
 *
 * Copyright 2021 Joan Seculi <jseculi@escoladeltreball.org>
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package leagueXYZ;



public class Match {
	
	private Team localTeam;
	private Team visitantTeam;
	private byte pointsLocalTeam;
	private byte pointsVisitantTeam;
	private String code;
	public static int idNext=1;
	

	

}
