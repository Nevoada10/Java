/*
* TeamTest.java 23 Jan 2025
*
*
* © Copyright 2025 Joan Sèculi <jseculi@escoladeltreball.org>
*
* This is free software, licensed under the GNU General Public License v3.
* See http://www.gnu.org/licenses/gpl.html for more information.
*/
package leagueXYZ;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class TeamTest {

	private Team team;
	private Team team2;
	private Team team3;
	private Team team4;
	private CodeTeam codeTeam;

	@BeforeEach
	public void setUp() {
		codeTeam = CodeTeam.GIRONA; // Example team
		team = new Team(codeTeam);
		team2 = new Team(CodeTeam.MADRID);
		team3 = new Team(CodeTeam.VALENCIA);
		team4 = new Team(CodeTeam.FERROL);
	}

	// Test for Team constructor
	@Test
	@Order(1)
	public void testTeamConstructor() {
		assertEquals(CodeTeam.GIRONA, team.getCodeTeam());
		assertEquals(1, team.getId());
		assertEquals(2, team2.getId());
		assertEquals(3, team3.getId());
		assertEquals(4, team4.getId());
		
	}

	

	@Test
	@Order(3)
	public void testTeamConstructorInitialValues() {
		assertEquals(0, team.getPointsTeam());
		assertEquals(0, team.getPointsFor());
		assertEquals(0, team.getPointsAgainst());
		assertEquals(0, team.getGamesPlayed());
		assertEquals(0, team.getGamesWon());
		assertEquals(0, team.getGamesLost());
		assertEquals(0, team.getGamesTied());
		
	}

	@Test
	@Order(4)
	public void testAddPoints() {
		team.addPointsTeam(1);
		assertEquals(1, team.getPointsTeam());
	}

	@Test
	@Order(5)
	public void testAddPoints2() {
		team.addPointsTeam(3);
		assertEquals(3, team.getPointsTeam());
	}
	
	@Test
	@Order(6)
	public void testAddPoints3() {
		team.addPointsTeam(2);
		assertEquals(0, team.getPointsTeam());
	}
	
	
	@Test
	@Order(7)
	public void testAddPointsMultipleTimes() {
		team.addPointsTeam(3);
		team.addPointsTeam(3);
		team.addPointsTeam(1);
		
		assertEquals(7, team.getPointsTeam());
	}

    @Test
    @Order(7)
    public void testAddPointsNegativeValue() {
    	team.setPointsTeam(0);
        team.addPointsTeam(-3);
        assertEquals(0, team.getPointsTeam());
    }

	@Test
	@Order(8)
	public void testAddPointsFor() {
		team.addPointsFor(60);
		assertEquals(60, team.getPointsFor());
	}
	
    

	@Test
	@Order(9)
	public void testAddPointsForMultipleTimes() {
		team.addPointsFor(65);
		team.addPointsFor(33);
		assertEquals(98, team.getPointsFor());
	}

	@Test
	@Order(10)
	public void testAddPointsForZero() {
		team.addPointsFor(0);
		assertEquals(0, team.getPointsFor());
	}
	
	@Test
    @Order(10)
    public void testAddPointsForNegativa() {
    	team.setPointsFor(0);
        team.addPointsFor(-3);
        assertEquals(0, team.getPointsFor());
    }

	@Test
	@Order(11)
	public void testAddPointsAgainst() {
		team.setPointsAgainst(0);
		team.addPointsAgainst(82);
		assertEquals(82, team.getPointsAgainst());
	}

	@Test
	@Order(12)
	public void testAddPointsAgainstMultipleTimes() {
		team.setPointsAgainst(0);
		team.addPointsAgainst(58);
		team.addPointsAgainst(58);
		assertEquals(116, team.getPointsAgainst());
	}

    @Test
    @Order(12)
    public void testAddPointsAgainstNegative() {
    	team.setPointsAgainst(0);
        team.addPointsAgainst(-4);
        assertEquals(0, team.getPointsAgainst());
    }

	@Test
	@Order(13)
	public void testIncreaseGamesPlayed() {
		team.setGamesPlayed(0);
		team.increaseGamesPlayed(1);
		assertEquals(1, team.getGamesPlayed());
	}

	@Test
	@Order(14)
	public void testIncreaseGamesPlayedMultipleTimes() {
		team.setGamesPlayed(0);
		team.increaseGamesPlayed(2);
		team.increaseGamesPlayed(3);
		assertEquals(5, team.getGamesPlayed());
	}

    @Test
    @Order(14)
    public void testIncreaseGamesPlayedNegative() {
    	team.setGamesPlayed(0);
        team.increaseGamesPlayed(-1);
        assertEquals(0, team.getGamesPlayed());
    }

	@Test
	@Order(15)
	public void testIncreaseGamesWon() {
		team.setGamesWon(0);
		team.increaseGamesWon(1);
		assertEquals(1, team.getGamesWon());
	}

	@Test
	@Order(16)
	public void testIncreaseGamesWonMultipleTimes() {
		team.setGamesWon(0);
		team.increaseGamesWon(2);
		team.increaseGamesWon(1);
		assertEquals(3, team.getGamesWon());
	}

	@Test
	@Order(17)
	public void testIncreaseGamesWonZero() {
		team.setGamesWon(0);
		team.increaseGamesWon(0);
		assertEquals(0, team.getGamesWon());
	}
	
    @Test
    @Order(17)
    public void testIncreaseGamesWonNegative() {
    	team.setGamesWon(0);
        team.increaseGamesWon(-1);
        assertEquals(0, team.getGamesWon());
    }

	@Test
	@Order(18)
	public void testIncreaseGamesLost() {
		team.setGamesLost(0);
		team.increaseGamesLost(1);
		assertEquals(1, team.getGamesLost());
	}

	@Test
	@Order(19)
	public void testIncreaseGamesLostMultipleTimes() {
		team.setGamesLost(0);
		team.increaseGamesLost(2);
		team.increaseGamesLost(1);
		assertEquals(3, team.getGamesLost());
	}

    @Test
    @Order(19)
    public void testIncreaseGamesLostNegative() {
    	team.setGamesLost(0);
        team.increaseGamesLost(-1);
        assertEquals(0, team.getGamesLost());
    }

	@Test
	@Order(20)
	public void testIncreaseGamesTied() {
		team.increaseGamesTied(1);
		assertEquals(1, team.getGamesTied());
	}

	@Test
	@Order(21)
	public void testIncreaseGamesTiedMultipleTimes() {
		team.increaseGamesTied(2);
		team.increaseGamesTied(1);
		assertEquals(3, team.getGamesTied());
	}

	@Test
	@Order(22)
	public void testIncreaseGamesTiedZero() {
		team.increaseGamesTied(0);
		assertEquals(0, team.getGamesTied());
	}

    @Test
    @Order(22)
    public void testIncreaseGamesTiedNegative() {
    	team.setGamesTied(0);
        team.increaseGamesTied(-1);
        assertEquals(0, team.getGamesLost());
    }
    
	// Test for CodeTeam enum
	@Test
	@Order(23)
	public void testCodeTeamGetName() {
		assertEquals("Spar Girona", codeTeam.getName());
	}

	@Test
	@Order(24)
	public void testCodeTeamGetCity() {
		assertEquals("Girona", codeTeam.getCity());
	}

	@Test
	@Order(25)
	public void testCodeTeamDifferentTeams() {
		assertNotEquals(CodeTeam.GIRONA, CodeTeam.MADRID);
	}

	// Test for Team toString method
	@Test
	@Order(26)
	public void testToString() {
		
		Team team1 = new Team(CodeTeam.GIRONA);
		System.out.println(team1.toString());
		String expected1 = "GIRONA";
		String expected2 = "    0    0    0    0    0    0    0";
		
		
		assertTrue(team1.toString().contains(expected1));
		assertTrue(team1.toString().contains(expected2));
	}


	@Test
	@Order(28)
	public void testToStringWithChanges() {
		Team team1 = new Team(CodeTeam.GIRONA);
		team1.addPointsTeam(3);
		team1.addPointsFor(30);
		team1.addPointsAgainst(20);
		team1.setGamesPlayed(1);
		team1.setGamesWon(1);
		team1.setGamesLost(0);
		
		
		String expected1 = "GIRONA";
		String expected2 = "    3   30   20    1    1    0    0";
		
		
		assertTrue(team1.toString().contains(expected1));
		assertTrue(team1.toString().contains(expected2));
		
		
	}
}
