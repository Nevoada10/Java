/*
 * CodeTeam.java 3 Mar 2023
 *
 *
 * \u00A9 Copyright 2023 Joan S�culi  
 * Email: jseculi@escoladeltreball.org
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package leagueXYZ;




public enum CodeTeam {
	
	
	
	
	

}
