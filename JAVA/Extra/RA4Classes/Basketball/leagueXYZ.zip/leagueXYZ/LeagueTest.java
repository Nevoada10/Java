/*
* LeagueTest.java 23 Jan 2025
*
*
* © Copyright 2025 Joan Sèculi <jseculi@escoladeltreball.org>
*
* This is free software, licensed under the GNU General Public License v3.
* See http://www.gnu.org/licenses/gpl.html for more information.
*/
package leagueXYZ;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class LeagueTest {

    private League league;
    private Team[] teams;

    @BeforeEach
    public void setUp() {
        teams = new Team[] {
            new Team(CodeTeam.FERROL),
            new Team(CodeTeam.LASEU),
            new Team(CodeTeam.ZARAGOZA),
            new Team(CodeTeam.BOSCO),
            new Team(CodeTeam.ENSINO)
        };
        league = new League(teams);
    }

    // Test constructor
    @Test
    public void testLeagueConstructorTeams() {
        assertArrayEquals(teams, league.getTeams());
    }

    @Test
    public void testLeagueConstructorMatchesCount() {
        // Check there are (n * (n-1)) matches
        int expectedMatches = teams.length * (teams.length - 1);
        assertEquals(expectedMatches, league.getMatches().length);
        
    }

    @Test
    public void testLeagueConstructorMatchesNotNull() {
        Match[] matches = league.getMatches();
        for (Match match : matches) {
            assertNotNull(match);
        }
    }

    // Test playLeague
    @Test
    public void testPlayLeagueUpdatesTeamStats() {
        league.playLeague();

        for (Team team : teams) {
            assertTrue(team.getGamesPlayed() > 0);
            assertTrue(team.getPointsFor() > 0 || team.getPointsAgainst() > 0);
        }
    }

    @Test
    public void testPlayLeagueAllMatchesPlayed() {
        league.playLeague();
        for (Match match : league.getMatches()) {
            assertTrue(match.getLocalTeam().getGamesPlayed() > 0);
            assertTrue(match.getVisitantTeam().getGamesPlayed() > 0);
        }
    }

    @Test
    public void testPlayLeagueUniqueMatchResults() {
        league.playLeague();
        Match[] matches = league.getMatches();
        for (int i = 0; i < matches.length; i++) {
            for (int j = i + 1; j < matches.length; j++) {
                assertNotEquals(matches[i].toString(), matches[j].toString());
            }
        }
    }

    // Test showTeams
    @Test
    public void testShowTeamsFormat() {
        String result = league.showTeams();
        assertNotNull(result);
        for (Team team : teams) {
            assertTrue(result.contains(team.getCodeTeam().toString()));
        }
    }

    // Test showMatches
    @Test
    public void testShowMatchesFormat() {
        league.playLeague();
        String result = league.showMatches();
        assertNotNull(result);
        Match[] matches = league.getMatches();
        for (Match match : matches) {
            assertTrue(result.contains(match.getCode()));
        }
    }
/*
    // Test classification
    @Test
    public void testClassificationIncludesAllTeams() {
        league.playLeague();
        String classification = league.classification();
        for (Team team : teams) {
            assertTrue(classification.contains(team.getCodeTeam().toString()));
        }
    }
*/
    // Test orderClassification
    @Test
    public void testOrderClassificationSorting() {
        league.playLeague();
        Team[] orderedTeams = league.orderClassification();

        for (int i = 0; i < orderedTeams.length - 1; i++) {
            assertTrue(
                orderedTeams[i].getPointsTeam() >= orderedTeams[i + 1].getPointsTeam()
            );
        }
    }

    @Test
    public void testOrderClassificationNoDuplicates() {
        league.playLeague();
        Team[] orderedTeams = league.orderClassification();

        for (int i = 0; i < orderedTeams.length; i++) {
            for (int j = i + 1; j < orderedTeams.length; j++) {
                assertNotEquals(orderedTeams[i].getCodeTeam(), orderedTeams[j].getCodeTeam());
            }
        }
    }
}


