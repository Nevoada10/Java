/*
* MainAlumne.java 20 Jan 2025
*
*
* © Copyright 2025 Joan Sèculi <jseculi@escoladeltreball.org>
*
* This is free software, licensed under the GNU General Public License v3.
* See http://www.gnu.org/licenses/gpl.html for more information.
*/
package leagueXYZ;

public class MainAlumne {

	public static void main(String[] args) {
		
		//1. Team
		System.out.println("\n1. Team\n--------------------------");
		
		//1.1 Create Teams
		System.out.println("\n1.1 Create Teams\n--------------------------");
		Team t1 = new Team(CodeTeam.FERROL);
		Team t2 = new Team(CodeTeam.LASEU);
		Team t3 = new Team(CodeTeam.ZARAGOZA);
		Team t4 = new Team(CodeTeam.BOSCO);
		Team t5 = new Team(CodeTeam.ENSINO);
		Team t6 = new Team(CodeTeam.MURCIA);
		Team t7 = new Team(CodeTeam.DONOSTIA);
		Team t8 = new Team(CodeTeam.JOVENTUT);
		Team t9 = new Team(CodeTeam.ARASKI);
		Team t10 = new Team(CodeTeam.GERNIKA);
		Team t11 = new Team(CodeTeam.MADRID);
		Team t12 = new Team(CodeTeam.ARDOI);
		Team t13 = new Team(CodeTeam.SALAMANCA);
		Team t14 = new Team(CodeTeam.GIRONA);
		Team t15 = new Team(CodeTeam.PALMAS);
		Team t16 = new Team(CodeTeam.VALENCIA);
	
		

		//1.2 Show team data.
		System.out.println("\n1.2 Show team data\n--------------------------");
		


		//1.3 Show code, name and city of team.
		System.out.println("\n1.3 Show code, name and city of team\n--------------------------");
		
		
		//1.4 Add team points in 3
		System.out.println("\n1.4 Add team points in 3\n--------------------------");
		
		//1.5 Add points For = 55 to team
		System.out.println("\n1.5 Add points For = 55 to team\n--------------------------");
		
		//1.6 Add points Against = 77 to team
		System.out.println("\n1.6 Add points Against = 77 to team\n--------------------------");
		
		
		//1.7 Increase GamesPlayed = 1 to team
		System.out.println("\n1.7 Increase GamesPlayed = 1 to team\n--------------------------");
						
		//1.8 Increase GamesWon = 1 to team
		System.out.println("\n1.8 Increase GamesWon = 1 to team\n--------------------------");
		
		//1.9 Increase GamesLost = 1 to team
		System.out.println("\n1.9 Increase GamesLost = 1 to team\n--------------------------");
		
		//1.10 Increase GamesTied = 1 to team
		System.out.println("\n1.10 Increase GamesTied = 1 to team\n--------------------------");
		
		
		//2. Match
		System.out.println("\n2. Match\n--------------------------");
		//2.1 Instantiate a match between two teams
		System.out.println("\n2.1 Instantiate a match between two teams\n--------------------------");
		
		//2.2 Show a match
		System.out.println("\n2.2 Show match toString\n--------------------------");
				
		//2.3 Pay a match
		System.out.println("\n2.2 Pay match\n--------------------------");
		
		//2.4 End a match
		System.out.println("\n2.3 End match\n--------------------------");
		
		//2.5 Show match toString
		System.out.println("\n2.5 Show match toString\n--------------------------");
		
		//2.5 Show teams details (toString)
		System.out.println("\n2.5 Show teams toString");

				
		//2.6 Simulate a new match with a draw and show teams details (toString)
		// Forcing a draw
		System.out.println("\n2.6 Simulate a new match with a draw and show teams toString)\n--------------------------");
					

		//3. Create league
		System.out.println("\n3. League\n--------------------------");
		
		//3.1 Create an array of teams
		System.out.println("\n3.1 Create array of Teams\n--------------------------");
		//IMPORTATNT: only teams you have not used before in the test		
				
				
		//3.2 Instantiate league
		System.out.println("\n3.2 Instantiate League\n--------------------------");
				
			
		
		//3.3 Play league
		System.out.println("\n3.3 Play league\n--------------------------");
		
		
		//3.4 Show teams after playing
		System.out.println("\n3.4 Show teams after play league\n--------------------------");
		
		
				
		//3.5 Show matches after play league
		System.out.println("\n3.5 Show matches after play league\n--------------------------");
		
						
		
		//3.6 Order classification
		System.out.println("\n3.6 Order classification\n--------------------------");
		
	}
}
