/*
* MatchTest.java 23 Jan 2025
*
*
* © Copyright 2025 Joan Sèculi <jseculi@escoladeltreball.org>
*
* This is free software, licensed under the GNU General Public License v3.
* See http://www.gnu.org/licenses/gpl.html for more information.
*/
package leagueXYZ;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class MatchTest {

    private static Team team1;
    private static Team team2;
    private static Match match;

    @BeforeAll
    static void setUpBeforeClass() throws Exception {  
    	 team1 = new Team(CodeTeam.GIRONA);
         team2 = new Team(CodeTeam.MADRID);
         match = new Match(team1, team2);
    }

    
    
    @BeforeEach
    public void setUp() {
       
        
    }

    // Test del constructor
    @Test
    @Order(1)
    public void testMatchConstructor() {
        assertEquals(team1, match.getLocalTeam());
        assertEquals(team2, match.getVisitantTeam());
    }

    @Test
    @Order(2)
    public void testMatchConstructorCode() {
        assertNotNull(match.getCode());
        System.out.println(match.getCode());
        assertTrue(match.getCode().contains("001-GIRONA-MADRID"));
    }

    // Test del mètode playMatch
    @Test
    @Order(4)
    public void testPlayMatchGeneratesPoints() {
        match.playMatch();
        assertNotEquals(0, match.getPointsLocalTeam());
        assertNotEquals(0, match.getPointsVisitantTeam());
    }
    
    @Test
    @Order(5)
    public void testPlayMatchGeneratesPoints2() {
    	for (int i = 0; i < 1000000; i++) {
    		match.playMatch();
            assertTrue(match.getPointsLocalTeam() >= 50 ||  match.getPointsLocalTeam() <= 100);
            assertTrue( match.getPointsVisitantTeam() >= 50 || match.getPointsVisitantTeam() <= 100);
            match.getLocalTeam().setPointsTeam(0);
            match.getVisitantTeam().setPointsTeam(0);
            
		}
        
    }

    @Test
    @Order(6)
    public void testPlayMatchDoesNotUpdateBeforeEndMatch() {
        match.playMatch();
        assertEquals(0, team1.getPointsTeam());
        assertEquals(0, team1.getPointsFor());
        assertEquals(0, team2.getPointsAgainst());
        assertEquals(0, team2.getGamesPlayed());
        assertEquals(0, team2.getGamesWon());
        assertEquals(0, team2.getGamesLost());
        assertEquals(0, team2.getGamesTied());
        
        
    }

    

    @Test
    @Order(8)
    public void testEndMatchTeamPoints() {
    	
    	Team team1 = new Team(CodeTeam.DONOSTIA);
        Team team2 = new Team(CodeTeam.VALENCIA);
        Match match = new Match(team1, team2);
        
        
        match.playMatch();
        match.endMatch();
        if (match.getVisitantTeam().getPointsFor() > match.getLocalTeam().getPointsFor()) {
            assertEquals(3, match.getVisitantTeam().getPointsTeam());
            assertEquals(0, match.getLocalTeam().getPointsTeam());
        }else {
        	assertEquals(0, match.getVisitantTeam().getPointsTeam());
            assertEquals(3, match.getLocalTeam().getPointsTeam());
        }
    }
    
    @Test
    @Order(9)
    public void testEndMatchCheckGamesPlayed() {
    	
    	Team team1 = new Team(CodeTeam.DONOSTIA);
        Team team2 = new Team(CodeTeam.VALENCIA);
        Match match = new Match(team1, team2);
        
        
        match.playMatch();
        match.endMatch();
        assertEquals(1, match.getLocalTeam().getGamesPlayed());
        assertEquals(1, match.getLocalTeam().getGamesPlayed());
            
      
    }
    
    @Test
    @Order(10)
    public void testEndMatchCheckGamesWon() {
    	
    	Team team1 = new Team(CodeTeam.DONOSTIA);
        Team team2 = new Team(CodeTeam.VALENCIA);
        Match match = new Match(team1, team2);
        
        // Forcing team1 a winner
        match.setPointsLocalTeam((byte)80);
        
        match.setPointsVisitantTeam((byte)50);
        match.endMatch();
        assertEquals(1, match.getLocalTeam().getGamesWon());
        assertEquals(0, match.getVisitantTeam().getGamesWon());
            
      
    }
    
    @Test
    @Order(11)
    public void testEndMatchCheckGamesLost() {
    	
    	Team team1 = new Team(CodeTeam.DONOSTIA);
        Team team2 = new Team(CodeTeam.VALENCIA);
        Match match = new Match(team1, team2);
        
        // Forcing team1 a winner
        match.setPointsLocalTeam((byte)80);
        
        match.setPointsVisitantTeam((byte)50);
        match.endMatch();
        assertEquals(0, match.getLocalTeam().getGamesLost());
        assertEquals(1, match.getVisitantTeam().getGamesLost());
    }
    
    @Test
    @Order(12)
    public void testEndMatchCheckGamesTied() {
    	
    	Team team1 = new Team(CodeTeam.DONOSTIA);
        Team team2 = new Team(CodeTeam.VALENCIA);
        Match match = new Match(team1, team2);
        
        // Forcing a draw
        match.setPointsLocalTeam((byte)80);
        
        match.setPointsVisitantTeam((byte)80);
        match.endMatch();
        assertEquals(1, match.getLocalTeam().getGamesTied());
        assertEquals(1, match.getVisitantTeam().getGamesTied());
    }
    @Test
    @Order(9)
    public void testEndMatchDraw() {
    	
    	Team team1 = new Team(CodeTeam.DONOSTIA);
        Team team2 = new Team(CodeTeam.VALENCIA);
        Match match = new Match(team1, team2);
        
        
        match.playMatch();
        // Forcing a draw
        match.setPointsLocalTeam((byte)50);;
        match.setPointsVisitantTeam((byte)50);
        match.endMatch();

        assertEquals(1, match.getLocalTeam().getPointsTeam());
        assertEquals(1, match.getVisitantTeam().getPointsTeam());
        
        
        assertEquals(match.getLocalTeam().getPointsFor(), match.getVisitantTeam().getPointsFor());
        assertEquals(match.getLocalTeam().getPointsAgainst(), match.getVisitantTeam().getPointsAgainst());
        
        assertEquals(1, match.getLocalTeam().getGamesPlayed());
        assertEquals(1, match.getVisitantTeam().getGamesPlayed());
        
        
        assertEquals(0, match.getLocalTeam().getGamesWon());
        assertEquals(0, match.getVisitantTeam().getGamesWon());
        
        assertEquals(0, match.getLocalTeam().getGamesLost());
        assertEquals(0, match.getVisitantTeam().getGamesLost());
        
    }
    
   
    
    

    // Test del mètode toString
    @Test
    @Order(10)
    public void testToStringFormat() {
    	Team team1 = new Team(CodeTeam.GIRONA);
        Team team2 = new Team(CodeTeam.MADRID);
        Match match = new Match(team1, team2);
        
        
        match.playMatch();
        match.endMatch();
        String result = match.toString();
        assertTrue(result.contains(CodeTeam.GIRONA.getName()));
        assertTrue(result.contains(CodeTeam.MADRID.getName()));
        
       
        
    }

    @Test
    @Order(11)
    public void testToStringIncludesPoints() {
    	Team team1 = new Team(CodeTeam.GIRONA);
        Team team2 = new Team(CodeTeam.MADRID);
        Match match = new Match(team1, team2);
        
        
        match.playMatch();
        match.endMatch();
        String result = match.toString();
        System.out.println(result);
        assertTrue(result.contains(String.valueOf(match.getLocalTeam().getPointsFor())));
        assertTrue(result.contains(String.valueOf(match.getVisitantTeam().getPointsAgainst())));
    }

    @Test
    @Order(12)
    public void testToStringIncludesMatchCode() {
    	Team team1 = new Team(CodeTeam.GIRONA);
        Team team2 = new Team(CodeTeam.MADRID);
        Match match = new Match(team1, team2);
        
        
        String result = match.toString();
        assertTrue(result.contains(match.getCode()));
    }
}
