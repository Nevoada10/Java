/*
 * Team.java        01.02.2021
 *
 *
 * Copyright 2020 Joan Seculi <jseculi@escoladeltreball.org>
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package leagueXYZ;

public class Team {
	private CodeTeam codeTeam;
	private int pointsTeam;
	private int id;
	private int pointsFor;
	private int pointsAgainst;
	private int gamesPlayed;
	private int gamesWon;
	private int gamesLost;
	private int gamesTied;
	
	


}