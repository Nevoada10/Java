/*
 * Square.java       23/04/2021
 *
 *
 * �Copyright 2021 Joan Seculi <jseculi@escoladeltreball.org>
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package figure;

public class Square extends Rectangle{

	public Square(double x, double y, Color color, boolean isFilled, double side) {
		super(x, y, color, isFilled, side, side);
	}

	public Square(double x, double y, double side) {
		super(x, y, side, side);
	}

	@Override
	public String toString() {
		return "Square [toString()=" + super.toString() + "]";
	}
	

	
	
}