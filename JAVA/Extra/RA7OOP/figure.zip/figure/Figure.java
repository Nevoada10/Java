/*
 * ObjectGeometric.java       23/04/2021
 *
 *
 * @Copyright 2021 Joan Seculi <jseculi@escoladeltreball.org>
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package figure;


public abstract class Figure {

	private double x;
	private double y;
	private Color color;
	private boolean isFilled;

	public Figure(double x, double y, Color color, boolean isFilled) {
		this.x = x;
		this.y = y;
		this.color = color;
		this.isFilled = isFilled;
	}

	public Figure(double x, double y) {
		this.x = x;
		this.y = y;
		this.color = Color.BLACK;
		this.isFilled = false;

	}



	
	
	@Override
	public String toString() {
		return "ObjectGeometric [x=" + x + ", y=" + y + ", color=" + color + ", isFilled=" + isFilled + "]";
	}

	public void resetPosition() {
		this.x = 0;
		this.y = 0;
	}
/*
	public double perimetre() {
		return 0;
	}
	
	public double area() {
		return 0;
	}
*/
	public double getX() {
		return x;
	}

	public void setX(double x) {
		this.x = x;
	}

	public double getY() {
		return y;
	}

	public void setY(double y) {
		this.y = y;
	}
	public double module() {
		return 1.0;
	}

	public Color getColor() {
		return color;
	}

	public void setColor(Color color) {
		this.color = color;
	}

	public boolean isFilled() {
		return isFilled;
	}

	public void setFilled(boolean isFilled) {
		this.isFilled = isFilled;
	}


	
	/*public final double module() {
		return 1.0;
	}*/
	
	
	/*
	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public boolean isFilled() {
		return isFilled;
	}

	public void setFilled(boolean isFilled) {
		this.isFilled = isFilled;
	}
*/
}
