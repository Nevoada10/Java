/*
 * Cercle.java       23/04/2021
 *
 *
 * @Copyright 2021 Joan Seculi <jseculi@escoladeltreball.org>
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package figure;

public class Circle extends Oval{

	
	public Circle(double x, double y, double radius) {
		super(x, y, radius, radius);
	}

	public Circle(double x, double y,Color color, Boolean isFilled, double radius) {
		super(x, y, color, isFilled, radius, radius);
	}

	@Override
	public String toString() {
		return "Circle [toString()=" + super.toString() + "]";
	}
	
	

}
