/*
 * Rectangle.java       23/04/2021
 *
 *
 * @Copyright 2021 Joan Seculi <jseculi@escoladeltreball.org>
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package figure;

public class Rectangle extends Figure {
	private double base;
	private double height;
	public Rectangle(double x, double y, Color color, boolean isFilled, double base, double height) {
		super(x, y, color, isFilled);
		this.base = base;
		this.height = height;
	}
	
	public Rectangle(double x, double y, double base, double height) {
		super(x, y);
		this.base = base;
		this.height = height;
	}
	
	@Override
	public double module() {
		return Math.sqrt(base*base + height*height);
	}
	
	@Override
	public String toString() {
		return "Rectangle [base=" + base + ", height=" + height + ", toString()=" + super.toString() + "]";
	}
	
//	Area quadrat = base * height
//	par�metre quadrat = 2 * base + 2 * height

	public double area() {
		return base*height;
	}

	public double perimetre() {
		return 2*base + 2*height;
	}

	public double getBase() {
		return base;
	}

	public void setBase(double base) {
		this.base = base;
	}

	public double getHeight() {
		return height;
	}

	public void setHeight(double height) {
		this.height = height;
	}


}
