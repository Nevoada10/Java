/*
 * Color.java       24/04/2021
 *
 *
 * @Copyright 2021 Joan Seculi <jseculi@escoladeltreball.org>
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package figure;

public enum Color {
	CYAN, YELLOW, MAGENTA, BLACK;

}
