/*
 * Oval.java       24/04/2021
 *
 *
 * @Copyright 2021 Joan Seculi <jseculi@escoladeltreball.org>
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package figure;

public class Oval extends Figure {
	
	
	private double radius1;
	private double radius2;
	
	
	public Oval(double x, double y, Color color, boolean isFilled, double radius1, double radius2) {
		super(x, y, color, isFilled);
		
		this.radius1 = radius1;
		this.radius2 = radius2;
	}
	public Oval(double x, double y, double radius1, double radius2) {
		super(x, y);
		this.radius1 = radius1;
		this.radius2 = radius2;
	}
	
	@Override
	public double module() {
		//System.out.println("Hola");
		return Math.sqrt(radius1*radius1 + radius2*radius2);
	}
	
	public double area() {
		return Math.PI*radius1*radius2;
	}

	public double perimetre() {
		return 2*Math.PI * Math.sqrt((radius1 * radius1 + radius2 * radius2)/2.0);
	}
	
	@Override
	public String toString() {
		return "Oval [radius1=" + radius1 + ", radius2=" + radius2 + ", toString()=" + super.toString() + "]";
	}

	
	
}
