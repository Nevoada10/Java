/*
 * Triangle.java       23/04/2021
 *
 *
 * �Copyright 2021 Joan Seculi <jseculi@escoladeltreball.org>
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package figure;

public class Triangle extends Figure {

	private double base;
	private double height;
	
	public Triangle(double x, double y, Color color, Boolean isFilled, double base, double height) {
		super(x, y, color, isFilled);
		this.base = base;
		this.height = height;
	}
	
	public Triangle(double x, double y, double base, double height) {
		super(x, y);
		this.base = base;
		this.height = height;

	}

	public double perimetre() {
		return base + height + Math.sqrt(Math.pow(base, 2) + Math.pow(height, 2));
	}
	
	public double area() {
		return this.base*this.height/2.0;
	}
	@Override
	public String toString() {
		return "Triangle [base=" + base + ", height=" + height + ", toString()=" + super.toString() + "]";
	}
	
	@Override
	public double module() {
		return Math.sqrt(base*base + height*height);
	}
	
}
