/*
 * Test.java       23/04/2021
 *
 *
 * @Copyright 2021 Joan Seculi <jseculi@escoladeltreball.org>
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package figure;

import java.util.ArrayList;
import java.util.List;

import javax.swing.text.html.HTMLDocument.HTMLReader.IsindexAction;

public class Main {

	public static void main(String[] args) {
		
		

		// Rectangle
		System.out.println("Rectangle 1: ");
		Rectangle rr = new Rectangle(1, 1, Color.BLACK, false, 100, 120);
		rr.getX();
		rr.getY();
		rr.getColor();
		rr.getBase();
		rr.getHeight();
		System.out.println(rr.toString());
		System.out.println("Module Rectangle: " + rr.module());
		System.out.println("Perimeter Rectangle: " + rr.perimetre());
		System.out.println("Area Rectangle: " + rr.area());

		System.out.println("Rectangle 2: ");
		Rectangle rr2 = new Rectangle(1, 1, 100, 120);
		rr2.getX();
		rr2.getY();
		rr2.getColor();
		rr2.getBase();
		rr2.getHeight();
		System.out.println(rr2.toString());
		System.out.println("Module Rectangle: " + rr2.module());
		System.out.println("Perimeter Rectangle: " + rr2.perimetre());
		System.out.println("Area Rectangle: " + rr2.area());

		// Square
		System.out.println("Square 1: ");
		Square ss = new Square(10, 10, 5);
		System.out.println(ss.toString());
		System.out.println("Module Square: " + ss.module());
		System.out.println("Perimeter Square: " + ss.perimetre());
		System.out.println("Area Square: " + ss.area());

		System.out.println("Square 2: ");
		Square ss2 = new Square(10, 10, Color.BLACK, true, 5);
		System.out.println(ss2.toString());
		System.out.println("Module Square: " + ss2.module());
		System.out.println("Perimeter Square: " + ss2.perimetre());
		System.out.println("Area Square: " + ss2.area());

		// Oval
		System.out.println("Oval 1: ");
		double radius1 = 4;
		double radius2 = 6;
		Oval oval1 = new Oval(1, 1, Color.CYAN, true, radius1, radius2);

		System.out.println(oval1.toString());
		System.out.println("Area Oval: " + ((Oval) oval1).area());
		System.out.println("Perimetre Oval: " + ((Oval) oval1).perimetre());
		System.out.println("toString Oval: " + oval1.toString());

		oval1.resetPosition();
		System.out.println("toString after init: " + oval1.toString());
		System.out.println("module Oval: " + oval1.module());

		System.out.println("Oval 2: ");
		radius1 = 8;
		radius2 = 3;
		Oval oval2 = new Oval(1, 1, radius1, radius2);

		System.out.println(oval2.toString());
		System.out.println("Area Oval: " + ((Oval) oval2).area());
		System.out.println("Perimetre Oval: " + ((Oval) oval2).perimetre());
		System.out.println("toString Oval: " + oval2.toString());

		oval1.resetPosition();
		System.out.println("toString after init: " + oval2.toString());
		System.out.println("module Oval: " + oval2.module());

		// Cercle
		System.out.println("Cercle 1: ");
		double radius = 4;
		Circle cercle1 = new Circle(1, 1, Color.MAGENTA, true, radius);
		System.out.println(cercle1.toString());
		System.out.println("Area cercle: " + ((Oval) cercle1).area());
		System.out.println("Perimetre cercle: " + ((Oval) cercle1).perimetre());
		System.out.println("toString cercle: " + cercle1.toString());

		cercle1.resetPosition();
		System.out.println("toString after init: " + cercle1.toString());
		System.out.println("module cercle: " + cercle1.module());

		System.out.println("Cercle 2: ");
		radius = 8;
		Circle cercle2 = new Circle(1, 1, radius);
		System.out.println(cercle1.toString());
		System.out.println("Area cercle: " + ((Oval) cercle2).area());
		System.out.println("Perimetre cercle: " + ((Oval) cercle2).perimetre());
		System.out.println("toString cercle: " + cercle2.toString());

		cercle1.resetPosition();
		System.out.println("toString after init: " + cercle2.toString());
		System.out.println("module cercle: " + cercle2.module());

		// Triangle
		System.out.println("Triangle 1: ");
		Triangle tt = new Triangle(10, 10, 4, 6);
		System.out.println("Module triangle: " + ((Triangle) tt).module());
		System.out.println("Area triangle: " + ((Triangle) tt).area());
		System.out.println("Perimetre triangle: " + ((Triangle) tt).perimetre());
		System.out.println("toString triangle: " + tt.toString());

		System.out.println("Triangle 2: ");
		Triangle tt2 = new Triangle(10, 10, 4, 6);
		System.out.println("Module triangle: " + ((Triangle) tt2).module());
		System.out.println("Area triangle: " + ((Triangle) tt2).area());
		System.out.println("Perimetre triangle: " + ((Triangle) tt2).perimetre());
		System.out.println("toString triangle: " + tt2.toString());

		// Declaring as Figure
		// Rectangle
		double side1 = 2;
		double side2 = 3;
		Figure rectangle1 = new Rectangle(1, 1, Color.CYAN, false, side1, side2);
		System.out.println("Area rectangle: " + ((Rectangle) rectangle1).area());
		System.out.println("Perimetre rectangle: " + ((Rectangle) rectangle1).perimetre());
		System.out.println("toString rectangle: " + rectangle1.toString());
		rectangle1.resetPosition();
		System.out.println("toString after init: " + rectangle1.toString());
		System.out.println("module rectangle: " + rectangle1.module());

		// Square
		double costat = 3;
		Figure square1 = new Square(1, 1, costat);
		System.out.println("Area square: " + ((Rectangle) square1).area());
		System.out.println("Perimetre square: " + ((Rectangle) square1).perimetre());
		System.out.println("toString square: " + square1.toString());
		square1.resetPosition();
		System.out.println("toString after init: " + square1.toString());
		System.out.println("module square: " + square1.module());

		// Triangle
		double base = 3;
		double height = 4;
		Figure triangle = new Triangle(1, 1, base, height);
		System.out.println("Area triangle: " + ((Triangle) triangle).area());
		System.out.println("Perimetre triangle: " + ((Triangle) triangle).perimetre());
		System.out.println("toString triangle: " + triangle.toString());
		triangle.resetPosition();
		System.out.println("toString after init: " + triangle.toString());
		System.out.println("module triangle: " + triangle.module());

		// Part 2

		List<Figure> figures = new ArrayList<>();

		figures.add(rr);
		figures.add(rr2);
		figures.add(ss);
		figures.add(ss2);
		figures.add(oval1);
		figures.add(oval2);
		figures.add(cercle1);
		figures.add(cercle2);
		figures.add(rectangle1);
		figures.add(square1);
		figures.add(triangle);

		System.out.println("Part 2:");

		for (Figure figure : figures) {
			if (figure instanceof Circle) {
				System.out.println("Cercle");
				System.out.println(figure.module());
				System.out.println(((Circle) figure).perimetre());
				System.out.println(((Circle) figure).area());

			} else if (figure instanceof Oval) {
				System.out.println("Oval");
				System.out.println(figure.module());
				System.out.println(((Oval) figure).perimetre());
				System.out.println(((Oval) figure).area());
			} else if (figure instanceof Square) {
				System.out.println("Square");
				System.out.println(figure.module());
				System.out.println(((Square) figure).perimetre());
				System.out.println(((Square) figure).area());
			} else if (figure instanceof Rectangle) {
				System.out.println("Rectangle");
				System.out.println(figure.module());
				System.out.println(((Rectangle) figure).perimetre());
				System.out.println(((Rectangle) figure).area());
			} else if (figure instanceof Triangle) {
				System.out.println("Triangle");
				System.out.println(figure.module());
				System.out.println(((Triangle) figure).perimetre());
				System.out.println(((Triangle) figure).area());
			}
		}

		// NO
		/*Figure piece1 = new Figure(1, 1);
		Figure piece2 = new Figure(5, 5, Color.YELLOW, true);

		// Exemples de com declarar i instanciar objectes
		// Figure - Rectangle - Square

		Figure square2 = new Square(3.5, 3.5, Color.CYAN, true, 5);
		Square square3 = (Square) square2;

		// Polimorfisme d'assignaci�
		// Figure - Rectangle - Square
		Figure figure = new Figure(1, 1);
		Figure rectangleF = new Rectangle(1, 1, 5, 10);
		Rectangle rectangleR = new Rectangle(1, 1, 4, 5);
		Figure squareF = new Square(1, 1, 5);
		Rectangle squareR = new Square(1, 1, 6);
		Square squareSquare = new Square(1, 1, 8);

		// Figure - Oval - Cercle
		Figure ovalF = new Oval(1, 1, 5, 7);
		Figure cercleF = new Cercle(1, 1, 5);
		Oval cercleO = new Cercle(1, 1, 10);

		// Figure - Triangle
		Figure triangleF = new Triangle(1, 1, 5, 6);
		Triangle triangleT = new Triangle(1, 1, 7, 6);
		
		*/

	}

}
