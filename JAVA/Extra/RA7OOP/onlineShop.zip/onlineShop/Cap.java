package onlineShop;

public class Cap extends Product {

	
	private Visor visor;

	public Cap(String barCode, String description,  Color color, Visor visor) {
		super(barCode, description,  color);
		this.visor = visor;
		this.price = price();
	}

	@Override
	public float price() {
		if (visor.equals(Visor.FLAT)) {
			//price = VISOR_FLAT;
			return Product.VISOR_FLAT;
			
		}
		//price = VISOR_CURVED;
		return Product.VISOR_CURVED;
	}

	public Visor getVisor() {
		return visor;
	}

	public void setVisor(Visor visor) {
		this.visor = visor;
	}

}
