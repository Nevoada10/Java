package onlineShop;

public class TankT extends TShirt{

	public TankT(String barCode, String description, Fabric fabric, Color color) {
		super(barCode, description, fabric, color);
		//setPrice(price());
		this.price = price();
	}

	@Override
	public float price() {
		float priceExtra = Product.PRICE_TANKT;
		//setPrice(super.price());
		return super.price() + priceExtra;
	}

	

}
