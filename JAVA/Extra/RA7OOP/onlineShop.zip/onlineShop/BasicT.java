package onlineShop;

public class BasicT extends TShirt {
	
	private boolean hasPocket;
	private boolean hasButtons;

	public BasicT(String code, String description,  Fabric fabric, Color color, boolean hasPocket, boolean hasButtons) {
		super(code, description, fabric,  color);
		this.hasPocket = hasPocket;
		this.hasButtons = hasButtons;
		this.price = price();
	}

	@Override
	public float price() {
		float priceExtra = Product.PRICE_BASICT;
		if (hasPocket) priceExtra += Product.PRICE_POCKET;
		if (hasButtons) priceExtra += Product.PRICE_BUTTONS;
		//price = super.price() + priceExtra;
		return super.price() + priceExtra;
	}

	@Override
	public String toString() {
		return "BasicT [hasPocket=" + hasPocket + ", toString()=" + super.toString() + "]";
	}

	public boolean isHasPocket() {
		return hasPocket;
	}

	public void setHasPocket(boolean hasPocket) {
		this.hasPocket = hasPocket;
	}

	public boolean isHasButtons() {
		return hasButtons;
	}

	public void setHasButtons(boolean hasButtons) {
		this.hasButtons = hasButtons;
	}

}
