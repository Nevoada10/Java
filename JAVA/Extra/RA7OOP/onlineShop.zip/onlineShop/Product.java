/*
 * Product.java
 *
 *
 * �Copyright 2021 Joan Seculi <jseculi@escoladeltreball.org>
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
*/
package onlineShop;

public abstract class Product {
	
	
	public static final float PRICE_IMAGE = 10;
	public static final float PRICE_BASICT = 10;
	public static final float PRICE_POCKET = 2;
	public static final float PRICE_BUTTONS = 3;
	public static final float PRICE_LONGT = 12;
	public static final float PRICE_VNECKT = 11;
	public static final float PRICE_TANKT = 13;
	public static final float VISOR_FLAT = 20;
	public static final float VISOR_CURVED = 30;
	
	
	
	
	protected String barCode;
	protected String desc;
    protected float price;  //default: 0
    protected PrintImage printImage;  //default: null
    protected Color color;    
    protected boolean onSell; //default: false

    
    
    
    
    public Product(String barCode, String description,  Color color) {
        this.barCode = barCode;
        this.desc = description;
        this.color = color;
        this.onSell = true;     
    }

    
    public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public Color getColor() {
		return color;
	}

	public void setColor(Color color) {
		this.color = color;
	}

	public boolean isOnSell() {
		return onSell;
	}

	public void setOnSell(boolean onSell) {
		this.onSell = onSell;
	}

	
    public PrintImage getPrintImage() {
		return printImage;
	}

	public void setPrintImage(PrintImage printImage) {
		this.printImage = printImage;
	}

	/**
     * Calculates the final price of the product.
     * 
     * @return the price.
     */
    public abstract float price();
    

    public String getBarCode() {
        return this.barCode;
    }



	public void setBarCode(String barCode) {
		this.barCode = barCode;
	}

	@Override
	public String toString() {
		
		String text = "";
		
		return "Product [barCode=" + barCode + ", desc=" + desc + ", price=" + price + ", printImage=" + printImage
				+ ", color=" + color + ", onSell=" + onSell + "]";
	}

	
}
