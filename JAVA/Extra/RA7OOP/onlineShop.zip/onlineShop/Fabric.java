package onlineShop;

public enum Fabric {
	COTTON(1f), LINEN(2f), POLYESTER(3f), RAYON(4f), LYCRA(5f);
	
   private final float price;
	
	private Fabric (float price) {
		this.price = price;
	}

	public float getPrice() {
		return this.price;
	}

}
