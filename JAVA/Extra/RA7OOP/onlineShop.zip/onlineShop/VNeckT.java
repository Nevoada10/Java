package onlineShop;

public class VNeckT extends TShirt {
	private boolean hasPocket;

	public VNeckT(String barCode, String description,Fabric fabric, Color color,  boolean hasPocket) {
		super(barCode, description, fabric, color);
		this.hasPocket = hasPocket;
		
		this.price = price();
	}

	@Override
	public float price() {
		float priceExtra = Product.PRICE_VNECKT;
		if (hasPocket) priceExtra += Product.PRICE_POCKET;
		//this.price = super.price() + priceExtra;
		return super.price() + priceExtra;
	}

	public boolean isHasPocket() {
		return hasPocket;
	}

	public void setHasPocket(boolean hasPocket) {
		this.hasPocket = hasPocket;
	}

}
