/*
* OnlineShopTest2.java
*
* This is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation v3.
*
* @see <a href="http://www.gnu.org/licenses/gpl.html">GNU License</a> for more information.
*
* Copyright (c) Joan Sculi <a href="mailto:jseculi@escoladeltreball.org">Joan Sculi</a>
*/
package onlineShop;

import java.util.Locale;
import java.util.Scanner;

import javax.print.attribute.Size2DSyntax;

/**
* Enter a description
*
* @author  <a href="mailto:jseculi@escoladeltreball.org">Joan Sculi</a>
* @version 1.0
* @since   08/11/2021  
* 
*
* This is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation v3.
*
* @see <a href="http://www.gnu.org/licenses/gpl.html">GNU License</a> for more information.
*
*
*/
public class OnlineShopMain {
	public static Scanner scanner = new Scanner(System.in).useLocale(Locale.UK);
	
	/**
	* The main method test all methods of the class
	*
	* @since   21/10/2021 
	* @param args 	args are not used 
	*/
	public static void main(String[] args)  {
		
//		System.out.println(round(10.12345, (byte) 2));
//		System.out.println(round(10.12345f, (byte) 2));
//		
//		System.out.println(round(-10.12345, (byte) 2));
//		System.out.println(round(-10.12345f, (byte) 2));
//		
//		System.out.println(round(10.1, (byte) 2));
//		System.out.println(round(10.1f, (byte) 2));
//		
//		System.out.println(round(10, (byte) 2));
//		System.out.println(round(10f, (byte) 2));
//		
//		System.out.println(round(10.249, (byte) 2));
//		System.out.println(round(10.249f, (byte) 2));
		
		OnlineShop shop = new OnlineShop();
		
		Product basic1 = null;
		Product basic2;
		Product basic3;
		Product vNeck1;
		Product vNeck2;
		Product long1;
		Product long2;
		Product tank1;
		Product tank2;
		Product cap1 = null;
		Product cap2;

		for (int i = 0; i < 1; i++) {

			basic1 = new BasicT("1001", "BASIC1", Fabric.COTTON, Color.WHITE, false, false);
			basic2 = new BasicT("1002", "BASIC2", Fabric.LINEN, Color.BLACK, true, true);
			basic3 = new BasicT("1003", "BASIC3", Fabric.RAYON, Color.BLACK, true, true);

			vNeck1 = new VNeckT("2001", "VNECK1", Fabric.LYCRA, Color.RED, false);
			vNeck2 = new VNeckT("2002", "VNECK2", Fabric.LYCRA, Color.RED, true);

			long1 = new LongT("3001", "LONG1", Fabric.POLYESTER, Color.RED, false);
			long2 = new LongT("3002", "LONG2", Fabric.LYCRA, Color.YELLOW, true);

			tank1 = new TankT("4001", "TANK1", Fabric.POLYESTER, Color.RED);
			tank2 = new TankT("4002", "TANK2", Fabric.LYCRA, Color.YELLOW);

			cap1 = new Cap("5001", "CAP1", Color.RED, Visor.FLAT);
			cap2 = new Cap("5002", "CAP2", Color.YELLOW, Visor.CURVED);

			shop.addProduct(basic1);
			shop.addProduct(basic2);
			shop.addProduct(basic3);
			shop.addProduct(vNeck1);
			shop.addProduct(vNeck2);
			shop.addProduct(long1);
			shop.addProduct(long2);
			shop.addProduct(tank1);
			shop.addProduct(tank2);
			shop.addProduct(cap1);
			shop.addProduct(cap2);
		}
	            
		
		byte option = menu();
		if (option == 0) {
			System.out.println("Bye!");
		}
		while (option !=0 ) {
				switch (option) {
				case 1:
					System.out.println("LIST PRODUCTS:");
					System.out.println(shop.listStock());
					break;
				case 2:
					System.out.println("ADD PRODUCT");
					basic1 = new BasicT("1004", "BASIC4", Fabric.COTTON, Color.WHITE, false, false);
			        System.out.println("Add product basic1: " + shop.addProduct(basic1));
			        System.out.println("basic1: " + basic1.toString());
					break;
				case 3:
					System.out.println("REMOVE PRODUCT");
					System.out.println(shop.removeProduct(cap1));
					break;
				case 4:
					System.out.println("ADD IMAGE");
					break;
				case 5:
					System.out.println("SELL PRODUCT");
					break;
				case 6:
					System.out.println("STOCK VALUE");
					System.out.println("STOCK VALUE = " + shop.stockValue());
					System.out.println("NUM. CAPS = " + shop.numCaps());
					System.out.println("NUM. TSHIRTS = " + shop.numTShirts());
					System.out.println("NUM. ALL = " + shop.getStock().size());
					
					break;
					
				default:
					System.out.println(
							"WRONG ENTRY, PLEASE ENTER A NUMBER FROM 0 TO 6: ");
					break;
				}
				option = menu();
				if (option == 0) {
					System.out.println("Bye!");
				}
				
			}
			scanner.close();
	}
	public static byte menu() {
		System.out.println("MENU");
		System.out.println("1. LIST PRODUCTS");
		System.out.println("2. ADD PRODUCT");
		System.out.println("3. REMOVE PRODUCT");
		System.out.println("4. ADD IMAGE");
		System.out.println("5. SELL PRODUCT");
		System.out.println("6. STOCK VALUE");
		
		
		System.out.println("0. Quit");
		byte option = dataEntryByte("CHOOSE MENU OPTION: ", (byte)0, (byte)6);
		return option;
	}
	public static byte dataEntryByte(String text, byte min, byte max) {
		byte number = 0;
		System.out.print(text);
		boolean isValid = false;
		while (!isValid) {
			if (scanner.hasNextByte()) {
				number = scanner.nextByte();
				if(number <= max && number >= min) {
					isValid = true;
				}
				else {
					
					System.out.println("Error! " + text);
				}
			} else {
				scanner.next();  //Consume next line
				System.out.println("Error! " + text);
			}
		}
		return number;
	}
	public static int dataEntryInt(String text) {
		int number = 0;
		System.out.print(text);
		boolean isValid = false;
		while (!isValid) {
			if (scanner.hasNextInt()) {
				number = scanner.nextInt();
				isValid = true;
			} else {
				scanner.next();  //Consume next line
				System.out.println("Error! " + text);
			}
		}
		return number;
	}
	public static double dataEntryDouble(String text) {
		double number = 0;
		System.out.print(text);
		boolean isValid = false;
		while (!isValid) {
			if (scanner.hasNextDouble()) {
				number = scanner.nextDouble();
				isValid = true;
			} else {
				scanner.next();  //Consume next line
				System.out.println("Error! " + text);
			}
		}
		return number;
	}
	public static float dataEntryFloat(String text) {
		float number = 0;
		System.out.print(text);
		boolean isValid = false;
		while (!isValid) {
			if (scanner.hasNextFloat()) {
				number = scanner.nextFloat();
				isValid = true;
			} else {
				scanner.next();  //Consume next line
				System.out.println("Error! " + text);
			}
		}
		return number;
	}
	public static short dataEntryShort(String text) {
		short number = 0;
		System.out.print(text);
		boolean isValid = false;
		while (!isValid) {
			if (scanner.hasNextShort()) {
				number = scanner.nextShort();
				isValid = true;
			} else {
				scanner.next();  //Consume next line
				System.out.println("Error! " + text);
			}
		}
		return number;
	}
	public static String dataEntryString(String text) {
		
		System.out.print(text);
			
		
		return scanner.nextLine();
	}
	
	   /* Round to a specific number of decimals
     * 
     * @param num   real number to round
     * @param dec   decimal numbers
     * @return 		the rounded number
     */
	public static double round(double num, byte dec) {
		return  Math.round(num * Math.pow(10.0, dec)) / Math.pow(10.0, dec);
	}
	
	/* Round to a specific number of decimals
     * 
     * @param num   real number to round
     * @param dec   decimal numbers
     * @return 		the rounded number
     */
	public static float round(float num, byte dec) {
		 int pow = 10;
		 for (int i = 1; i < dec; i++) {
			 pow *= 10;
		 }	       
		 float tmp = num * pow;
		 return ( (float) ( (int) ((tmp - (int) tmp) >= 0.5f ? tmp + 1 : tmp) ) ) / pow;
	}
}
