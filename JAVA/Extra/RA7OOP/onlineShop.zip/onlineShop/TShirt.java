package onlineShop;

public abstract class TShirt extends Product{
	protected Fabric fabric;

	public TShirt(String barCode, String description,   Fabric fabric, Color color) {
		super(barCode, description, color);
		this.fabric = fabric;
	}

	public Fabric getFabric() {
		return fabric;
	}

	public void setFabric(Fabric fabric) {
		this.fabric = fabric;
	}

	@Override
	public String toString() {
		return "TShirt [fabric=" + fabric + ", toString()=" + super.toString() + "]";
	}

	@Override
	public float price() {
		float priceExtra = 0;
		//if (printImage != null) priceExtra += Product.PRICE_IMAGE;
		return getFabric().getPrice() + priceExtra;
	}

}
