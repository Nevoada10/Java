/*
 * Test.java
 *
 *
 * �Copyright 2021 Joan Seculi <jseculi@escoladeltreball.org>
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
*/

package onlineShop;


public class Main {

    /**
     * Main program.
     * 
     * @param args not used
     */
    public static void main(String[] args) {
      
        OnlineShop shop = new OnlineShop();
        
        Product	basic1 = new BasicT("1001", "BASIC1", Fabric.COTTON, Color.WHITE, false, false);
        Product	basic2 = new BasicT("1002", "BASIC2", Fabric.LINEN, Color.BLACK, true, true);
        Product	basic3 = new BasicT("1003", "BASIC3", Fabric.RAYON, Color.BLACK, true, true);
            
        Product vNeck1 = new VNeckT("2001", "VNECK1", Fabric.LYCRA, Color.RED, false);
        Product vNeck2 = new VNeckT("2002", "VNECK2", Fabric.LYCRA, Color.RED, true);
           
        Product long1 = new LongT("3001", "LONG1", Fabric.POLYESTER, Color.RED, false);
        Product long2 = new LongT("3002", "LONG2", Fabric.LYCRA, Color.YELLOW, true);
            
        Product tank1 = new TankT("4001", "TANK1", Fabric.POLYESTER, Color.RED);
        Product tank2 = new TankT("4002", "TANK2", Fabric.LYCRA, Color.YELLOW);
           
        Product cap1 = new Cap("5001", "CAP1",  Color.RED, Visor.FLAT);
        Product cap2 = new Cap("5002", "CAP2", Color.YELLOW, Visor.CURVED);
        
        
        
        	shop.addProduct(basic1);
        	shop.addProduct(basic2);
            shop.addProduct(basic3);
            shop.addProduct(vNeck1);
            shop.addProduct(vNeck2);
            shop.addProduct(long1);
            shop.addProduct(long2);
            shop.addProduct(tank1);
            shop.addProduct(tank2);
            shop.addProduct(cap1);
            shop.addProduct(cap2);
            
            /*System.out.println("Add product basic1: " + shop.addProduct(basic1));
        	System.out.println("Add product basic2: " + shop.addProduct(basic2));
            System.out.println("Add product basic3: " + shop.addProduct(basic3));
            System.out.println("Add product vNeck1: " + shop.addProduct(vNeck1));
            System.out.println("Add product vNeck2: " + shop.addProduct(vNeck2));
            System.out.println("Add product long1: " + shop.addProduct(long1));
            System.out.println("Add product long2: " + shop.addProduct(long2));
            System.out.println("Add product tank1: " + shop.addProduct(tank1));
            System.out.println("Add product tank2: " + shop.addProduct(tank2));
            System.out.println("Add product cap1: " + shop.addProduct(cap1));
            System.out.println("Add product cap2: " + shop.addProduct(cap2));*/
      //  }
        
             
        System.out.println(shop.listStock());
        System.out.println("Value: " + shop.stockValue());
        System.out.println("Num caps: " + shop.numCaps());
        System.out.println("Num TShirts: " + shop.numTShirts());
        
        System.out.println();
        System.out.println("Add new product: ");
        Product basic4 = new BasicT("1001", "BASIC1", Fabric.COTTON, Color.WHITE, false, false);
        System.out.println("Add product basic1: " + shop.addProduct(basic4));
        System.out.println("basic1: " + basic1.toString());
        
        System.out.println();
        System.out.println("STOCK: ");
        System.out.println(shop.listStock());
        System.out.println("Value: " + shop.stockValue());
        System.out.println("Num caps: " + shop.numCaps());
        System.out.println("Num TShirts: " + shop.numTShirts());
        System.out.println();
        
        System.out.println();
        System.out.println("PRICE BEFORE AND AFTER SELLING: ");
        System.out.println("Price BASIC1 before selling: " + basic1.price());
       
        System.out.println("Sell product with image BULL: " + shop.sellProduct(basic1, PrintImage.BULL));
      //  System.out.println("Price BASIC1 after adding image: " + basic1.price());
        System.out.println("basic1: " + basic1.toString());
        
        System.out.println();
        System.out.println("PRICE BEFORE AND AFTER SELLING: ");
        System.out.println("Price VNECK1 before selling: " + vNeck1.price());
       
        System.out.println("Sell product with image TIGER: " + shop.sellProduct(vNeck1, PrintImage.TIGER));
     //   System.out.println("Price VNECK1 after adding image: " + vNeck1.price());
        System.out.println("basic1: " + vNeck1.toString());
        System.out.println();
        
        System.out.println();
        System.out.println("PRICE BEFORE AND AFTER SELLING: ");
        System.out.println("Price LONG1 before selling: " + long1.price());
       
        System.out.println("Sell product with image COBRA: " + shop.sellProduct(long1, PrintImage.COBRA));
      //  System.out.println("Price LONG1 after adding image: " + long1.price());
        System.out.println("basic1: " + long1.toString());
        System.out.println();
        
        System.out.println();
        System.out.println("PRICE BEFORE AND AFTER SELLING: ");
        System.out.println("Price TANK1 before selling: " + tank1.price());
       
        System.out.println("Sell product with image REINDEER: " + shop.sellProduct(tank1, PrintImage.REINDEER));
      //  System.out.println("Price TANK1 after adding image: " + tank1.price());
        System.out.println("basic1: " + tank1.toString());
        System.out.println();
        
        System.out.println();
        System.out.println("PRICE BEFORE AND AFTER SELLING: ");
        System.out.println("Price CAP before selling: " + cap1.price());
       
        System.out.println("Sell product with image EAGLE: " + shop.sellProduct(cap1, PrintImage.EAGLE));
      //  System.out.println("Price CAP after adding image: " + cap1.price());
        System.out.println("basic1: " + cap1.toString());
        System.out.println();
        
        System.out.println();
        System.out.println("STOCK: ");
        System.out.println(shop.listStock());
        System.out.println("Value: " + shop.stockValue());
        System.out.println("Num caps: " + shop.numCaps());
        System.out.println("Num TShirts: " + shop.numTShirts());
        
    }

}
