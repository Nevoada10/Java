/*
 * OnlineShop.java
 *
 *
 * �Copyright 2021 Joan Seculi <jseculi@escoladeltreball.org>
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
*/

package onlineShop;
import java.util.ArrayList;
import java.util.List;

public class OnlineShop {

    private List<Product> stock;

    public OnlineShop() {
        this.stock = new ArrayList<Product>();
    }

    /**
     * Add product to the stock.
     * 
     * @param p the product
     * @return true if it has been added, false otherwise
     */
    public boolean addProduct(Product p) {
        return this.stock.add(p);
    }

//    public boolean addImage(Product p, PrintImage printImage) {
//    	if (p.isOnSell()) {
//    		p.setPrintImage(printImage);
//    		return true;
//    	}
//    	return false;
//    }
    public boolean sellProduct(Product p, PrintImage printImage) {
    	if (p.isOnSell()) {
    		p.setPrintImage(printImage);
    		p.setPrice(p.getPrice() + Product.PRICE_IMAGE);
    		return stock.remove(p);
    	} else  {
    		return false;
    	}
    }
    /**
     * Remove a product from the stock.
     * 
     * @param p a product
     * @return true it has been removed, false otherwise
     */
    public boolean removeProduct(Product p) {
        return this.stock.remove(p);
    }

    /**
     * List shop stock
     */
    public String listStock() {
    	String text = "";
       // int numTshirts = 0, numCaps = 0;
       
        text += String.format("%-10S%-10S%-10S%-10S%-10S%-10S%-10S%-10S%-10S%-10S", "BARCODE","DESC","PRICE","PRINT", "COLOR", "ON-SELL", "FABRIC", "POCKET?", "BUTTONS?", "CAP TYPE");
        text += "\n----------------------------------------------------------------------------------------------------\n";
        for (Product a : this.stock) {
        	text += String.format("%-10S%-10S%-10.2f%-10S%-10S%-10B",  a.getBarCode(), a.getDesc(), a.price(), a.getPrintImage(), a.getColor(), a.isOnSell());
           
            if (a instanceof TShirt) {
            	text += String.format("%-10S",((TShirt)a).getFabric()); //Tank
            	 if (a instanceof BasicT) text += String.format("%-10S%-10S%n",((BasicT)a).isHasPocket(),((BasicT)a).isHasButtons());
            	 if (a instanceof VNeckT) text += String.format("%-10S%n",((VNeckT)a).isHasPocket());
            	 if (a instanceof LongT) text +=  String.format("%-10S%n",((LongT)a).isHasPocket());
            	 if (a instanceof TankT) text +=  String.format("%n");
            	 
             	
            	//numTshirts ++;
            }    
            else if (a instanceof Cap) {
            	text += String.format("%-10S%-10S%-10S%-10S%n","", "", "", ((Cap)a).getVisor());
            	//numCaps ++;
            }    
        }
        
//        text += "\nStock T-Shirts: " + numTshirts;
//        text +=	"\nStock Caps: " + numCaps;
//        text += "\nValue Total Stock: " + this.stockValue();
        return text;
    }
    
    

    /**
     * Calculates total stock value.
     * 
     * @return the value
     */
    public float stockValue() {
        float total = 0;
        for (Product c : stock) {
            total = total +  c.price();
        }
        return total;
    }
    
    public int numCaps() {
    	int numCaps = 0;
        for (Product a : this.stock) {
        	 if (a instanceof Cap) {
            	numCaps ++;
            }    
        }
        return numCaps;
    }
    public int numTShirts() {
    	int numTshirts = 0;
        for (Product a : this.stock) {
        	
            if (a instanceof TShirt) {
            
            	numTshirts ++;
            }    
               
        }
        return numTshirts;
    }

	public List<Product> getStock() {
		return stock;
	}

	public void setStock(List<Product> stock) {
		this.stock = stock;
	}
    
}
