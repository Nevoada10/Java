/*
 * Car.java       23/04/2021
 *
 *
 * Copyright 2021 Joan Seculi <jseculi@escoladeltreball.org>
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package vehicle;
public class Vehicle {
	private String registration;
	private String make;
	private String model;

	public Vehicle(String registration, String make, String model) {
		this.registration = registration;
		this.make = make;
		this.model = model;
	}

	@Override
	public String toString() {
		System.out.println("I am in Vehicle");
		return "Vehicle [registration=" + registration + ", make=" + make + ", model=" + model + "]";
	}

	public String getRegistration() {
		return registration;
	}

	public void setRegistration(String registration) {
		this.registration = registration;
	}

	public String getMake() {
		return make;
	}

	public void setMake(String make) {
		this.make = make;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public double weight() {
		//System.out.println("I am in Vehicle");
		if (registration.toUpperCase().charAt(0)=='A') return 1.0;
		else return 2.0;
	}
	
}
