/*
 * Car.java       23/04/2021
 *
 *
 * Copyright 2021 Joan Seculi <jseculi@escoladeltreball.org>
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package vehicle;

public class Truck extends Car {
	private int maxLoad;
	private boolean hasFridge;
	
	
	public Truck(String registration, String make, String model, byte numSeats, byte numDoors, String fuelType,
			int maxLoad, boolean hasFridge) {
		super(registration, make, model, numSeats, numDoors, fuelType);
		this.maxLoad = maxLoad;
		this.hasFridge = hasFridge;
	}


	@Override
	public String toString() {
		System.out.println("I am in Truck");
		return "Truck [maxLoad=" + maxLoad + ", hasFridge=" + hasFridge + ", toString()=" + super.toString() + "]";
	}


	public int getMaxLoad() {
		return maxLoad;
	}


	public void setMaxLoad(int maxLoad) {
		this.maxLoad = maxLoad;
	}


	public boolean hasFridge() {
		return hasFridge;
	}


	public void setHasFridge(boolean hasFridge) {
		this.hasFridge = hasFridge;
	}


	@Override
	public double weight() {
		System.out.println("I am in Truck");
		if (hasFridge) return maxLoad * 2 * super.weight();
		return maxLoad * super.weight();
	}
}