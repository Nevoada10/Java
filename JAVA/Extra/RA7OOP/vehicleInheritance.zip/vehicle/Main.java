/*
 * Car.java       23/04/2021
 *
 *
 * Copyright 2021 Joan Seculi <jseculi@escoladeltreball.org>
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package vehicle;
import java.util.ArrayList;
import java.util.List;

public class Main {

	public static void main(String[] args) {
		
		//Instantiate Vehicle
		System.out.println("Instantiate Vehicle:");
		Vehicle vehicle1 = new Vehicle("REG-V", "Tesla", "T1");
		System.out.println("veh: " + vehicle1.toString());
		System.out.println("veh: " + vehicle1.weight());

		//Instantiate Car as Car
		System.out.println("\nInstantiate Car as Car:");
				
		System.out.println("Car car1 = new Car()");
		Car car1 = new Car("REG-A", "Maserati", "M1", (byte)4, (byte)4, "Gas");
		System.out.println("car1: " + car1.toString());
		System.out.println("car1: " + car1.weight());
		System.out.println("car2: " + car1.has4Doors());
		
		//Instantiate Car as Vehicle
		System.out.println("\nInstantiate Car as Vehicle:");
		System.out.println("Vehicle car2 = new Car()");
		Vehicle car2 = new Car("AEG-B", "Ferrari", "F1", (byte)2, (byte)2, "Gas");
		System.out.println("car2: " + car2.toString());  //llegeix el toString de Car
		System.out.println("car2: " + car2.weight());
		System.out.println("car2: " + ((Car)car2).has4Doors());
		
		
		//Car car3 = car2; //error
		System.out.println("\nAssign a vehicle to a car:");
		System.out.println("Car car3 = (Car)car2");
		Car car3 = (Car)car2;
		System.out.println("car3: " + car3.toString());
		System.out.println("car3: " + car3.weight());
		System.out.println("car3: " + ((Car)car3).has4Doors());
		
	
		System.out.println("\ninstanceof car1");
		
		if (car1 instanceof Car) {
				
			System.out.println("car1 is a car");  //true
		} else {
			System.out.println("car1 is not a car");
		}
		
		if (car1 instanceof Vehicle) {
			System.out.println("car1 is a Vehicle");  //true
		} else {
			System.out.println("car1 is not a Vehicle");
		}
		
		System.out.println("\ninstanceof car5");
		Vehicle car5 = new Vehicle("REG-D", "Lamborghini", "L1");
		
		if (car5 instanceof Car) {
			System.out.println("car5 is a car");   
		} else {
			System.out.println("car5 is not a car");   //false
		}
		if (car5 instanceof Vehicle) {
			System.out.println("car5 is a Vehicle");  //true
		} else {
			System.out.println("car5 is not a Vehicle");
		}
		
		
		System.out.println("\nTruck as a Vehicle");
		Vehicle truck = new Truck("R0001", "Pegasus", "P1", (byte)3, (byte)4, "Diesel", 1000, true);
		System.out.println("truck: " + truck.toString());
		System.out.println("truck: " + truck.weight());
		System.out.println("truck: " + ((Truck)truck).has4Doors());
		//System.out.println("truck: " + ((Car)truck).has4Doors());  //tamb� pot ser
		
		
		System.out.println("\nTruck as a Car");
		Car truck2 = new Truck("R0002", "Pegasus", "P2", (byte)4, (byte)5, "Diesel", 1200, true);
		System.out.println("truck: " + truck2.toString());
		System.out.println("truck: " + truck2.weight());
		System.out.println("truck: " + ((Truck)truck2).has4Doors());
		System.out.println("truck: " + truck2.has4Doors()); //tamb� pot ser
		System.out.println("truck: " + ((Car)truck2).has4Doors());  //tamb� pot ser
		
		System.out.println("\nTruck as a Truck");
		Truck truck3 = new Truck("R0003", "Pegasus", "P3", (byte)3, (byte)3, "Gas", 1500, true);
		System.out.println("truck: " + truck3.toString());
		System.out.println("truck: " + truck3.weight());
		System.out.println("truck: " + ((Truck)truck3).has4Doors());
		System.out.println("truck: " + ((Car)truck3).has4Doors());  //tamb� pot ser
		System.out.println("truck: " + truck3.has4Doors()); //tamb� pot ser

		
		System.out.println("\nMoto as a Vehicle");
		Vehicle moto = new Moto("L001", "BMW", "B1",250);
		System.out.println("moto: " + moto.toString());
		System.out.println("moto: " + moto.weight());
		
		System.out.println("\nMoto as a Moto");
		Moto moto2 = new Moto("L002", "Aprilia", "B2",300);
		System.out.println("moto: " + moto2.toString());
		System.out.println("moto: " + moto2.weight());
		
		
		//Part2
		
		System.out.println("\nArrayList");
		List<Vehicle> vehicles = new ArrayList<>();

		
		vehicles.add(vehicle1);
		vehicles.add(car1);
		vehicles.add(car2);
		vehicles.add(car3);
		vehicles.add(truck);
		vehicles.add(truck2);
		vehicles.add(truck3);
		vehicles.add(moto);
		vehicles.add(moto2);

		
		
		for (Vehicle v : vehicles) {
			System.out.println(v.getClass());
			
			System.out.println(v.toString());
			
			System.out.println("Model: " + v.getModel() +
					" - Make: " + v.getMake() +
					" - Registration: " + v.getRegistration() + 
					" - weight: "+ v.weight() + "\n"); 
			
			if  (v instanceof Moto) {
				System.out.println("cc: " + ( (Moto)v).getCc() + "\n");
			} 
			if(v instanceof Truck) {
				System.out.println("MaxLoad: " + ((Truck) v).getMaxLoad() +
						" - HasFridge: " + ((Truck) v).hasFridge() + 
						" - 4Doors: " + ((Truck) v).has4Doors() + "\n");
			} 
			if (v instanceof Car) {
				System.out.println("4Doors: " + ((Car)v).has4Doors() + 
						" - Num Seats: " + ((Car) v).getNumSeats() + 
						" - Num Doors: " + ((Car) v).getNumDoors() + 
						" - Fuel Type: " + ((Car) v).getFuelType() + 
						"\n");
			} 
		
		}

	
		
	}

}
