/*
 * Car.java       23/04/2021
 *
 *
 * Copyright 2021 Joan Seculi <jseculi@escoladeltreball.org>
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package vehicle;

public class Car extends Vehicle {

	private byte numSeats;
	private byte numDoors;
	private String fuelType;
	

	public Car(String registration, String make, String model, byte numSeats, byte numDoors, String fuelType) {
		super(registration, make, model);
		this.numSeats = numSeats;
		this.numDoors = numDoors;
		this.fuelType = fuelType;
	}

	@Override
	public String toString() {
		System.out.println("I am in Car");
		return "Car [numSeats=" + numSeats + ", numDoors=" + numDoors + ", fuelType=" + fuelType + ", toString()="
				+ super.toString() + "]";
	}

	public byte getNumSeats() {
		return numSeats;
	}

	public void setNumSeats(byte numSeats) {
		this.numSeats = numSeats;
	}

	public byte getNumDoors() {
		return numDoors;
	}

	public void setNumDoors(byte numDoors) {
		this.numDoors = numDoors;
	}

	public String getFuelType() {
		
		return fuelType;
	}

	public void setFuelType(String fuelType) {
		this.fuelType = fuelType;
	}


	@Override
	public double weight() {
		//System.out.println("I am in Car");
		return numSeats * numDoors* super.weight();
	}
	
	public boolean has4Doors() {
		return numDoors == 4;
	}
}
	
	