/*
 * Car.java       23/04/2021
 *
 *
 * Copyright 2021 Joan Seculi <jseculi@escoladeltreball.org>
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package vehicle;

public class Moto extends Vehicle {

	private int cc;

	public int getCc() {
		return cc;
	}
	public void setCc(int cc) {
		this.cc = cc;
	}
	public Moto(String registration, String make, String model, int cc) {
		super(registration, make, model);
		this.cc = cc;
	}
	
	@Override
	public String toString() {
		System.out.println("I am in Moto");
		return "Moto [cc=" + cc + ", toString()=" + super.toString() + "]";
	}
	@Override
	public double weight() {
		//System.out.println("I am in Moto");
		return cc * super.weight() / 10.0;
	}
	
}