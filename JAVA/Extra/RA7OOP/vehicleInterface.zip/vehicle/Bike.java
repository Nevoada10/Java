/*
 * Bike.java       30/04/2021
 *
 *
 * �Copyright 2021 Joan Seculi <jseculi@escoladeltreball.org>
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package vehicle;

public class Bike extends Vehicle implements Movable, Repairable{

	public Bike(int posX, int posY, int money, boolean available) {
		super(posX, posY, money, available);
	}

	@Override
	public boolean repair() {
		if (isAvailable()) return false;  //we only can repair if car is unavailable
		if (getMoney() >= Repairable.MOTO) {
			super.setMoney(getMoney() - Repairable.MOTO);
			super.setAvailable(true);
			return true;
		}
		else return false;
	}

	@Override
	public boolean move(char pos) {
		if (!isAvailable()) return false; //we only can move if bike is available
		if(pos=='X') {
			super.setPosX(super.getPosX() + Movable.BIKE);
			return true;
		} else if(pos=='Y') {
			super.setPosY(super.getPosY() + Movable.BIKE);
			return true;
		}
		
		return false;
		
	}
}