/*
 * Test.java       05/05/2021
 *
 *
 * �Copyright 2021 Joan Seculi <jseculi@escoladeltreball.org>
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package vehicle;

import java.util.Locale;
import java.util.Scanner;

public class Main {
	public static Scanner scanner = new Scanner(System.in).useLocale(Locale.UK);

	public static void main(String[] args) {
		Movable car = new Car(0, 0, 1000, true, 100);
		Movable moto = new Moto(0, 0, 1000, true, 50);
		Movable truck = new Truck(0, 0, 1000, true, 200, 10000);
		Movable bike = new Bike(0, 0, 1000, true);
		
		Diagonal diagonal = new Diagonal();

		boolean cont = true;
		Scanner sc = new Scanner(System.in);
		while (cont) {
			System.out.print("MENU:\n");
			System.out.print("1. MOVE CAR X\n");
			System.out.print("2. MOVE CAR Y\n");
			System.out.print("3. SHOW DETAILS CAR\n");
			System.out.print("4. SIMULATE COLLISION CAR\n");
			System.out.print("5. REPAIR CAR\n");
			System.out.print("6. REFILL CAR\n");
			System.out.print("7. GET MONEY CAR\n");
		//	System.out.print("8. MOVE CAR XY\n");
			System.out.print("0. LEAVE.\n");
			System.out.print("\nOption (0 .. 7) ? ");
			int op = sc.nextInt();
			switch (op) {
			case 0:
				System.out.print("\nEnd of program\n");
				cont = false;
				break;
			case 1:
				System.out.println(((Car) car).move('x'));
				System.out.println(((Car) car).toString());
				break;
			case 2:
				System.out.println(((Car) car).move('y'));
				System.out.println(((Car) car).toString());
				break;
			case 3:
				System.out.println(((Car) car).toString());
				break;
			case 4:
				System.out.println(((Car) car).collision());
				System.out.println(((Car) car).toString());
				break;
			case 5:
				System.out.println(((Car) car).repair());
				System.out.println(((Car) car).toString());
				break;
			case 6:
				System.out.println(((Car) car).refill());
				System.out.println(((Car) car).toString());
				break;
			case 7:
				int money = dataEntryInt("Enter money:");
				((Car) car).setMoney(((Car) car).getMoney() + money);
				System.out.println(((Car) car).toString());
				break;
//			case 8:
//				
//				System.out.println(diagonal.moveXY(car));
//				System.out.println(((Car) car).toString());
//				break;

			default:
				System.out.print("\nThis is not an option\n");
			}
		}
		sc.close();
	}
	public static int dataEntryInt(String text) {
		int number = 0;
		System.out.println(text);
		boolean isValid = false;
		while (!isValid) {
			if (scanner.hasNextInt()) {
				number = scanner.nextInt();
				isValid = true;
			} else {
				scanner.next();  //Consume next line
				System.out.println("Error! " + text);
			}
		}
		return number;
	}
}
