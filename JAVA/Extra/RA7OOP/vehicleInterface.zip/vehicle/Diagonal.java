package vehicle;

public class Diagonal {
//	public boolean moveXY(Movable movable) {
//		return (movable.move('x') && movable.move('y'));
//
//	}
//
}
