/*
 * Truck.java       23/04/2021
 *
 *
 * �Copyright 2021 Joan Seculi <jseculi@escoladeltreball.org>
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package vehicle;

public class Truck extends Vehicle implements Movable, Repairable, Refillable{
	private int petrol;
	private int load;
	
	

	public Truck(int posX, int posY, int money, boolean available, int petrol, int load) {
		super(posX, posY, money, available);
		this.petrol = petrol;
		this.load = load;
	}

	

	@Override
	public String toString() {
		return "Truck [petrol=" + petrol + ", load=" + load + ", toString()=" + super.toString() + "]";
	}



	@Override
	public boolean repair() {
		if (isAvailable()) return false;  //we only can repair if car is unavailable
		if (getMoney() > Repairable.TRUCK) {
			super.setMoney(getMoney() - Repairable.TRUCK);
			super.setAvailable(true);
			return true;
		}
		else return false;
	}

	@Override
	public boolean move(char pos) {
		if (petrol == 0) return false;
		int move = Movable.TRUCK_CONSUM + (int)load/1000;
		if ((petrol - move) >= 0) {
			petrol -= move;
			if (pos == 'x') {
				setPosX(getPosX() + Movable.TRUCK);
			} else {
				setPosY(getPosY() + Movable.TRUCK);
			}
			return true;
		} else { 
			//super.setAvailable(false);	
			return false;
		}
	}

	@Override
	public boolean refill() {
		if (!isAvailable()) return false; //we only can fill if car is available
		if (petrol == Refillable.TRUCK) return false;
		int diff = Refillable.TRUCK - petrol;
		int need = diff * Refillable.PRICE;
		if (getMoney() >= need) {
			petrol = Refillable.TRUCK;
			setMoney(getMoney() - need);
			return true;
		} else {
			return false;
		}
	}

}