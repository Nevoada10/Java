/*
 * Moto.java       23/04/2021
 *
 *
 * �Copyright 2021 Joan Seculi <jseculi@escoladeltreball.org>
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package vehicle;

public class Moto extends Vehicle implements Movable, Repairable, Refillable{
	private int petrol;


	public Moto(int posX, int posY, int money, boolean available, int petrol) {
		super(posX, posY, money, available);
		this.petrol = petrol;
	}
	
	@Override
	public String toString() {
		return "Moto [petrol=" + petrol + ", toString()=" + super.toString() + "]";
	}

	@Override
	public boolean repair() {
		if (isAvailable()) return false;  //we only can repair if moto is unavailable
		if (getMoney() > Repairable.MOTO) {
			super.setMoney(getMoney() - Repairable.MOTO);
			super.setAvailable(true);
			return true;
		}
		else return false;
	}

	@Override
	public boolean move(char pos) {
		if (petrol == 0) return false;
		if (!isAvailable()) return false; //we only can move if moto is available
		if ((petrol - Movable.MOTO_CONSUM) >= 0) {
			petrol -= Movable.MOTO_CONSUM;
			if (pos == 'x') {
				setPosX(getPosX() + Movable.MOTO);
			} else {
				setPosY(getPosY() + Movable.MOTO);
			}
			return true;
		} else { 
			//super.setAvailable(false);	
			return false;
		}
	}

	@Override
	public boolean refill() {
		if (!isAvailable()) return false; //we only can fill if car is available
		if (petrol == Refillable.MOTO) return false;
		int diff = Refillable.MOTO - petrol;
		int need = diff * Refillable.PRICE;
		if (getMoney() >= need) {
			petrol = Refillable.MOTO;
			setMoney(getMoney() - need);
			return true;
		} else {
			return false;
		}
	}

}