/*
 * Car.java       23/04/2021
 *
 *
 * �Copyright 2021 Joan Seculi <jseculi@escoladeltreball.org>
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package vehicle;


public class Car extends Vehicle implements Movable, Repairable, Refillable {

	private int petrol;
	
	public Car(int posX, int posY, int money, boolean available, int petrol) {
		super(posX, posY, money, available);
		this.petrol = petrol;
	}
	

	@Override
	public String toString() {
		return "Car: petrol=" + petrol  + ", " + super.toString();
	}


	@Override
	public boolean repair() {
		if (isAvailable()) return false;  //we only can repair if car is unavailable
		if (getMoney() >= Repairable.CAR) {
			super.setMoney(getMoney() - Repairable.CAR);
			super.setAvailable(true);
			return true;
		}
		else return false;
	}

	@Override
	public boolean move(char pos) {
		if (petrol == 0) return false;
		if (!isAvailable()) return false; //we only can move if car is available
		if ((petrol - Movable.CAR_CONSUM) >= 0) {
			petrol -= Movable.CAR_CONSUM;
			if (pos == 'x') {
				setPosX(getPosX() + Movable.CAR);
				
			} else {
				setPosY(getPosY() + Movable.CAR);	
			}
			return true;
		} else { 
			//super.setAvailable(false);	
			return false;
		}
	}

	@Override
	public boolean refill() {
		if (!isAvailable()) return false; //we only can fill if car is available
		if (petrol == Refillable.CAR) return false;
		int diff = Refillable.CAR - petrol;
		int need = diff * Refillable.PRICE;
		if (getMoney() >= need) {
			petrol = Refillable.CAR;
			setMoney(getMoney() - need);
			return true;
		} else {
			return false;
		}
		
	}


	public int getPetrol() {
		return petrol;
	}


	public void setPetrol(int petrol) {
		this.petrol = petrol;
	}

	
}
	
	