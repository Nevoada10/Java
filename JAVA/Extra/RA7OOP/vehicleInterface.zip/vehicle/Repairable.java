/*
 * Reparable.java       30/04/2021
 *
 *
 * �Copyright 2021 Joan Seculi <jseculi@escoladeltreball.org>
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package vehicle;

public interface Repairable {
	int CAR = 500;
	int MOTO = 300;
	int TRUCK = 400;
	int BIKE = 50;
	
    boolean repair();
    
    

}
