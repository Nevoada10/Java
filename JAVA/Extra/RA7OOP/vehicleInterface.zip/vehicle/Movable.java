/*
 * Movable.java       30/04/2021
 *
 *
 * �Copyright 2021 Joan Seculi <jseculi@escoladeltreball.org>
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package vehicle;

public interface Movable {
   // boolean jump();
	int CAR = 10;
	int MOTO = 8;
	int TRUCK = 7;
	int BIKE = 3;
	
	int CAR_CONSUM = 10;
	int MOTO_CONSUM = 4;
	int TRUCK_CONSUM = 6;

    boolean move(char pos);
    
    boolean collision();
    
    
    /*default double inertia(double m, double r) {
    	return m * r * r;
    }*/
    
    
    /*
    public static boolean moveAll(char pos, int type, Object obj) {
    	if (obj instanceof Car) {
    		if ((((Car) obj).getPetrol() - Movable.CAR_CONSUM) > 0) {
    			((Car) obj).setPetrol( ((Car) obj).getPetrol() - Movable.CAR_CONSUM);
    			if (pos == 'x') {
    				((Car)obj).setPosX(((Car)obj).getPosX() + Movable.CAR);
    				
    			} else {
    				((Car)obj).setPosY(((Car)obj).getPosY() + Movable.CAR);
    				
    			}
    			return true;
    		} else { 
    			((Car)obj).setAvailable(false);	
    			return false;
    		}
    	}
    	return false;
    }*/

}
