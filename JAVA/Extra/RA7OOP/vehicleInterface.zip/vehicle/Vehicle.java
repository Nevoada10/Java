/*
 * Vehicle.java       23/04/2021
 *
 *
 * �Copyright 2021 Joan Seculi <jseculi@escoladeltreball.org>
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package vehicle;

public abstract class Vehicle implements Movable{


	protected int posX;
	protected int posY;
	protected int money;
	protected boolean available;
	
	public Vehicle(int posX, int posY, int money, boolean available) {
		super();
		this.posX = posX;
		this.posY = posY;
		this.money = money;
		this.available = available;
	}
	
	@Override
	public String toString() {
		return "pos=[" + posX + ", " + posY + "], $=" + money + ", available=" + available;
	}
	public int getPosX() {
		return posX;
	}
	public void setPosX(int posX) {
		this.posX = posX;
	}
	public int getPosY() {
		return posY;
	}
	public void setPosY(int posY) {
		this.posY = posY;
	}
	public int getMoney() {
		return money;
	}
	public void setMoney(int money) {
		this.money = money;
	}
	public boolean isAvailable() {
		return available;
	}
	public void setAvailable(boolean available) {
		this.available = available;
	}
		
	@Override
	public boolean collision() {
		if (!isAvailable()) return false; //we only can collision if vehicle is available
		setAvailable(false); 
		return true;
		
	}
	
	
}
