/*
 * Refillable.java       30/04/2021
 *
 *
 * �Copyright 2021 Joan Seculi <jseculi@escoladeltreball.org>
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package vehicle;

public interface Refillable {
	int CAR = 100; //capacity in liters
	int MOTO = 50;
	int TRUCK = 200;
	
	int PRICE = 1; //price per liter

	
	boolean refill();

}
