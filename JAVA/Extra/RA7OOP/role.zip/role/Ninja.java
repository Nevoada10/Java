/*
 * Ninja.java       25/04/2021
 *
 *
 * �Copyright 2021 Joan Seculi <jseculi@escoladeltreball.org>
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package role;

public class Ninja extends Role {
	
	public Ninja(float posX, float posY) {
		super(posX, posY);
	}

	public void move() {
		setPosX(posX + Utils.NINJA_MOVE);
		

	}
	
	public void jump() {
		setPosY(posY + Utils.NINJA_JUMP);

	}

	@Override
	public String toString() {
		return "Ninja [toString()=" + super.toString() + "]";
	}
	
}
