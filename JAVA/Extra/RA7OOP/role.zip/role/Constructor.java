/*
 * Constructor.java       25/04/2021
 *
 *
 * @Copyright 2021 Joan Seculi <jseculi@escoladeltreball.org>
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package role;

public class Constructor extends Role {
	
	public Constructor(float posX, float posY) {
		super(posX, posY);
		
	
	}

	public void move() {
		setPosX(posX + Utils.CONSTRUCTOR_MOVE);
		
		
	}

	
	public void jump() {
		setPosY(posY + Utils.CONSTRUCTOR_JUMP);
		
	}
	@Override
	public String toString() {
		return "Constructor [toString()=" + super.toString() + "]";
	}
}
