/*
 * Soldier.java       25/04/2021
 *
 *
 * �Copyright 2021 Joan Seculi <jseculi@escoladeltreball.org>
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package role;

public class Soldier extends Role {
	
	
	
	public Soldier(float posX, float posY) {
		super(posX, posY);
		
	}

	public void move() {
		
		 posX += Utils.SOLDIER_MOVE;
				

				
	}
	
	public void jump() {
		posY += Utils.SOLDIER_JUMP;
		
	}

	@Override
	public String toString() {
		return "Soldier [toString()=" + super.toString() + "]";
	}


	
}
