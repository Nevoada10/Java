/*
 * Test.java       25/04/2021
 *
 *
 * �Copyright 2021 Joan Seculi <jseculi@escoladeltreball.org>
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package role;

public class Main {

	public static void main(String[] args) {
		//Role role = new Role();  //ERROR
		
		Role outlander = new Outlander(1,1);
		outlander.move();
		outlander.jump();
		System.out.println(outlander.toString());
		outlander.extraMove();
		System.out.println(outlander.toString());
		outlander.extraJump();
		System.out.println(outlander.toString());
		
		
		Role soldier = new Soldier(1,1);
		soldier.move();
		soldier.jump();
		System.out.println(soldier.toString());
		soldier.extraMove();
		System.out.println(soldier.toString());
		soldier.extraJump();
		System.out.println(soldier.toString());
		
        		
		Role constructor = new Constructor(1,1);
		constructor.move();
		constructor.jump();
		System.out.println(constructor.toString());
		constructor.extraMove();
		System.out.println(constructor.toString());
		constructor.extraJump();
		System.out.println(constructor.toString());
		
		Role ninja = new Ninja(1,1);
        ninja.move();
        ninja.jump();
        System.out.println(ninja.toString());
        ninja.extraMove();
		System.out.println(ninja.toString());
		ninja.extraJump();
		System.out.println(ninja.toString());

		
	}

}
