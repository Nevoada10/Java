/*
 * Utils.java 10 May 2023
 *
 *
 * \u00A9 Copyright 2023 Joan S�culi
 * Email: jseculi@escoladeltreball.org
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package role;

public class Utils {
	public static final float OUTLANDER_MOVE = 10.5f;
	public static final float OUTLANDER_JUMP = 6.2f;
	
	public static final float SOLDIER_MOVE = 10.5f;
	public static final float SOLDIER_JUMP = 8.0f;
	
	public static final float CONSTRUCTOR_MOVE = 5f;
	public static final float CONSTRUCTOR_JUMP = 5f;
	
	public static final float NINJA_MOVE = 8.0f;
	public static final float NINJA_JUMP = 7.5f;
	
	public static final float EXTRA_MOVE = 20.5f;
	public static final float EXTRA_JUMP = 25.2f;
	
	public static final float ENERGY_MOVE = 0.5f;
	public static final float ENERGY_JUMP = 1f;
	
	public static final float EXTRA_ENERGY_MOVE = 2f;
	public static final float EXTRA_ENERGY_JUMP = 4f;
	

	public static final float INITIAL_ENERGY = 100f;
	
	public static final byte LIFES = 3;

}
