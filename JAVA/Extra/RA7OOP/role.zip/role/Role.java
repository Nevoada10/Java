/*
 * Character.java       25/04/2021
 *
 *
 * �Copyright 2021 Joan Seculi <jseculi@escoladeltreball.org>
 *
 * This is free software, licensed under the GNU General Public License v3.
 * See http://www.gnu.org/licenses/gpl.html for more information.
 */
package role;

public abstract class Role {
	protected float posX;
	protected float posY;
	protected boolean available;
	protected byte lifes;
	protected float energy;
	
	public Role(float posX, float posY) {
		this.posX = posX;
		this.posY = posY;
		available = true;
		energy = Utils.INITIAL_ENERGY;
		lifes = Utils.LIFES;
	}

	public abstract void move();
	
	public abstract void jump();
	
	public float getPosX() {
		return posX;
	}
	public void setPosX(float posX) {
		if (available) {
			if (energy >= Utils.ENERGY_MOVE) {
				this.posX = posX;
				energy -= Utils.ENERGY_MOVE;
			}

		}
	}
	public float getPosY() {
		return posY;
	}
	public void setPosY(float posY) {
		if (available) {
			if (energy >= Utils.ENERGY_JUMP) {
				this.posY = posY;
				energy -= Utils.ENERGY_JUMP;

			}
		}
	}

	public boolean isAvailable() {
		return available;
	}

	public void setAvailable(boolean available) {
		this.available = available;
	}

	public byte getLifes() {
		return lifes;
	}

	public void setLifes(byte lifes) {
		
		this.lifes = lifes;
	}

	public float getEnergy() {
		return energy;
	}

	public void setEnergy(float energy) {
		this.energy = energy;
	}

	@Override
	public String toString() {
		return "[" + posX + "," + posY + "]";
	}
	
	public final void extraMove() {
		if (available) {
			if (energy >= Utils.EXTRA_ENERGY_MOVE) {
				posX += Utils.EXTRA_MOVE; 
				energy -= Utils.EXTRA_ENERGY_MOVE;;
			}
			
		}
	}
	
	public final void extraJump() {
		if (available) {
			if (energy >= Utils.EXTRA_ENERGY_JUMP) {
				posY += Utils.EXTRA_JUMP; 
				energy -= Utils.EXTRA_ENERGY_JUMP;
			}
		}
	}

	public final void resetPosition() {
		posX = 0; 
		posY = 0; 
	}
	
	public final void resetRole() {
		posX = 0; 
		posY = 0; 
		available = true;
		lifes = 3;
		energy = 100;
	}
	
	public final boolean decreaseLife() {
		if (lifes > 0 && available) {
			lifes--;
			return true;
		}
		return false;
	}
	
	public final boolean increaseLife() {
		if (lifes < 3 && available) {
			lifes++;
			return true;
		}
		return false;
	}

}
